"""Persist and restore the web service's desired GPU configuration."""

import json
import os
from pathlib import Path
import re
import runpy
import sys
import time

from inventory import READ_ERRORS, normalize_bdf
import mig


STORE = Path("/var/lib/vgpu-web/gpu-state.json")
LEGACY_STORE = Path("/etc/nvidia-vgpu-persist/config.json")
_restore = runpy.run_path(str(Path(__file__).resolve().parents[1] / "vgpu-persist/vgpu-persist.py"))
Hardware = _restore["Hardware"]
StateError = _restore["Error"]


def normalize_state(raw):
    if (not isinstance(raw, dict) or raw.get("version") not in (1, 2, 3)
            or not isinstance(raw.get("enabled_pfs"), dict)):
        raise StateError("Check the vGPU Web UI restore configuration format.")
    enabled = {}
    for address, gpu_uuid in raw["enabled_pfs"].items():
        pf = normalize_bdf(address)
        if (pf in enabled or not isinstance(gpu_uuid, str)
                or not re.fullmatch(r"GPU-[0-9a-fA-F-]+", gpu_uuid)):
            raise StateError(f"{pf}: The restore configuration contains an invalid or duplicate GPU UUID.")
        enabled[pf] = gpu_uuid
    entries = _restore["validate_config"]({**raw, "version": 1})
    if any(enabled.get(entry["pf"]) != entry["gpu_uuid"] for entry in entries):
        raise StateError("The VF and physical GPU entries in the restore configuration do not match.")
    mig_pfs = raw.get("mig_pfs", {})
    if not isinstance(mig_pfs, dict) or (raw["version"] == 1 and mig_pfs):
        raise StateError("Invalid saved MIG configuration")
    configured = {}
    for address, config in mig_pfs.items():
        pf = normalize_bdf(address)
        if (pf in configured or not isinstance(config, dict)
                or not isinstance(config.get("gpu_uuid"), str)
                or not re.fullmatch(r"GPU-[0-9a-fA-F-]+", config["gpu_uuid"])
                or enabled.get(pf, config["gpu_uuid"]) != config["gpu_uuid"]
                or not isinstance(config.get("instances"), list)):
            raise StateError(f"{pf}: invalid saved MIG GPU")
        layout = []
        for row in config["instances"]:
            if (not isinstance(row, dict) or not isinstance(row.get("profile"), str)
                    or not re.fullmatch(mig.PROFILE_NAME, row["profile"])
                    or type(row.get("start")) is not int or row["start"] < 0
                    or type(row.get("size")) is not int or row["size"] <= 0
                    or any(mig.overlaps(existing, row) for existing in layout)):
                raise StateError(f"{pf}: invalid or overlapping saved GI")
            layout.append(mig.geometry(row))
        configured[pf] = {"gpu_uuid": config["gpu_uuid"],
                          "instances": sorted(layout, key=lambda row: row["start"])}
    for entry in entries:
        config = configured.get(entry["pf"])
        if config is None and "gi_start" not in entry:
            continue
        if (config is None or type(entry.get("gi_start")) is not int
                or entry["gi_start"] not in {row["start"] for row in config["instances"]}):
            raise StateError(f"{entry['vf_bdf']}: invalid saved GI placement")
    result = {"version": 1, "enabled_pfs": dict(sorted(enabled.items())),
              "entries": sorted(entries, key=lambda entry: (entry["pf"], entry["vf_index"]))}
    if configured:
        result.update(version=2, mig_pfs=dict(sorted(configured.items())))
    size_modes = raw.get("size_modes", {})
    if not isinstance(size_modes, dict):
        raise StateError("Invalid saved size modes")
    normalized_modes = {}
    for address, config in size_modes.items():
        pf = normalize_bdf(address)
        if (pf in normalized_modes or pf in configured or not isinstance(config, dict)
                or config.get("mode") not in ("equal", "mixed")
                or enabled.get(pf) is None or config.get("gpu_uuid") != enabled[pf]):
            raise StateError(f"{pf}: invalid saved size mode or GPU identity")
        normalized_modes[pf] = {"gpu_uuid": enabled[pf], "mode": config["mode"]}
    if normalized_modes:
        result.update(version=3, size_modes=dict(sorted(normalized_modes.items())))
    return result


def load_state(path=STORE):
    return normalize_state(json.loads(path.read_text(encoding="utf-8")))


def save_state(path, state):
    canonical = normalize_state(state)
    _restore["atomic_write"](path, json.dumps(canonical, indent=2, ensure_ascii=False) + "\n", 0o600)
    if sys.platform == "linux":
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def check_legacy(pfs, path=LEGACY_STORE):
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return
    overlap = set(pfs) & {entry["pf"] for entry in _restore["validate_config"](json.loads(raw))}
    if overlap:
        raise StateError("These GPUs are already registered in a separate vgpu-persist restore configuration: " + ", ".join(sorted(overlap)))


def gpu_identity(hw, pf, inventory=None, *, allow_mig=False):
    inventory = hw.gpus() if inventory is None else inventory
    if pf not in inventory:
        raise StateError(f"{pf}: Unable to identify the NVIDIA GPU.")
    gpu_uuid = inventory[pf]["gpu_uuid"]
    if allow_mig:
        hw.check_pf(pf, gpu_uuid, inventory, allow_mig=True)
        if not mig.supported(inventory[pf]["name"]):
            raise StateError(f"{pf}: unsupported GPU for Cockpit MIG management")
    else:
        hw.check_pf(pf, gpu_uuid, inventory)
    return gpu_uuid


def with_enabled_pf(state, pf, gpu_uuid):
    previous_uuid = state["enabled_pfs"].get(pf)
    if previous_uuid is not None and previous_uuid != gpu_uuid:
        raise StateError(f"{pf}: The saved GPU UUID differs from the installed GPU.")
    return {**state, "enabled_pfs": {**state["enabled_pfs"], pf: gpu_uuid}}


def with_profile(state, pf, gpu_uuid, index, vf, profile, gi_start=None):
    updated = with_enabled_pf(state, pf, gpu_uuid)
    if any(entry["vf_bdf"] == vf and entry["pf"] != pf for entry in state["entries"]):
        raise StateError(f"{vf}: The VF now belongs to a different physical GPU.")
    entries = [entry for entry in state["entries"]
               if (entry["pf"], entry["vf_index"]) != (pf, index) and entry["vf_bdf"] != vf]
    if profile is not None:
        entry = {"pf": pf, "gpu_uuid": gpu_uuid, "vf_index": index, "vf_bdf": vf, "profile": profile}
        if gi_start is not None:
            entry["gi_start"] = gi_start
        entries.append(entry)
    return normalize_state({**updated, "entries": entries})


def save_and_apply(path, before, desired, apply, readback, original, expected):
    """Record desired state first and roll back only when hardware is still at baseline."""
    changed = desired != before
    if changed:
        save_state(path, desired)
    if original == expected:
        return
    try:
        apply()
        if readback() != expected:
            raise StateError("Unable to verify the GPU change.")
    except READ_ERRORS as exc:
        try:
            actual = readback()
        except READ_ERRORS:
            actual = None
        if actual == original:
            if changed:
                save_state(path, before)
            raise
        if actual == expected:
            return
        raise StateError(f"The restore configuration was saved. Refresh to check whether the GPU change took effect. {exc}") from exc


def initialize(path, hw, adopt=False, legacy=LEGACY_STORE, *, require_vfs=False):
    if path.exists():
        state = load_state(path)
        pfs = set(state["enabled_pfs"]) | set(state.get("mig_pfs", {}))
        if pfs:
            check_legacy(pfs, legacy)
        return state
    state = {"version": 1, "enabled_pfs": {}, "entries": []}
    if not adopt:
        save_state(path, state)
        return state

    inventory = hw.gpus()
    for pf in sorted(inventory):
        if not inventory[pf]["sriov"]:
            continue
        present = []
        for index, vf in hw.vfs(pf):
            device = hw.devices / vf
            settings = device / "nvidia"
            if (settings / "current_vgpu_type").is_file() and not (device / "mdev_supported_types").is_dir():
                present.append((index, vf, hw.current(settings)))
        mig_enabled = inventory[pf].get("mig_mode", "").lower() == "enabled"
        if not present and not (mig_enabled and mig.supported(inventory[pf]["name"])):
            continue
        check_legacy((pf,), legacy)
        gpu_uuid = gpu_identity(hw, pf, inventory, allow_mig=mig_enabled)
        gi_starts = {}
        if mig_enabled:
            if mig.mode(hw.run, pf) != ("enabled", "enabled"):
                raise StateError(f"{pf}: MIG mode is not ready")
            instances = mig.instances(hw.run, pf)
            cis = mig.compute_instances(hw.run, pf) if instances else []
            if any(not mig.default_ci(row, [ci for ci in cis if ci["gi"] == row["id"]]) for row in instances):
                raise StateError(f"{pf}: only GIs with a default CI can be adopted")
            gi_starts = {row["id"]: row["start"] for row in instances}
            config = {"gpu_uuid": gpu_uuid, "instances": [mig.geometry(row) for row in instances]}
            state = normalize_state({**state, "version": 2, "mig_pfs": {**state.get("mig_pfs", {}), pf: config}})
        if present:
            state = with_enabled_pf(state, pf, gpu_uuid)
            if not mig_enabled:
                mode = mig.size_status(hw.run, pf)["current"]
                if mode == "mixed":
                    state = with_size_mode(state, pf, gpu_uuid, mode)
        names = hw.supported(pf) if any(number for _, _, number in present) else {}
        for index, vf, number in present:
            if number:
                if number not in names:
                    raise StateError(f"{vf}: Unable to resolve the name of existing profile ID {number}.")
                gi_start = None
                if mig_enabled:
                    gi = mig.vf_gi(hw.devices / vf / "nvidia")
                    if gi not in gi_starts:
                        raise StateError(f"{vf}: the vGPU's GI cannot be identified")
                    gi_start = gi_starts[gi]
                state = with_profile(state, pf, gpu_uuid, index, vf, names[number], gi_start)
    if require_vfs and not state["enabled_pfs"]:
        raise StateError("No active VFs were found. Check the active configuration before switching the restore service.")
    save_state(path, state)
    return state


def vf_profiles(hw, pf):
    for index, vf in hw.vfs(pf):
        entry = {"pf": pf, "vf_index": index, "vf_bdf": vf}
        path = hw.vf_path(entry, time.monotonic())
        yield vf, path, hw.current(path)


def with_size_mode(state, pf, gpu_uuid, selected):
    updated = with_enabled_pf(state, pf, gpu_uuid)
    modes = {**updated.get("size_modes", {}), pf: {"gpu_uuid": gpu_uuid, "mode": selected}}
    return normalize_state({**updated, "version": 3, "size_modes": modes})


def restore_mig(pf, config, entries, enabled, hw, deadline):
    current, pending = mig.mode(hw.run, pf)
    if current == "disabled" and pending == "disabled":
        # An out-of-band mode change can leave active non-MIG VFs on this PF.
        for vf, _, profile in vf_profiles(hw, pf):
            if profile:
                raise StateError(f"{vf}: an existing VF type prevents restoring MIG mode")
        mig.change_mode(hw.run, pf, True)
    elif (current, pending) != ("enabled", "enabled"):
        raise StateError(f"{pf}: MIG state is {current} (pending: {pending})")
    gi_ids = {}
    for row in config["instances"]:
        instance = mig.find_instance(hw.run, pf, row)
        if instance is not None and not mig.compute_instances(hw.run, pf, instance["id"]):
            for vf, path, profile in vf_profiles(hw, pf):
                if profile and mig.vf_gi(path) == instance["id"]:
                    raise StateError(f"{vf}: configured vGPU prevents repairing its compute instance")
        gi_ids[row["start"]] = mig.ensure_instance(hw.run, pf, row)
    if enabled:
        hw.enable_vfs(pf)
        if not hw.vfs(pf):
            raise StateError(f"{pf}: SR-IOV VFs are missing after MIG restore")
    for entry in entries:
        path = hw.vf_path(entry, min(deadline, time.monotonic() + 30))
        expected = gi_ids[entry["gi_start"]]
        current = hw.current(path)
        if current:
            if hw.supported(pf).get(current) != entry["profile"] or mig.vf_gi(path) != expected:
                raise StateError(f"{entry['vf_bdf']}: existing vGPU profile or GI differs from saved state")
        else:
            number = hw.creatable(path).get(entry["profile"])
            if number is None:
                raise StateError(f"{entry['vf_bdf']}: {entry['profile']} is not currently creatable")
            create_mig_profile(hw, path, number, expected)
        print(f"OK {entry['vf_bdf']}: {entry['profile']} (GI {expected})", flush=True)


def create_mig_profile(hw, path, number, gi):
    try:
        hw.write_type(path, number)
        if hw.current(path) != number:
            raise StateError(f"{path}: could not verify the new vGPU type")
        mig.place_vf(path, gi)
    except READ_ERRORS:
        if hw.current(path) == number:
            # Roll back only the profile created by this operation.
            (path / "current_vgpu_type").write_text("0\n")
        raise


def restore_saved(path, hw, legacy=LEGACY_STORE, timeout=180):
    state = load_state(path)
    mig_pfs = state.get("mig_pfs", {})
    pfs = {**state["enabled_pfs"], **{pf: config["gpu_uuid"] for pf, config in mig_pfs.items()}}
    if not pfs:
        print("No saved GPU configuration", flush=True)
        return
    check_legacy(pfs, legacy)
    deadline = time.monotonic() + timeout
    # At boot the driver can be initializing even after its service is runnable.
    ready_deadline = min(deadline, time.monotonic() + 45)
    while True:
        try:
            inventory = hw.gpus()
            pending = [pf for pf in pfs if pf not in inventory or not (hw.devices / pf / "driver").is_symlink()]
            if pending:
                raise StateError("Unable to verify the saved GPUs. " + ", ".join(pending))
            break
        except READ_ERRORS:
            if time.monotonic() >= ready_deadline:
                raise
            time.sleep(1)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise StateError("Timed out waiting for GPU initialization.")
    for pf, uuid in pfs.items():
        if gpu_identity(hw, pf, inventory, allow_mig=pf in mig_pfs) != uuid:
            raise StateError(f"{pf}: GPU UUID mismatch")
    time_sliced = {pf: uuid for pf, uuid in pfs.items() if pf not in mig_pfs}
    if time_sliced:
        entries = [entry for entry in state["entries"] if entry["pf"] in time_sliced]
        # VF enablement must precede heterogeneous mode, which must precede profiles.
        for pf in time_sliced:
            config = state.get("size_modes", {}).get(pf)
            if config:
                hw.enable_vfs(pf)
                status = mig.size_status(hw.run, pf)
                if status["current"] != config["mode"] and any(number for _, _, number in vf_profiles(hw, pf)):
                    raise StateError(f"{pf}: existing vGPUs prevent restoring the saved size mode")
                mig.change_size_mode(hw.run, pf, config["mode"])
        _restore["restore"](entries, hw, enabled_pfs=time_sliced, timeout=remaining)
    for pf, config in mig_pfs.items():
        entries = [entry for entry in state["entries"] if entry["pf"] == pf]
        restore_mig(pf, config, entries, pf in state["enabled_pfs"], hw, deadline)
    for pf in state["enabled_pfs"]:
        if not hw.vfs(pf):
            raise StateError(f"{pf}: Unable to verify VFs after restore.")
        print(f"OK {pf}: SR-IOV VF enabled", flush=True)
