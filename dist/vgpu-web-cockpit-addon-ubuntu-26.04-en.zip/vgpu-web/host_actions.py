"""Perform explicitly requested NVIDIA vGPU changes on the local KVM host."""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
from uuid import UUID, uuid4
from xml.dom import minidom
from xml.parsers.expat import ExpatError
import xml.etree.ElementTree as ET


# The installed helper is started with Python's isolated mode. Import only
# the shared inventory code beside the root-owned copy of this file.
if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from inventory import READ_ERRORS, normalize_bdf, pci_source_bdf, read_profiles, read_vm_assignments
import mig
from gpu_state import (
    Hardware, LEGACY_STORE, STORE, check_legacy, create_mig_profile, gpu_identity, initialize,
    load_state, normalize_state, restore_saved, save_and_apply, save_state, vf_profiles, with_enabled_pf, with_profile, with_size_mode,
)


DEVICES = Path("/sys/bus/pci/devices")
LOCK_PATH = Path("/run/lock/nvidia-vgpu-persist.lock")
SRIOV_MANAGE = "/usr/lib/nvidia/sriov-manage"
LIBVIRT = ["/usr/bin/virsh", "--connect", "qemu:///system"]
REQUEST_FIELDS = {
    "check": set(),
    "restore-state": set(),
    "set-restore": {"pf", "kind", "key", "enabled"},
    "enable-vfs": {"pf"},
    "set-profile": {"pf", "vf", "profile_id"},
    "set-mig-profile": {"pf", "vf", "profile_id", "gi_start"},
    "set-mig-mode": {"pf", "enabled"},
    "set-mode": {"pf", "mode"},
    "create-gi": {"pf", "gi_profile", "gi_start", "gi_size"},
    "delete-gi": {"pf", "gi_profile", "gi_start", "gi_size"},
    "clear-profile": {"pf", "vf", "profile_id"},
    "attach": {"pf", "vf", "vm_uuid", "profile_id"},
    "detach": {"pf", "vf", "vm_uuids"},
    "set-unmanaged": {"pf", "vf", "vm_uuid", "profile_id"},
}


class HostActionError(RuntimeError):
    pass


ACTION_ERRORS = READ_ERRORS + (KeyError, TypeError, AttributeError, ExpatError)


def trusted_runner(timeout=70):
    deadline = time.monotonic() + timeout

    def run(args):
        program = "/usr/bin/virsh" if args[0] == "virsh" else args[0]
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise HostActionError("The host operation timed out. Refresh to check the current state.")
        result = subprocess.run(
            [program, *args[1:]], cwd="/", capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=min(remaining, 25),
            env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C", "LC_ALL": "C", "HOME": "/root"},
        )
        if result.returncode:
            raise HostActionError((result.stderr or result.stdout).strip() or f"{program}: exit {result.returncode}")
        return result.stdout

    return run


@contextmanager
def operation_lock():
    import fcntl

    fd = os.open(LOCK_PATH, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != 0 or not stat.S_ISREG(info.st_mode) or info.st_mode & 0o022:
            raise HostActionError("Check the lock file ownership and permissions.")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise HostActionError("Another vGPU operation is in progress. Refresh after it finishes.") from exc
        yield
    finally:
        os.close(fd)


def validate_request(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("action"), str):
        raise HostActionError("Invalid operation request.")
    action = payload["action"]
    if action not in REQUEST_FIELDS or payload.keys() - {"action"} != REQUEST_FIELDS[action]:
        raise HostActionError("Unsupported operation or input field.")
    for key in ("pf", "vf"):
        if key in payload:
            payload[key] = normalize_bdf(payload[key])
    if "vm_uuid" in payload:
        payload["vm_uuid"] = str(UUID(payload["vm_uuid"]))
    if "vm_uuids" in payload:
        targets = payload["vm_uuids"]
        if not isinstance(targets, list) or not targets or not all(isinstance(value, str) for value in targets):
            raise HostActionError("Invalid confirmation for the VMs to detach.")
        normalized = [str(UUID(value)) for value in targets]
        if len(set(normalized)) != len(normalized):
            raise HostActionError("The VM confirmation list contains duplicates.")
        payload["vm_uuids"] = normalized
    if "profile_id" in payload:
        value = payload["profile_id"]
        if type(value) is not int or not 0 < value <= 2**31 - 1:
            raise HostActionError("Invalid profile ID.")
    for key, minimum in (("gi_start", 0), ("gi_size", 1)):
        if key in payload and (type(payload[key]) is not int or not minimum <= payload[key] < 2**31):
            raise HostActionError("Invalid GI placement")
    if "gi_profile" in payload and (not isinstance(payload["gi_profile"], str)
                                    or not re.fullmatch(mig.PROFILE_NAME, payload["gi_profile"])):
        raise HostActionError("Invalid GI profile name")
    if "enabled" in payload and type(payload["enabled"]) is not bool:
        raise HostActionError("Invalid MIG mode")
    if action == "set-restore":
        if (payload["kind"] not in ("mig", "gi", "vfs", "profile", "size-mode")
                or type(payload["key"]) is not int or not 0 <= payload["key"] < 2**31):
            raise HostActionError("Invalid restore target")
    if action == "set-mode" and payload["mode"] not in ("equal", "mixed", "mig"):
        raise HostActionError("Invalid configuration mode")
    return payload


def check_pf(devices, address):
    pf = devices / address
    if ((pf / "physfn").exists() or (pf / "vendor").read_text().strip().lower() != "0x10de"
            or (pf / "driver").resolve(strict=True).name != "nvidia"
            or int((pf / "sriov_totalvfs").read_text()) <= 0):
        raise HostActionError(f"{address}: Unable to verify this device as an NVIDIA SR-IOV GPU PF.")
    return pf


def vf_directory(devices, pf, address):
    vf = (devices / address).resolve(strict=True)
    if ((vf / "physfn").resolve(strict=True) != pf.resolve(strict=True)
            or not any(link.resolve(strict=True) == vf for link in pf.glob("virtfn*")
                       if re.fullmatch(r"virtfn\d+", link.name))):
        raise HostActionError(f"{address}: This VF belongs to a different GPU.")
    path = vf / "nvidia"
    if not (path / "current_vgpu_type").is_file() or (vf / "mdev_supported_types").is_dir():
        raise HostActionError(f"{address}: Unable to verify NVIDIA vendor-specific VFIO.")
    return path


def domain_snapshot(runner):
    warnings = []
    domains = read_vm_assignments(runner, warnings)
    if not domains["complete"]:
        raise HostActionError("Unable to verify VM references. " + " / ".join(warnings[:3]))
    return domains


def stopped_vms(runner):
    return set(runner([*LIBVIRT, "list", "--inactive", "--persistent", "--without-managed-save", "--uuid"]).split())


def check_stopped(vm_uuid, runner):
    if vm_uuid not in stopped_vms(runner):
        raise HostActionError("Select a stopped VM with a persistent definition. Resume any VM with a managed save and shut it down first.")


def current_profile(path):
    value = (path / "current_vgpu_type").read_text().strip()
    if not re.fullmatch(r"\d+", value):
        raise HostActionError(f"Unable to verify the current profile ID. {value!r}")
    return int(value)


def write_profile(path, profile_id):
    (path / "current_vgpu_type").write_text(str(profile_id) + "\n")
    if current_profile(path) != profile_id:
        raise HostActionError("Unable to verify the write. Refresh to check the current state.")


def find_hostdev(xml, address):
    document = minidom.parseString(xml)
    devices = next(
        (node for node in document.documentElement.childNodes
         if node.nodeType == node.ELEMENT_NODE and node.tagName == "devices"), None,
    )
    candidates = [] if devices is None else [
        node for node in devices.childNodes
        if node.nodeType == node.ELEMENT_NODE and node.tagName == "hostdev"
        and node.getAttribute("type") == "pci"
        and pci_source_bdf(ET.fromstring(node.toxml())) == address
    ]
    if len(candidates) > 1:
        raise HostActionError(f"{address} appears more than once in the same VM definition.")
    return document, candidates[0] if candidates else None


def new_hostdev(address):
    domain, bus, slot, function = re.split(r"[:.]", address)
    hostdev = ET.Element("hostdev", mode="subsystem", type="pci", managed="no")
    ET.SubElement(ET.SubElement(hostdev, "source"), "address",
                  domain=f"0x{domain}", bus=f"0x{bus}", slot=f"0x{slot}", function=f"0x{function}")
    return ET.tostring(hostdev, encoding="unicode")


def change_vm(action, vf, vm_uuid, refs, runner):
    def dump():
        return runner([*LIBVIRT, "dumpxml", "--inactive", vm_uuid])

    check_stopped(vm_uuid, runner)
    before = dump()
    document, node = find_hostdev(before, vf)
    if action == "attach":
        if refs or node is not None:
            raise HostActionError(f"A VM references {vf}.")
        xml, command = new_hostdev(vf), "attach-device"
    else:
        if node is None:
            if action == "detach":
                return
            raise HostActionError(f"The selected VM has no PCI hostdev entry for {vf}.")
        if any(ref["scope"] == "live" for ref in refs):
            raise HostActionError(f"Shut down the running VMs that reference {vf}.")
        if action == "detach":
            xml, command = node.toxml(), "detach-device"
        else:
            if any(ref["uuid"] != vm_uuid for ref in refs):
                raise HostActionError(f"Another VM definition also references {vf}.")
            node.setAttribute("managed", "no")
            xml, command = document.toxml(), "define"
    check_stopped(vm_uuid, runner)
    if dump() != before:
        raise HostActionError("The VM definition changed during the operation. Refresh and try again.")
    with TemporaryDirectory(prefix="vgpu-web-") as directory:
        config = Path(directory) / "device.xml"
        config.write_text(xml, encoding="utf-8")
        args = ["define", str(config), "--validate"] if command == "define" else [
            command, vm_uuid, str(config), "--config",
        ]
        runner([*LIBVIRT, *args])
    _, saved = find_hostdev(dump(), vf)
    if (saved is not None if action == "detach"
            else saved is None or saved.getAttribute("managed") != "no"):
        raise HostActionError("Unable to verify the persistent VM XML. Refresh to check the current state.")


def detach_vf(vf, refs, confirmed_vms, runner):
    if not refs:
        return f"{vf}: Already detached from all VMs."
    if any(ref["scope"] == "live" for ref in refs):
        raise HostActionError(f"Shut down the running VMs that reference {vf}.")
    vm_uuids = {ref["uuid"] for ref in refs}
    if not vm_uuids.issubset(confirmed_vms):
        raise HostActionError(f"The VM references for {vf} changed. Refresh and confirm the current list.")
    if len(vm_uuids) != len(refs) or any(ref["element"] != "hostdev" for ref in refs):
        raise HostActionError(f"Check that each VM definition has one PCI hostdev entry for {vf}.")
    stopped = stopped_vms(runner)
    blocked = [ref["vm"] for ref in refs if ref["uuid"] not in stopped]
    if blocked:
        raise HostActionError("Verify shutdown and managed save status for these VMs: " + ", ".join(blocked))

    detached = []
    for ref in refs:
        try:
            change_vm("detach", vf, ref["uuid"], refs, runner)
        except READ_ERRORS + (ExpatError,) as exc:
            progress = "Already detached from: " + ", ".join(detached) + "." if detached else ""
            raise HostActionError(f"{vf}: Unable to verify detachment from {ref['vm']}. {progress} {exc}") from exc
        detached.append(ref["vm"])
    remaining = domain_snapshot(runner)["pci"].get(vf, [])
    if remaining:
        names = list(dict.fromkeys(ref["vm"] for ref in remaining))
        raise HostActionError(f"{vf}: VM references remain after detachment. Refresh and review these VMs: " + ", ".join(names))
    return f"{vf}: Detached from " + ", ".join(detached) + "."


def save_profile(state_path, hw, pf, vf, path, name, current, selected, legacy, instance=None):
    check_legacy((pf,), legacy)
    previous = load_state(state_path)
    mig_config = previous.get("mig_pfs", {}).get(pf)
    gpu_uuid = gpu_identity(hw, pf, allow_mig=mig_config is not None)
    if mig_config is not None and mig.mode(hw.run, pf) != ("enabled", "enabled"):
        raise HostActionError(f"{pf}: enable MIG mode before changing a VF type")
    if name is not None and (instance is None) != (mig_config is None):
        raise HostActionError(f"{pf}: the requested profile does not match the saved GPU mode")
    indexes = [index for index, address in hw.vfs(pf) if address == vf]
    if len(indexes) != 1:
        raise HostActionError(f"{vf}: Unable to identify a unique VF index to save.")
    desired = with_profile(previous, pf, gpu_uuid, indexes[0], vf, name,
                           gi_start=instance["start"] if instance is not None else None)
    if instance is None:
        if name is not None:
            observed = mig.size_status(hw.run, pf)["current"]
            if observed is None:
                raise HostActionError(f"{pf}: could not confirm the current size mode")
            if observed == "mixed" or pf in previous.get("size_modes", {}):
                desired = with_size_mode(desired, pf, gpu_uuid, observed)
        save_and_apply(state_path, previous, desired, lambda: write_profile(path, selected),
                       lambda: current_profile(path), current, selected)
        return
    gi = instance["id"]
    actual = (current, mig.vf_gi(path) if current else None)
    if current and actual != (selected, gi):
        raise HostActionError(f"{vf}: the existing vGPU has a different profile or GI")

    def readback():
        number = current_profile(path)
        return (number, mig.vf_gi(path) if number else None)

    save_and_apply(state_path, previous, desired, lambda: create_mig_profile(hw, path, selected, gi),
                   readback, actual, (selected, gi))


def set_mig_mode(request, hw, pf, state_path, legacy):
    enabled = request["enabled"]
    uuid = gpu_identity(hw, pf, allow_mig=True)
    check_legacy((pf,), legacy)
    state = load_state(state_path)
    configs = dict(state.get("mig_pfs", {}))
    config = configs.get(pf)
    if (config and config["gpu_uuid"] != uuid) or state["enabled_pfs"].get(pf, uuid) != uuid:
        raise HostActionError(f"{pf}: saved GPU UUID differs from hardware")
    entries = [entry for entry in state["entries"] if entry["pf"] == pf]
    if enabled and config is None and entries:
        raise HostActionError(f"{pf}: detach and clear the saved time-sliced vGPUs first")
    if not enabled and config and (config["instances"] or entries):
        raise HostActionError(f"{pf}: clear the saved vGPUs and delete the saved GPU instances first")
    expected = "enabled" if enabled else "disabled"
    before = mig.mode(hw.run, pf)
    if any(value not in ("enabled", "disabled") for value in before):
        raise HostActionError(f"{pf}: could not confirm current and pending MIG modes")
    if before[0] != expected:
        vfs = hw.vfs(pf)
        refs = domain_snapshot(hw.run)["pci"]
        if any(refs.get(address) for address in (pf, *(vf for _, vf in vfs))):
            raise HostActionError(f"{pf}: remove VM references to this GPU and its VFs first")
        for vf, _, profile in vf_profiles(hw, pf):
            if profile:
                raise HostActionError(f"{vf}: clear the vGPU type before changing MIG mode")
        if before[0] == "enabled" and not enabled and mig.instances(hw.run, pf):
            raise HostActionError(f"{pf}: delete the GPU instances before disabling MIG mode")
    if enabled:
        configs[pf] = config or {"gpu_uuid": uuid, "instances": []}
    else:
        configs.pop(pf, None)
    modes = {p: c for p, c in state.get("size_modes", {}).items() if not (enabled and p == pf)}
    desired = normalize_state({**state, "version": 2, "mig_pfs": configs, "size_modes": modes})
    save_and_apply(state_path, state, desired, lambda: mig.change_mode(hw.run, pf, enabled),
                   lambda: mig.mode(hw.run, pf), before, (expected, expected))
    return f"{pf}: MIG mode {expected}"


def configured_mig(hw, pf, state):
    config = state.get("mig_pfs", {}).get(pf)
    if config is None:
        raise HostActionError(f"{pf}: save MIG mode in Cockpit first")
    if gpu_identity(hw, pf, allow_mig=True) != config["gpu_uuid"]:
        raise HostActionError(f"{pf}: saved GPU UUID differs from hardware")
    if mig.mode(hw.run, pf) != ("enabled", "enabled"):
        raise HostActionError(f"{pf}: MIG mode is not ready")
    return config


def change_gi(request, hw, pf, state_path, legacy):
    check_legacy((pf,), legacy)
    state = load_state(state_path)
    original_state = state
    # A CLI-enabled GPU can be active without a saved MIG mode. GI management
    # must validate live mode, rather than require an unrelated checkbox first.
    if pf not in state.get("mig_pfs", {}):
        uuid = gpu_identity(hw, pf, allow_mig=True)
        if mig.mode(hw.run, pf) != ("enabled", "enabled"):
            raise HostActionError(f"{pf}: MIG mode is not ready")
        if any(entry["pf"] == pf for entry in state["entries"]):
            raise HostActionError(f"{pf}: remove incompatible saved vGPU targets first")
        modes = {p: value for p, value in state.get("size_modes", {}).items() if p != pf}
        state = normalize_state({**state, "version": 3, "size_modes": modes,
                                 "mig_pfs": {**state.get("mig_pfs", {}),
                                             pf: {"gpu_uuid": uuid, "instances": []}}})
    config = configured_mig(hw, pf, state)
    desired_gi = {"profile": request["gi_profile"], "start": request["gi_start"], "size": request["gi_size"]}
    layout = config["instances"]
    instance = mig.find_instance(hw.run, pf, desired_gi)
    cis = []
    creating = request["action"] == "create-gi"
    if creating:
        if not desired_gi["profile"].lower().endswith("+gfx"):
            raise HostActionError("Only graphics GI profiles can be created for vGPU")
        if any(mig.overlaps(row, desired_gi) and row != desired_gi for row in layout):
            raise HostActionError(f"{pf}: the requested GI overlaps a saved placement")
        if instance is None and not any(mig.can_create(p, desired_gi) for p in mig.profiles(hw.run, pf)):
            raise HostActionError(f"{pf}: the requested GI and placement are not available")
        layout = layout if desired_gi in layout else [*layout, desired_gi]
    else:
        if any(entry["pf"] == pf and entry["gi_start"] == desired_gi["start"] for entry in state["entries"]):
            raise HostActionError(f"{pf}: clear vGPU types saved on this GI first")
        layout = [row for row in layout if row != desired_gi]
    if instance is not None:
        cis = mig.compute_instances(hw.run, pf, instance["id"])
        if creating and cis and not mig.default_ci(instance, cis):
            raise HostActionError(f"{pf}: the existing GI must have one default compute instance")
        if not creating or not cis:
            for vf, path, profile in vf_profiles(hw, pf):
                if profile and mig.vf_gi(path) == instance["id"]:
                    raise HostActionError(f"{vf}: clear the vGPU type on this GI before changing its instances")
    desired = normalize_state({**state, "mig_pfs": {**state["mig_pfs"], pf: {**config, "instances": layout}}})
    if not creating and pf not in original_state.get("mig_pfs", {}):
        desired = original_state
    if creating:
        def readback():
            actual = mig.find_instance(hw.run, pf, desired_gi)
            if actual is None:
                return "missing"
            return "ready" if mig.default_ci(actual, mig.compute_instances(hw.run, pf, actual["id"])) else "incomplete"

        before = "missing" if instance is None else "ready" if cis else "incomplete"
        save_and_apply(state_path, original_state, desired, lambda: mig.ensure_instance(hw.run, pf, desired_gi),
                       readback, before, "ready")
        gi = mig.find_instance(hw.run, pf, desired_gi)["id"]
        return f"{pf}: GI {gi} saved ({desired_gi['profile']}, placement {desired_gi['start']})"

    def remove():
        gi = str(instance["id"])
        for ci in cis:
            mig.run_mig(hw.run, pf, "-dci", "-gi", gi, "-ci", str(ci["id"]))
        mig.run_mig(hw.run, pf, "-dgi", "-gi", gi)

    save_and_apply(state_path, original_state, desired, remove, lambda: mig.find_instance(hw.run, pf, desired_gi) is not None,
                   instance is not None, False)
    return f"{pf}: GI at placement {desired_gi['start']} removed"


def set_configuration_mode(request, hw, pf, state_path, legacy):
    selected = request["mode"]
    check_legacy((pf,), legacy)
    info = hw.gpus()
    mig_capable = mig.supported(info.get(pf, {}).get("name", ""))
    if selected == "mig" and not mig_capable:
        raise HostActionError(f"{pf}: MIG configuration is not supported for this GPU")
    gpu_uuid = gpu_identity(hw, pf, info, allow_mig=mig_capable)
    mig_state = mig.mode(hw.run, pf) if mig_capable else ("disabled", "disabled")
    if mig_state[0] != mig_state[1] or mig_state[0] not in ("enabled", "disabled"):
        raise HostActionError(f"{pf}: resolve the pending MIG mode first")
    status = mig.size_status(hw.run, pf)
    original = "mig" if mig_state[0] == "enabled" else status["current"]
    if original is None:
        raise HostActionError(f"{pf}: could not confirm the current configuration mode")
    if selected == "mixed" and status["supported"] is not True:
        raise HostActionError(f"{pf}: Mixed-Size support could not be confirmed")
    state = load_state(state_path)
    if (state["enabled_pfs"].get(pf, gpu_uuid) != gpu_uuid
            or state.get("mig_pfs", {}).get(pf, {}).get("gpu_uuid", gpu_uuid) != gpu_uuid):
        raise HostActionError(f"{pf}: saved GPU UUID differs from hardware")
    configs = dict(state.get("mig_pfs", {}))
    modes = dict(state.get("size_modes", {}))
    if selected != original:
        refs = domain_snapshot(hw.run)["pci"]
        addresses = [pf, *(vf for _, vf in hw.vfs(pf))]
        blockers = [address for address in addresses if refs.get(address)]
        profiles = [vf for vf, _, number in vf_profiles(hw, pf) if number]
        saved = [entry["vf_bdf"] for entry in state["entries"] if entry["pf"] == pf]
        if blockers or profiles or saved:
            raise HostActionError("Remove VM references, current vGPU types and saved vGPU targets first: "
                                  + ", ".join(sorted(set(blockers + profiles + saved))))
        if original == "mig" and (mig.instances(hw.run, pf) or configs.get(pf, {}).get("instances")):
            raise HostActionError(f"{pf}: delete existing and saved GIs before changing mode")
    if selected == "mig":
        modes.pop(pf, None)
        configs[pf] = configs.get(pf, {"gpu_uuid": gpu_uuid, "instances": []})
        desired = normalize_state({**state, "version": 3, "mig_pfs": configs, "size_modes": modes})
    else:
        configs.pop(pf, None)
        desired = with_size_mode({**state, "mig_pfs": configs}, pf, gpu_uuid, selected)

    def apply():
        if selected == "mig":
            if status["current"] == "mixed":
                mig.change_size_mode(hw.run, pf, "equal")
            mig.change_mode(hw.run, pf, True)
        else:
            if original == "mig":
                mig.change_mode(hw.run, pf, False)
            hw.enable_vfs(pf)
            mig.change_size_mode(hw.run, pf, selected)

    def readback():
        if mig_capable and mig.mode(hw.run, pf) == ("enabled", "enabled"):
            return "mig"
        return mig.size_status(hw.run, pf)["current"]

    save_and_apply(state_path, state, desired, apply, readback, original, selected)
    return f"{pf}: configuration mode {selected}; startup restore settings updated."


def set_restore(request, hw, pf, state_path, legacy):
    """Change startup intent only; never change the running GPU configuration."""
    check_legacy((pf,), legacy)
    state = load_state(state_path)
    kind, key, enabled = request["kind"], request["key"], request["enabled"]
    config = state.get("mig_pfs", {}).get(pf)
    uuid = gpu_identity(hw, pf, allow_mig=config is not None or kind == "mig"
                        or hw.gpus().get(pf, {}).get("mig_mode", "").lower() == "enabled")
    if state["enabled_pfs"].get(pf, uuid) != uuid or (config and config["gpu_uuid"] != uuid):
        raise HostActionError("Saved GPU identity differs from hardware")
    configs = dict(state.get("mig_pfs", {}))
    desired = {**state, "version": 2, "mig_pfs": configs}
    if kind == "mig":
        if enabled:
            if mig.mode(hw.run, pf) != ("enabled", "enabled"):
                raise HostActionError("Enable MIG before selecting startup restore")
            if any(e["pf"] == pf and "gi_start" not in e for e in state["entries"]):
                raise HostActionError("Remove saved time-sliced profiles first")
            if pf in state.get("size_modes", {}):
                raise HostActionError("Uncheck the saved size mode first")
            configs[pf] = config or {"gpu_uuid": uuid, "instances": []}
        else:
            if config and (config["instances"] or any(e["pf"] == pf for e in state["entries"])):
                raise HostActionError("Uncheck dependent vGPU and GI restore settings first")
            configs.pop(pf, None)
    elif kind == "gi":
        if config is None:
            raise HostActionError("Select MIG mode restore first")
        layout = config["instances"]
        if enabled:
            configured_mig(hw, pf, state)
            instance = next((gi for gi in mig.instances(hw.run, pf) if gi["start"] == key), None)
            if instance is None or not mig.default_ci(instance, mig.compute_instances(hw.run, pf, instance["id"])):
                raise HostActionError("Select an existing GI with its default CI")
            geometry = mig.geometry(instance)
            if not geometry["profile"].lower().endswith("+gfx"):
                raise HostActionError("Only graphics GI profiles can be saved for vGPU restore")
            if any(mig.overlaps(row, geometry) and row != geometry for row in layout):
                raise HostActionError("Saved GI layout differs from hardware")
            layout = layout if geometry in layout else [*layout, geometry]
        else:
            if any(e["pf"] == pf and e.get("gi_start") == key for e in state["entries"]):
                raise HostActionError("Uncheck vGPU restore settings on this GI first")
            layout = [row for row in layout if row["start"] != key]
        configs[pf] = {**config, "instances": layout}
    elif kind == "size-mode":
        modes = dict(state.get("size_modes", {}))
        if enabled:
            if config is not None:
                raise HostActionError("Size mode restore is not available for a saved MIG GPU")
            current_mode = mig.size_status(hw.run, pf)["current"]
            if current_mode not in ("equal", "mixed"):
                raise HostActionError("Could not confirm current size mode")
            desired = with_size_mode(desired, pf, uuid, current_mode)
        else:
            if any(e["pf"] == pf for e in state["entries"]):
                raise HostActionError("Uncheck dependent vGPU restore settings first")
            modes.pop(pf, None)
            desired["size_modes"] = modes
    elif kind == "vfs":
        if enabled:
            if not hw.vfs(pf):
                raise HostActionError("Enable VFs before selecting startup restore")
            desired = with_enabled_pf(desired, pf, uuid)
        else:
            if any(e["pf"] == pf for e in state["entries"]) or pf in state.get("size_modes", {}):
                raise HostActionError("Uncheck vGPU restore settings first")
            desired["enabled_pfs"] = {p: u for p, u in state["enabled_pfs"].items() if p != pf}
    else:
        entries = [e for e in state["entries"] if not (e["pf"] == pf and e["vf_index"] == key)]
        if enabled:
            vf = next((vf for index, vf in hw.vfs(pf) if index == key), None)
            if vf is None:
                raise HostActionError("VF is unavailable")
            path = hw.vf_path({"pf": pf, "vf_index": key, "vf_bdf": vf}, time.monotonic())
            number = hw.current(path)
            name = hw.supported(pf).get(number) if number else None
            if not name:
                raise HostActionError("Current vGPU profile is unavailable")
            gi_start = None
            if hw.gpus().get(pf, {}).get("mig_mode", "").lower() == "enabled":
                configured_mig(hw, pf, state)
                gi_id = mig.vf_gi(path)
                instance = next((gi for gi in mig.instances(hw.run, pf) if gi["id"] == gi_id), None)
                if instance is None or mig.geometry(instance) not in config["instances"]:
                    raise HostActionError("Select the parent GI restore setting first")
                gi_start = instance["start"]
            elif config is not None:
                raise HostActionError("Saved GPU mode differs from hardware")
            desired = with_profile(desired, pf, uuid, key, vf, name, gi_start)
            if gi_start is None:
                observed = mig.size_status(hw.run, pf)["current"]
                if observed is None:
                    raise HostActionError("Could not confirm current size mode")
                if observed == "mixed" or pf in state.get("size_modes", {}):
                    desired = with_size_mode(desired, pf, uuid, observed)
        else:
            desired["entries"] = entries
    save_state(state_path, desired)
    return "Startup restore setting updated; running GPU configuration unchanged."


def perform(payload, devices=DEVICES, runner=None, restore_config=LEGACY_STORE, state_path=STORE):
    request = validate_request(payload)
    action = request["action"]
    if action == "check":
        return "Host operation helper is ready."
    if action == "restore-state":
        return json.dumps(load_state(state_path))
    runner = runner or trusted_runner()
    pf_address = request["pf"]
    pf = check_pf(devices, pf_address)
    hardware = Hardware(devices, runner)
    if action == "set-restore":
        return set_restore(request, hardware, pf_address, state_path, restore_config)
    if action == "set-mode":
        return set_configuration_mode(request, hardware, pf_address, state_path, restore_config)
    if action == "set-mig-mode":
        return set_mig_mode(request, hardware, pf_address, state_path, restore_config)
    if action in ("create-gi", "delete-gi"):
        return change_gi(request, hardware, pf_address, state_path, restore_config)
    if action == "enable-vfs":
        def enabled():
            return int((pf / "sriov_numvfs").read_text()) > 0

        current = enabled()
        if not current and domain_snapshot(runner)["pci"].get(pf_address):
            raise HostActionError(f"A VM references {pf_address}.")
        check_legacy((pf_address,), restore_config)
        previous = load_state(state_path)
        if pf_address in previous.get("mig_pfs", {}):
            gpu_uuid = configured_mig(hardware, pf_address, previous)["gpu_uuid"]
        else:
            gpu_uuid = gpu_identity(hardware, pf_address)
        desired = with_enabled_pf(previous, pf_address, gpu_uuid)
        save_and_apply(state_path, previous, desired, lambda: runner([SRIOV_MANAGE, "-e", pf_address]),
                       enabled, current, True)
        return f"{pf_address}: Saved VF enablement to the restore configuration."

    vf = request["vf"]
    path = vf_directory(devices, pf, vf)
    refs = domain_snapshot(runner)["pci"].get(vf, [])
    if action == "detach":
        return detach_vf(vf, refs, request["vm_uuids"], runner)
    current = current_profile(path)
    selected = request.get("profile_id")
    if action in ("set-profile", "set-mig-profile"):
        instance = None
        if action == "set-mig-profile":
            config = configured_mig(hardware, pf_address, load_state(state_path))
            layout = next((row for row in config["instances"] if row["start"] == request["gi_start"]), None)
            if layout is not None:
                instance = mig.find_instance(runner, pf_address, layout)
            if instance is None or not mig.default_ci(instance, mig.compute_instances(runner, pf_address, instance["id"])):
                raise HostActionError(f"{pf_address}: select a saved GI with a default compute instance")
        if current == selected:
            name = hardware.supported(pf_address).get(selected)
        else:
            if current or refs:
                raise HostActionError(f"{vf}: Select a VF with no type or VM references.")
            names = {profile["id"]: profile["name"] for profile in read_profiles(path / "creatable_vgpu_types")}
            name = names.get(selected)
        if not name:
            raise HostActionError("Unable to verify the selected profile name or availability.")
        live_mode = hardware.gpus().get(pf_address, {}).get("mig_mode", "").lower()
        if (action == "set-mig-profile") != (live_mode == "enabled"):
            raise HostActionError("GPU mode changed. Refresh before choosing a profile.")
        if mig.is_mig_vgpu(name) != (action == "set-mig-profile"):
            raise HostActionError("The selected profile does not belong to the active GPU mode.")
        save_profile(state_path, hardware, pf_address, vf, path, name, current, selected, restore_config, instance)
        return f"{vf}: {name} (ID {selected}) applied. The restore configuration was updated."
    if action == "clear-profile":
        if refs:
            raise HostActionError(f"{vf}: Detach the VF from its VMs before clearing the type.")
        if current and current != selected:
            raise HostActionError("The VF profile changed. Refresh to check the current state.")
        save_profile(state_path, hardware, pf_address, vf, path, None, current, 0, restore_config)
        return f"{vf}: Reset the vGPU type to unset (ID 0) and removed it from the restore configuration."
    if current != selected:
        raise HostActionError("The VF profile changed. Refresh to check the current state.")
    if action == "attach":
        state = load_state(state_path)
        if pf_address in state.get("mig_pfs", {}) or hardware.gpus().get(pf_address, {}).get("mig_mode", "").lower() == "enabled":
            config = configured_mig(hardware, pf_address, state)
            entry = next((row for row in state["entries"] if row["pf"] == pf_address and row["vf_bdf"] == vf), None)
            layout = next((row for row in config["instances"] if entry and row["start"] == entry["gi_start"]), None)
            instance = mig.find_instance(runner, pf_address, layout) if layout else None
            if (instance is None or mig.vf_gi(path) != instance["id"]
                    or hardware.supported(pf_address).get(current) != entry["profile"]
                    or not mig.default_ci(instance, mig.compute_instances(runner, pf_address, instance["id"]))):
                raise HostActionError(f"{vf}: save this vGPU on its current GI before attaching it to a VM")
    change_vm(action, vf, request["vm_uuid"], refs, runner)
    result = {"attach": "Attached with managed=no.", "set-unmanaged": "Updated to managed=no."}
    return f"{vf}: {result[action]}"


def cockpit_operator(loginuid_path=Path("/proc/self/loginuid")):
    import pwd

    try:
        uid = int(loginuid_path.read_text(encoding="ascii"))
    except (OSError, ValueError):
        return {"operator": None, "operator_uid": None}
    if not 0 <= uid < 4294967295:
        return {"operator": None, "operator_uid": None}
    try:
        name = pwd.getpwuid(uid).pw_name
    except KeyError:
        name = None
    return {"operator": name, "operator_uid": uid}


def run_cockpit_operation(request):
    import syslog

    request = validate_request(request)
    record = {"event": "vgpu_operation", "interface": "cockpit", "request_id": str(uuid4()),
              **cockpit_operator(), **request}
    syslog.openlog("vgpu-web-cockpit")

    def audit(result, **detail):
        timestamps = {"timestamp": datetime.now(timezone.utc).isoformat()}
        syslog.syslog(syslog.LOG_INFO, json.dumps({**record, **timestamps, "result": result, **detail},
                                                 separators=(",", ":")))

    audit("started")
    try:
        with operation_lock():
            message = perform(request)
    except ACTION_ERRORS as exc:
        audit("failed", error=str(exc))
        raise
    audit("succeeded", message=message)
    return message


def main():
    args = sys.argv[1:]
    from_cockpit = args == ["--cockpit-operation"]
    try:
        if sys.platform != "linux" or os.geteuid() != 0:
            raise HostActionError("Run with administrative privileges on the Linux host.")
        if args == ["--restore"]:
            with operation_lock():
                restore_saved(STORE, Hardware(DEVICES, trusted_runner(180)))
            return 0
        if args in (["--initialize-state"], ["--initialize-state", "--adopt-current"],
                    ["--initialize-state", "--adopt-current", "--require-vfs"]):
            with operation_lock():
                state = initialize(STORE, Hardware(DEVICES, trusted_runner()),
                                   adopt="--adopt-current" in args, require_vfs="--require-vfs" in args)
            print(f"Restore configuration contains {len(state['enabled_pfs'])} physical GPU(s) and {len(state['entries'])} vGPU type(s).")
            return 0
        if args and not from_cockpit:
            raise HostActionError("Check the host operation options.")
        raw = sys.stdin.buffer.read(4097)
        if len(raw) > 4096:
            raise HostActionError("The input exceeds the maximum size.")
        request = json.loads(raw)
        if from_cockpit:
            message = run_cockpit_operation(request)
        else:
            with operation_lock():
                message = perform(request)
        print(json.dumps({"message": message}))
    except ACTION_ERRORS as exc:
        if args and not from_cockpit:
            print(str(exc), file=sys.stderr)
        else:
            print(json.dumps({"error": str(exc)}))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
