#!/usr/bin/env bash
set -euo pipefail

if [[ -r /etc/os-release ]]; then
    . /etc/os-release
fi
if [[ ${ID:-} != ubuntu || ${VERSION_ID:-} != 26.04 ]]; then
    echo 'This package requires an Ubuntu 26.04 LTS KVM host.' >&2
    exit 1
fi

if [[ ! -x /usr/bin/python3 || ! -x /usr/bin/virsh ]] ||
    { ! systemctl cat virtqemud.service >/dev/null 2>&1 &&
      ! systemctl cat libvirtd.service >/dev/null 2>&1; }; then
    echo 'Set up Python 3 and the libvirt QEMU service first. See INSTALL.md for details.' >&2
    exit 1
fi

if ! command -v nvidia-smi >/dev/null || [[ ! -x /usr/lib/nvidia/sriov-manage ]] ||
    ! systemctl cat nvidia-vgpu-mgr.service >/dev/null 2>&1; then
    echo 'Verify that NVIDIA vGPU Manager for Ubuntu is installed. See INSTALL.md for details.' >&2
    exit 1
fi

exec bash "$(dirname -- "$0")/install-cockpit.sh" "$@"
