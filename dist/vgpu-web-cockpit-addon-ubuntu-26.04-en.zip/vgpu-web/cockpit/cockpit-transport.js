"use strict";

(() => {
  const cockpit = window.cockpit;
  const permission = cockpit?.permission({ admin: true });
  const helper = "/usr/local/libexec/vgpu-web/vgpu-web/";
  const python = "/usr/bin/python3";
  const canWrite = () => permission?.allowed === true;

  window.vgpuTransport = {
    canWrite,
    readOnlyHint: "Read-only · Switch to Administrative access in Cockpit to view or configure GPU and compute instances",
    onPermissionsChanged(callback) {
      permission?.addEventListener("changed", callback);
    },
    async inventory() {
      if (!cockpit) throw new Error("Check the connection to Cockpit.");
      const command = [python, "-I", helper + "inventory.py"];
      if (canWrite()) {
        try {
          const data = JSON.parse(await cockpit.spawn(command, { superuser: "require" }));
          return { ...data, write_enabled: data.is_root === true && canWrite() };
        } catch (error) {
          if (error.problem !== "access-denied") throw error;
        }
      }
      const output = await cockpit.spawn(command);
      return { ...JSON.parse(output), write_enabled: false };
    },
    operate(payload) {
      if (!canWrite()) return Promise.resolve({ error: "Administrative access in Cockpit is required." });
      const process = cockpit.spawn(
        [python, "-I", helper + "host_actions.py", "--cockpit-operation"],
        { superuser: "require" },
      );
      process.input(JSON.stringify(payload));
      return process.then(JSON.parse, (failure, output) => {
        if (failure.problem === "access-denied") {
          return { error: "Administrative access in Cockpit is required." };
        }
        if (output) return JSON.parse(output);
        throw new Error(failure.message);
      });
    },
  };
})();
