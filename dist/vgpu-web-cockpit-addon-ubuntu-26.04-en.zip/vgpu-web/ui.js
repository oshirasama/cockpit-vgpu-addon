"use strict";

const element = (id) => document.getElementById(id);
const interfaces = {
  "vendor-vfio": "NVIDIA vendor-specific VFIO",
  mdev: "mdev",
  both: "vendor-specific VFIO / mdev",
  unobserved: "Interface undetected",
};
const scopes = { live: "Live", config: "Persistent" };
const modeLabels = { equal: "Equal-Size", mixed: "Mixed-Size", mig: "MIG" };
const modeDrafts = new Map();
let inventory = null;
let writing = false;
let refreshForPermissions = false;

const transport = window.vgpuTransport ?? {
  async inventory() {
    const response = await fetch("/api/inventory");
    if (!response.ok) throw new Error("HTTP " + response.status);
    return response.json();
  },
  async operate(payload) {
    const response = await fetch("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VGPU-Request": "1" },
      body: JSON.stringify(payload),
    });
    if (!response.headers.get("Content-Type")?.includes("application/json")) {
      throw new Error("HTTP " + response.status);
    }
    return response.json();
  },
};

function node(tag, text) {
  const item = document.createElement(tag);
  if (text !== undefined) item.textContent = text;
  return item;
}

function list(entries) {
  const item = node("ul");
  for (const entry of entries) item.append(node("li", entry));
  return item;
}

function assignmentLabel(assignment) {
  return assignment.vm + " · " + scopes[assignment.scope] +
    " · " + (assignment.managed === null ? "managed attribute absent" : "managed=" + assignment.managed);
}

function modeProfiles(gpu, vf) {
  const mode = currentMode(gpu);
  if (!mode) return [];
  return (vf.creatable ?? []).filter((profile) =>
    /\bDC-\d+-\d+[ABCQ](?:GFX)?(?:\s|$)/i.test(profile.name) === (mode === "mig"));
}

function profilesCell(vf, gpu) {
  if (modeChangePending(gpu)) return node("span", "Mode change pending");
  if (vf.creatable === null) return node("span", "Unavailable");
  const profiles = modeProfiles(gpu, vf);
  if (profiles.length === 0) return node("span", "None available");
  const details = node("details");
  details.append(
    node("summary", profiles.length + " available"),
    list(profiles.map((profile) => profile.name + " (" + profile.id + ")"))
  );
  return details;
}

function renderGpu(gpu, vmReadComplete) {
  const card = node("article");
  card.className = "card";
  const total = gpu.sriov_total_vfs === null ? "" : " / max " + gpu.sriov_total_vfs;
  const mdev = gpu.pf_mdev ? " · mdev interface on PF" : "";
  card.append(
    node("h2", gpu.name),
    node("p", gpu.bdf + " · Driver " + gpu.driver + " · VF " + gpu.vfs.length + total + mdev)
  );
  card.append(node("p", "Current mode: " + (modeLabels[currentMode(gpu)] ?? "Unavailable")));
  if (gpu.mig) {
    const { current, pending, instances } = gpu.mig;
    card.append(node("p", "MIG · " + (current ?? "Unavailable") + " · Pending · " + (pending ?? "Unavailable")));
    if (instances?.length) {
      card.append(list(instances.map((gi) => giLabel(gi) + " · CI " +
        (gi.compute.map((ci) => ci.id).join(", ") || "None"))));
    }
    if (current === "enabled" && gpu.mig.requires_admin) {
      card.append(node("p", "Viewing GPU and compute instances requires administrative access on the host."));
    }
  }
  if (gpu.vfs.length === 0) {
    const description = gpu.sysfs_visible ? "No enabled VFs detected." : "PCI sysfs is unavailable.";
    card.append(node("p", description));
    return card;
  }

  const table = node("table");
  const headRow = table.createTHead().insertRow();
  const isMig = currentMode(gpu) === "mig";
  const columns = ["VF / PCI BDF", "Interface", "Current profile"];
  if (isMig) columns.push("Parent GI / placement");
  columns.push("Available profiles", "VM references", "Actions");
  for (const label of columns) {
    const header = node("th", label);
    header.scope = "col";
    headRow.append(header);
  }
  const body = table.createTBody();
  for (const vf of gpu.vfs) {
    const row = body.insertRow();
    row.insertCell().textContent = "virtfn" + vf.index + " · " + (vf.bdf ?? "Unavailable");
    row.insertCell().textContent = interfaces[vf.interface];
    const activeProfile = vf.profile_name
      ? vf.profile_name + " (" + vf.profile_id + ")"
      : "ID " + vf.profile_id;
    row.insertCell().textContent = vf.profile_id === null ? "Unavailable" :
      vf.profile_id === 0 ? "Unset" : activeProfile;
    if (isMig) {
      const gi = gpu.mig?.instances?.find((item) => item.id === vf.gi_id);
      row.insertCell().textContent = gi ? "GI " + gi.id + " · " + gi.start + ":" + gi.size :
        vf.profile_id > 0 ? "Unavailable" : "—";
    }
    row.insertCell().append(profilesCell(vf, gpu));
    const assigned = row.insertCell();
    if (vf.assignments.length) assigned.append(list(vf.assignments.map(assignmentLabel)));
    else assigned.textContent = vmReadComplete && vf.bdf ? "None" : "Unverified";
    const action = row.insertCell();
    if (inventory.write_enabled && vf.bdf) action.append(operationButton("Select", () => {
      element("vf-select").value = vf.bdf;
      renderVfActions();
      element("vf-select").focus();
      element("configuration").scrollIntoView({ behavior: "smooth", block: "start" });
      return null;
    }));
  }
  const container = node("div");
  container.className = "table-scroll";
  container.append(table);
  card.append(container);
  return card;
}

function selectedGpu() {
  return inventory?.gpus?.find((gpu) => gpu.bdf === element("gpu-select").value);
}

function option(label, value) {
  const entry = node("option", label);
  entry.value = value;
  return entry;
}

function operationButton(label, buildRequest) {
  const button = node("button", label);
  button.type = "button";
  button.disabled = writing;
  button.addEventListener("click", () => {
    const request = buildRequest();
    if (!request) return;
    const { payload, target } = request;
    submitOperation(label, target, payload);
  });
  return button;
}

function choice(id, label, options) {
  const select = node("select");
  select.id = id;
  select.append(...options);
  const caption = node("label", label);
  caption.htmlFor = id;
  const field = node("div");
  field.className = "operation-field";
  field.append(caption, select);
  return { field, select };
}

function giLabel(gi) {
  return "GI " + gi.id + " · " + gi.profile + " · " + gi.start + ":" + gi.size +
    (gi.profile.toLowerCase().endsWith("+gfx") ? "" : " · No graphics support");
}

function giRequest(action, gpu, gi) {
  return { action, pf: gpu.bdf, gi_profile: gi.profile, gi_start: gi.start, gi_size: gi.size };
}

function currentMode(gpu) {
  if (gpu.mig?.current === "enabled") return "mig";
  if (gpu.mig && gpu.mig.current !== "disabled") return null;
  return gpu.size_mode?.current ?? null;
}

function modeChangePending(gpu) {
  return modeDrafts.has(gpu.bdf) && modeDrafts.get(gpu.bdf) !== currentMode(gpu);
}

function renderModeControls(gpu) {
  const container = element("mode-controls");
  container.replaceChildren();
  const current = currentMode(gpu);
  if (modeDrafts.get(gpu.bdf) === current) modeDrafts.delete(gpu.bdf);
  const draft = modeDrafts.get(gpu.bdf) ?? current;
  container.append(node("p", "Current mode: " + (modeLabels[current] ?? "Unavailable")));
  const fieldset = node("fieldset");
  fieldset.className = "mode-options";
  fieldset.append(node("legend", "Configuration mode"));
  const modes = ["equal", "mixed"];
  if (gpu.mig_supported !== false && (gpu.mig_supported === true || gpu.mig)) modes.push("mig");
  const inputs = [];
  const apply = operationButton("Change mode", () => {
    const mode = inputs.find((input) => input.checked)?.value;
    return { payload: { action: "set-mode", pf: gpu.bdf, mode },
      target: gpu.bdf + " · " + modeLabels[current] + " → " + modeLabels[mode] };
  });
  const notice = node("p");
  notice.className = "mode-notice";
  const update = () => {
    const selected = inputs.find((input) => input.checked)?.value;
    apply.disabled = writing || !inventory.write_enabled || !inventory.vm_read_complete || !current || selected === current;
    notice.textContent = selected && selected !== current ? "Planned change: " + modeLabels[selected] + " · Apply with Change mode. Creation is unavailable until the change is applied." : "";
    if (selected && selected !== current) {
      const saved = inventory.restore_state;
      const blocked = new Set(gpu.vfs.filter((vf) => vf.profile_id > 0 || vf.assignments.length).map((vf) => vf.bdf));
      for (const entry of saved?.entries ?? []) if (entry.pf === gpu.bdf) blocked.add(entry.vf_bdf);
      if (blocked.size) {
        apply.disabled = true;
        notice.textContent += " · First remove VM references, vGPU types and saved vGPU targets: " + [...blocked].join(", ");
      }
      if (current === "mig" && (gpu.mig.instances?.length || saved?.mig_pfs?.[gpu.bdf]?.instances.length)) {
        apply.disabled = true;
        notice.textContent += " · Delete GIs / CIs and saved GI targets first.";
      }
      if (!saved) {
        apply.disabled = true;
        notice.textContent += " · Restore settings unavailable. Refresh to retry.";
      }
    }
  };
  for (const mode of modes) {
    const label = node("label");
    const input = node("input");
    input.type = "radio";
    input.name = "configuration-mode";
    input.value = mode;
    input.checked = mode === draft;
    input.disabled = writing || !inventory.write_enabled || !current ||
      (gpu.mig && gpu.mig.current !== gpu.mig.pending) ||
      (mode === "mixed" && gpu.size_mode?.supported !== true) ||
      (mode === "mig" && !["enabled", "disabled"].includes(gpu.mig?.current));
    input.addEventListener("change", () => {
      modeDrafts.set(gpu.bdf, mode);
      renderSelectedGpu();
    });
    inputs.push(input);
    label.append(input, node("span", modeLabels[mode]));
    fieldset.append(label);
  }
  container.append(fieldset, apply, notice);
  update();
}

function renderMigActions(controls, gpu, creatingAllowed = true) {
  const mig = gpu.mig;
  if (!mig) return true;
  if (!["enabled", "disabled"].includes(mig.current) || !["enabled", "disabled"].includes(mig.pending)) {
    controls.append(node("p", "Refresh to retrieve the current and pending MIG modes."));
    return false;
  }
  const active = mig.current === "enabled";
  if (mig.current !== mig.pending) return false;
  if (!active) return true;
  if (!mig.instances) {
    controls.append(node("p", "Refresh to retrieve GPU and compute instances."));
    return false;
  }
  if (mig.instances.some((gi) => !gi.profile.toLowerCase().endsWith("+gfx"))) {
    controls.append(node("p", "Non-graphics GIs remain and occupy candidate placements. If no longer needed, select them under Existing GI and delete them."));
  }
  const choices = (mig.profiles ?? []).filter((profile) => profile.free > 0).flatMap((profile) =>
    profile.starts.map((start) => ({ profile: profile.profile, start, size: profile.size })));
  if (choices.length && creatingAllowed) {
    const create = choice("new-gi-select", "New GI profile / placement", choices.map((gi, index) =>
      option(gi.profile + " · " + gi.start + ":" + gi.size, index)));
    controls.append(create.field, operationButton("Create GI and default CI", () => {
      const gi = choices[Number(create.select.value)];
      return { payload: giRequest("create-gi", gpu, gi), target: gpu.bdf + " · " + create.select.selectedOptions[0].textContent };
    }));
  }
  if (mig.instances.length) {
    const existing = choice("existing-gi-select", "Existing GI", mig.instances.map((gi, index) => option(giLabel(gi), index)));
    const existingAction = (action) => {
      const gi = mig.instances[Number(existing.select.value)];
      return { payload: giRequest(action, gpu, gi), target: gpu.bdf + " · " + giLabel(gi) };
    };
    controls.append(existing.field,
      operationButton("Delete GI and CIs", () => existingAction("delete-gi")));
  }
  return true;
}

function renderVfActions() {
  renderRestoreSettings(selectedGpu());
  const controls = element("operation-controls");
  controls.replaceChildren();
  const gpu = selectedGpu();
  if (!gpu || !inventory.write_enabled) return;
  renderModeControls(gpu);
  const migControls = element("mig-controls");
  migControls.replaceChildren();
  element("mig-configuration").hidden = currentMode(gpu) !== "mig";
  if (currentMode(gpu) === "mig" && gpu.mig?.instances?.length === 0 && !modeChangePending(gpu)) {
    element("mig-configuration").open = true;
  }
  if (!inventory.vm_read_complete) {
    controls.append(node("p", "Check access to VM references and refresh."));
    return;
  }
  const pendingMode = modeChangePending(gpu);
  if (!renderMigActions(migControls, gpu, !pendingMode)) return;
  if (!currentMode(gpu)) {
    controls.append(node("p", "Unable to determine the current mode. Refresh to retry."));
    return;
  }
  if (pendingMode) controls.append(node("p", "Mode change pending. Only removal of the current configuration is available."));
  if (gpu.vfs.length === 0) {
    if (pendingMode) return;
    if (gpu.sysfs_visible && gpu.sriov_total_vfs > 0) {
      controls.append(operationButton("Enable VFs", () => ({
        payload: { action: "enable-vfs", pf: gpu.bdf },
        target: "Physical GPU " + gpu.bdf + ". Stop CUDA workloads and monitoring processes using this GPU before proceeding.",
      })));
    } else {
      controls.append(node("p", "Unable to verify the SR-IOV prerequisites for this GPU."));
    }
    return;
  }
  const vf = gpu.vfs.find((entry) => entry.bdf === element("vf-select").value);
  if (!vf || vf.interface !== "vendor-vfio" || vf.profile_id === null) {
    controls.append(node("p", "Select a VF with NVIDIA vendor-specific VFIO and a readable profile ID."));
    return;
  }
  const address = { pf: gpu.bdf, vf: vf.bdf };
  const migEnabled = gpu.mig?.current === "enabled";
  const gis = migEnabled ? (gpu.mig.instances ?? []).filter((gi) => gi.default_ci && gi.profile.toLowerCase().endsWith("+gfx")) : [];
  const stopped = (inventory.vms ?? []).filter((vm) => !vm.active);
  if (vf.assignments.length) {
    if (vf.assignments.some((ref) => ref.scope === "live")) {
      controls.append(node("p", "Shut down the running VMs that reference this VF."));
      return;
    }
    const vmUuids = [...new Set(vf.assignments.map((ref) => ref.uuid))];
    if (vmUuids.length !== vf.assignments.length || vf.assignments.some((ref) => ref.element !== "hostdev")) {
      controls.append(node("p", "Check that each VM has one PCI hostdev entry for this VF."));
      return;
    }
    const blocked = vf.assignments.filter((ref) => !stopped.some((vm) => vm.uuid === ref.uuid));
    if (blocked.length) {
      controls.append(node("p", "Verify that these VMs are stopped · " + blocked.map((ref) => ref.vm).join(", ")));
      return;
    }
    const vmNames = vf.assignments.map((ref) => ref.vm).join(", ");
    controls.append(operationButton("Detach VF from all VMs", () => ({
      payload: { action: "detach", ...address, vm_uuids: vmUuids },
      target: vf.bdf + "\nDetach from · " + vmNames,
    })));
    const ref = vf.assignments[0];
    if (vf.assignments.length === 1 && ref.managed !== "no" && vf.profile_id > 0) {
      controls.append(operationButton("Set managed=no", () => ({
        payload: { action: "set-unmanaged", ...address, vm_uuid: ref.uuid, profile_id: vf.profile_id },
        target: vf.bdf + " → " + ref.vm,
      })));
    }
    return;
  }
  if (vf.profile_id === 0) {
    if (pendingMode) return;
    if (migEnabled && !gis.length) {
      controls.append(node("p", "First create a GI and default CI under Manage GI / CI."));
      return;
    }
    const available = modeProfiles(gpu, vf);
    if (!available.length) {
      controls.append(node("p", "Unable to retrieve available profiles."));
      return;
    }
    const profiles = choice("profile-select", "Profile to apply",
      available.map((profile) => option(profile.name + " (" + profile.id + ")", profile.id)));
    if (migEnabled) {
      const target = choice("target-gi-select", "Target GI", gis.map((gi) => option(giLabel(gi), gi.start)));
      controls.append(profiles.field, target.field, operationButton("Set MIG-backed vGPU", () => ({
        payload: { action: "set-mig-profile", ...address, profile_id: Number(profiles.select.value),
          gi_start: Number(target.select.value) },
        target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent + " · " +
          target.select.selectedOptions[0].textContent,
      })));
      return;
    }
    controls.append(profiles.field, operationButton("Set profile", () => ({
      payload: { action: "set-profile", ...address, profile_id: Number(profiles.select.value) },
      target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent,
    })));
    return;
  }
  if (stopped.length && !pendingMode) {
    const vms = choice("vm-select", "Stopped VM",
      stopped.map((vm) => option(vm.name, vm.uuid)));
    controls.append(vms.field, operationButton("Attach with managed=no", () => ({
      payload: { action: "attach", ...address, vm_uuid: vms.select.value, profile_id: vf.profile_id },
      target: vf.bdf + " → " + vms.select.selectedOptions[0].textContent,
    })));
  } else if (!pendingMode) {
    controls.append(node("p", "No stopped persistent VM is available for assignment."));
  }
  controls.append(operationButton("Clear vGPU type", () => ({
    payload: { action: "clear-profile", ...address, profile_id: vf.profile_id },
    target: vf.bdf + " · Reset vGPU type ID " + vf.profile_id + " to unset (ID 0).",
  })));
}

function restoreCheckbox(container, gpu, label, checked, kind, key, available = true, note = "") {
  const row = node("label");
  row.className = "restore-option";
  const input = node("input");
  input.type = "checkbox";
  input.checked = checked;
  input.disabled = writing || !inventory.write_enabled || (!checked && !available);
  const text = node("span");
  text.append(node("strong", label));
  text.append(node("small", (checked ? "Restore enabled" : "Restore disabled") + (note ? " · " + note : "")));
  input.addEventListener("change", () => {
    const enabled = input.checked;
    input.checked = checked;
    submitOperation(enabled ? "Enable startup restore" : "Disable startup restore",
      gpu.bdf + " · " + label,
      { action: "set-restore", pf: gpu.bdf, kind, key, enabled });
  });
  row.append(input, text);
  container.append(row);
}

function renderRestoreSettings(gpu) {
  const section = element("restore-settings");
  section.hidden = !gpu;
  const controls = element("restore-controls");
  controls.replaceChildren();
  if (!gpu) return;
  const saved = inventory.restore_state;
  if (!saved) {
    controls.append(node("p", "Unable to read restore settings. Refresh with administrative access."));
    return;
  }
  const config = saved.mig_pfs?.[gpu.bdf];
  const entries = saved.entries.filter((entry) => entry.pf === gpu.bdf);
  const mig = gpu.mig;
  const active = mig?.current === "enabled" && mig.pending === "enabled";
  const sizeMode = saved.size_modes?.[gpu.bdf];
  if (!active && (sizeMode || gpu.size_mode?.current)) {
    restoreCheckbox(controls, gpu, "Restore mode · " + (modeLabels[sizeMode?.mode ?? gpu.size_mode?.current] ?? "Unavailable"),
      !!sizeMode, "size-mode", 0, !config && !!gpu.size_mode?.current);
  }
  if (mig || config) {
    restoreCheckbox(controls, gpu, "Restore MIG mode", !!config, "mig", 0, active);
    const geometryKey = (gi) => [gi.start, gi.size, gi.profile].join(":");
    const layouts = new Map((config?.instances ?? []).map((gi) => [geometryKey(gi), gi]));
    for (const gi of mig?.instances ?? []) layouts.set(geometryKey(gi), gi);
    for (const gi of [...layouts.values()].sort((a, b) => a.start - b.start)) {
      const stored = config?.instances.some((row) => row.start === gi.start && row.size === gi.size && row.profile === gi.profile);
      const existing = mig?.instances?.find((row) => row.start === gi.start && row.profile === gi.profile && row.size === gi.size);
      restoreCheckbox(controls, gpu, "Restore GI and default CI · " + gi.profile + " · " + gi.start + ":" + gi.size,
        !!stored, "gi", gi.start, !!config && active && existing?.default_ci && gi.profile.toLowerCase().endsWith("+gfx"),
        existing ? "" : "Current GI not detected");
    }
  }
  restoreCheckbox(controls, gpu, "Restore SR-IOV VFs", !!saved.enabled_pfs[gpu.bdf], "vfs", 0, gpu.vfs.length > 0);
  const vfs = new Map(gpu.vfs.map((vf) => [vf.index, vf]));
  for (const entry of entries) if (!vfs.has(entry.vf_index)) vfs.set(entry.vf_index, { index: entry.vf_index, bdf: entry.vf_bdf });
  for (const vf of [...vfs.values()].sort((a, b) => a.index - b.index)) {
    const entry = entries.find((row) => row.vf_index === vf.index);
    if (!entry && !(vf.profile_id > 0)) continue;
    const name = entry?.profile ?? vf.profile_name ?? ("ID " + vf.profile_id);
    const gi = mig?.instances?.find((row) => row.id === vf.gi_id);
    const parentSaved = !active || config?.instances.some((row) => row.start === gi?.start && row.profile === gi?.profile && row.size === gi?.size);
    const placement = entry?.gi_start ?? gi?.start;
    restoreCheckbox(controls, gpu, "Restore vGPU · virtfn" + vf.index + " · " + name,
      !!entry, "profile", vf.index, vf.profile_id > 0 && parentSaved,
      vf.bdf + (placement === undefined ? "" : " · GI placement " + placement));
  }
}

function renderConfiguration(gpu) {
  element("configuration").hidden = !inventory.write_enabled || !gpu;
  const select = element("vf-select");
  const previousVf = select.value;
  const vfs = gpu?.vfs.filter((vf) => vf.bdf) ?? [];
  select.replaceChildren(...vfs.map((vf) => option("virtfn" + vf.index + " · " + vf.bdf, vf.bdf)));
  if (vfs.some((vf) => vf.bdf === previousVf)) select.value = previousVf;
  element("vf-picker").hidden = vfs.length === 0;
  renderVfActions();
}

async function confirmOperation(label, target) {
  if (!transport.onPermissionsChanged) return window.confirm(label + "\n" + target);
  const dialog = element("operation-dialog");
  element("operation-title").textContent = label;
  element("operation-target").textContent = target;
  dialog.returnValue = "";
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "apply"), { once: true });
  });
}

async function submitOperation(label, target, payload) {
  if (writing || element("refresh").disabled) return;
  const status = element("operation-status");
  const restoreStatus = element("restore-status");
  if (!await confirmOperation(label, target)) return;
  writing = true;
  element("refresh").disabled = true;
  status.textContent = label + " in progress";
  restoreStatus.textContent = status.textContent;
  renderVfActions();
  try {
    const result = await transport.operate(payload);
    status.textContent = result.error ?? result.message;
  } catch (error) {
    status.textContent = "Unable to retrieve the operation result. Refresh to check the current state. " + error.message;
  } finally {
    restoreStatus.textContent = status.textContent;
    await refresh();
    writing = false;
    renderSelectedGpu();
  }
}

function renderSelectedGpu() {
  if (!inventory) return;
  const gpu = selectedGpu();
  const content = gpu
    ? renderGpu(gpu, inventory.vm_read_complete)
    : node("p", inventory.gpus === null ? "Unable to retrieve GPU information." : "No physical NVIDIA GPUs detected.");
  element("gpus").replaceChildren(content);
  renderConfiguration(gpu);
}

function render(data) {
  inventory = data;
  element("diagnostic-button").disabled = false;
  element("host-info").textContent = [data.host.os, data.host.kernel, data.host.arch].join(" · ");
  const mode = data.write_enabled ? "Changes enabled" :
    (transport.readOnlyHint ?? "Read-only");
  element("status").textContent = mode + " · Updated " +
    new Date(data.collected_at).toLocaleString("en") +
    (data.vm_read_complete ? "" : " · VM references are partially or fully unverified");
  element("warnings").hidden = data.warnings.length === 0;
  element("warning-list").replaceChildren(...data.warnings.map((warning) => node("li", warning)));
  const select = element("gpu-select");
  const previousBdf = select.value;
  const gpus = data.gpus ?? [];
  select.replaceChildren(...gpus.map((gpu) => option(gpu.name + " · " + gpu.bdf, gpu.bdf)));
  if (gpus.some((gpu) => gpu.bdf === previousBdf)) {
    select.value = previousBdf;
  }
  element("gpu-label").textContent = "Physical GPUs (" + gpus.length + ")";
  element("gpu-picker").hidden = gpus.length === 0;
  renderSelectedGpu();

  const mdev = Object.entries(data.mdev_assignments);
  element("mdev").hidden = mdev.length === 0;
  element("mdev-list").replaceChildren(...mdev.map(([uuid, assignments]) =>
    node("li", uuid + " · " + assignments.map(assignmentLabel).join(" / "))));
}

async function refresh() {
  refreshForPermissions = false;
  const button = element("refresh");
  button.disabled = true;
  element("status").textContent = "Refreshing";
  try {
    render(await transport.inventory());
  } catch (error) {
    element("status").textContent = "Refresh failed. The page shows the last retrieved results. " + error.message;
  } finally {
    button.disabled = false;
    if (refreshForPermissions) await refresh();
  }
}

element("gpu-select").addEventListener("change", renderSelectedGpu);
element("vf-select").addEventListener("change", renderVfActions);
element("refresh").addEventListener("click", refresh);
if (transport.onPermissionsChanged) {
  element("diagnostic-link").hidden = true;
  element("diagnostic-button").hidden = false;
  element("diagnostic-button").addEventListener("click", () => {
    element("diagnostic-data").textContent = JSON.stringify(inventory, null, 2);
    element("diagnostic-dialog").showModal();
  });
  transport.onPermissionsChanged(() => {
    if (inventory && !transport.canWrite()) render({ ...inventory, write_enabled: false });
    if (element("refresh").disabled) refreshForPermissions = true;
    else refresh();
  });
}
refresh();
