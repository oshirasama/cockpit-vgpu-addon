"use strict";

const element = (id) => document.getElementById(id);
const interfaces = {
  "vendor-vfio": "NVIDIA vendor-specific VFIO",
  mdev: "mdev",
  both: "vendor-specific VFIO / mdev",
  unobserved: "インターフェース未検出",
};
const scopes = { live: "稼働中", config: "永続定義" };
let inventory = null;
let writing = false;

const transport = window.vgpuTransport ?? {
  async inventory() {
    const response = await fetch("/api/inventory");
    if (!response.ok) throw new Error("HTTP " + response.status);
    return response.json();
  },
  async operate(payload) {
    const response = await fetch("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VGPU-Request": "1" },
      body: JSON.stringify(payload),
    });
    if (!response.headers.get("Content-Type")?.includes("application/json")) {
      throw new Error("HTTP " + response.status);
    }
    return response.json();
  },
};

function node(tag, text) {
  const item = document.createElement(tag);
  if (text !== undefined) item.textContent = text;
  return item;
}

function list(entries) {
  const item = node("ul");
  for (const entry of entries) item.append(node("li", entry));
  return item;
}

function assignmentLabel(assignment) {
  return assignment.vm + " · " + scopes[assignment.scope] +
    " · " + (assignment.managed === null ? "managed 属性なし" : "managed=" + assignment.managed);
}

function profilesCell(vf) {
  if (vf.creatable === null) return node("span", "未取得");
  if (vf.creatable.length === 0) return node("span", "候補なし");
  const details = node("details");
  details.append(
    node("summary", vf.creatable.length + " 件"),
    list(vf.creatable.map((profile) => profile.name + " (" + profile.id + ")"))
  );
  return details;
}

function renderGpu(gpu, vmReadComplete) {
  const card = node("article");
  card.className = "card";
  const total = gpu.sriov_total_vfs === null ? "" : " / 最大 " + gpu.sriov_total_vfs;
  const mdev = gpu.pf_mdev ? " · PF に mdev インターフェースあり" : "";
  card.append(
    node("h2", gpu.name),
    node("p", gpu.bdf + " · Driver " + gpu.driver + " · VF " + gpu.vfs.length + total + mdev)
  );
  if (gpu.vfs.length === 0) {
    const description = gpu.sysfs_visible ? "有効な VF を検出していません。" : "PCI sysfs を確認できません。";
    card.append(node("p", description));
    return card;
  }

  const table = node("table");
  const headRow = table.createTHead().insertRow();
  for (const label of ["VF / PCI BDF", "管理方式", "現在のプロファイル", "設定可能", "VM 参照"]) {
    const header = node("th", label);
    header.scope = "col";
    headRow.append(header);
  }
  const body = table.createTBody();
  for (const vf of gpu.vfs) {
    const row = body.insertRow();
    row.insertCell().textContent = "virtfn" + vf.index + " · " + (vf.bdf ?? "未取得");
    row.insertCell().textContent = interfaces[vf.interface];
    const activeProfile = vf.profile_name
      ? vf.profile_name + " (" + vf.profile_id + ")"
      : "ID " + vf.profile_id;
    row.insertCell().textContent = vf.profile_id === null ? "未取得" :
      vf.profile_id === 0 ? "未設定" : activeProfile;
    row.insertCell().append(profilesCell(vf));
    const assigned = row.insertCell();
    if (vf.assignments.length) assigned.append(list(vf.assignments.map(assignmentLabel)));
    else assigned.textContent = vmReadComplete && vf.bdf ? "参照なし" : "未確認";
  }
  const container = node("div");
  container.className = "table-scroll";
  container.append(table);
  card.append(container);
  return card;
}

function selectedGpu() {
  return inventory?.gpus?.find((gpu) => gpu.bdf === element("gpu-select").value);
}

function option(label, value) {
  const entry = node("option", label);
  entry.value = value;
  return entry;
}

function operationButton(label, buildRequest) {
  const button = node("button", label);
  button.type = "button";
  button.disabled = writing;
  button.addEventListener("click", () => {
    const { payload, target } = buildRequest();
    submitOperation(label, target, payload);
  });
  return button;
}

function choice(id, label, options) {
  const select = node("select");
  select.id = id;
  select.append(...options);
  const caption = node("label", label);
  caption.htmlFor = id;
  const field = node("div");
  field.className = "operation-field";
  field.append(caption, select);
  return { field, select };
}

function renderVfActions() {
  const controls = element("operation-controls");
  controls.replaceChildren();
  const gpu = selectedGpu();
  if (!gpu || !inventory.write_enabled) return;
  if (!inventory.vm_read_complete) {
    controls.append(node("p", "VM の参照を確認できる状態で再取得してください。"));
    return;
  }
  if (gpu.vfs.length === 0) {
    if (gpu.sysfs_visible && gpu.sriov_total_vfs > 0) {
      controls.append(operationButton("VF を有効化", () => ({
        payload: { action: "enable-vfs", pf: gpu.bdf },
        target: "物理 GPU " + gpu.bdf + "。GPU を使う CUDA や監視処理を停止した状態で実行します。",
      })));
    } else {
      controls.append(node("p", "この GPU では SR-IOV の有効化条件を確認できません。"));
    }
    return;
  }
  const vf = gpu.vfs.find((entry) => entry.bdf === element("vf-select").value);
  if (!vf || vf.interface !== "vendor-vfio" || vf.profile_id === null) {
    controls.append(node("p", "構成できる VF は NVIDIA vendor-specific VFIO で、現在のプロファイル ID を取得できる VF です。"));
    return;
  }
  const address = { pf: gpu.bdf, vf: vf.bdf };
  const stopped = (inventory.vms ?? []).filter((vm) => !vm.active);
  if (vf.assignments.length) {
    if (vf.assignments.some((ref) => ref.scope === "live")) {
      controls.append(node("p", "この VF を参照する稼働中の VM を停止してください。"));
      return;
    }
    const vmUuids = [...new Set(vf.assignments.map((ref) => ref.uuid))];
    if (vmUuids.length !== vf.assignments.length || vf.assignments.some((ref) => ref.element !== "hostdev")) {
      controls.append(node("p", "この VF の PCI hostdev を VM ごとに一つずつ確認してください。"));
      return;
    }
    const blocked = vf.assignments.filter((ref) => !stopped.some((vm) => vm.uuid === ref.uuid));
    if (blocked.length) {
      controls.append(node("p", "停止状態を確認する VM · " + blocked.map((ref) => ref.vm).join("、")));
      return;
    }
    const vmNames = vf.assignments.map((ref) => ref.vm).join("、");
    controls.append(operationButton("VF の割り当てを一括解除", () => ({
      payload: { action: "detach", ...address, vm_uuids: vmUuids },
      target: vf.bdf + "\n解除する VM · " + vmNames,
    })));
    const ref = vf.assignments[0];
    if (vf.assignments.length === 1 && ref.managed !== "no" && vf.profile_id > 0) {
      controls.append(operationButton("managed=no に修正", () => ({
        payload: { action: "set-unmanaged", ...address, vm_uuid: ref.uuid, profile_id: vf.profile_id },
        target: vf.bdf + " → " + ref.vm,
      })));
    }
    return;
  }
  if (vf.profile_id === 0) {
    if (!vf.creatable?.length) {
      controls.append(node("p", "現在設定できるプロファイルを取得できません。"));
      return;
    }
    const profiles = choice("profile-select", "設定するプロファイル",
      vf.creatable.map((profile) => option(profile.name + " (" + profile.id + ")", profile.id)));
    controls.append(profiles.field, operationButton("プロファイルを設定", () => ({
      payload: { action: "set-profile", ...address, profile_id: Number(profiles.select.value) },
      target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent,
    })));
    return;
  }
  if (stopped.length) {
    const vms = choice("vm-select", "停止中の VM",
      stopped.map((vm) => option(vm.name, vm.uuid)));
    controls.append(vms.field, operationButton("managed=no で割り当て", () => ({
      payload: { action: "attach", ...address, vm_uuid: vms.select.value, profile_id: vf.profile_id },
      target: vf.bdf + " → " + vms.select.selectedOptions[0].textContent,
    })));
  } else {
    controls.append(node("p", "割り当て先として選択できる停止中の永続 VM がありません。"));
  }
  controls.append(operationButton("vGPU タイプをクリア", () => ({
    payload: { action: "clear-profile", ...address, profile_id: vf.profile_id },
    target: vf.bdf + " · vGPU タイプ ID " + vf.profile_id + " を未設定（ID 0）に戻します。",
  })));
}

function renderConfiguration(gpu) {
  element("configuration").hidden = !inventory.write_enabled || !gpu;
  const select = element("vf-select");
  const previousVf = select.value;
  const vfs = gpu?.vfs.filter((vf) => vf.bdf) ?? [];
  select.replaceChildren(...vfs.map((vf) => option("virtfn" + vf.index + " · " + vf.bdf, vf.bdf)));
  if (vfs.some((vf) => vf.bdf === previousVf)) select.value = previousVf;
  element("vf-picker").hidden = vfs.length === 0;
  renderVfActions();
}

async function confirmOperation(label, target) {
  if (!transport.onPermissionsChanged) return window.confirm(label + "\n" + target);
  const dialog = element("operation-dialog");
  element("operation-title").textContent = label;
  element("operation-target").textContent = target;
  dialog.returnValue = "";
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "apply"), { once: true });
  });
}

async function submitOperation(label, target, payload) {
  if (writing || element("refresh").disabled) return;
  const status = element("operation-status");
  if (!await confirmOperation(label, target)) return;
  writing = true;
  element("refresh").disabled = true;
  status.textContent = label + "を実行中";
  renderVfActions();
  try {
    const result = await transport.operate(payload);
    status.textContent = result.error ?? result.message;
  } catch (error) {
    status.textContent = "操作の結果を取得できません。再取得して現在の状態を確認してください。 " + error.message;
  } finally {
    await refresh();
    writing = false;
    renderVfActions();
  }
}

function renderSelectedGpu() {
  if (!inventory) return;
  const gpu = selectedGpu();
  const content = gpu
    ? renderGpu(gpu, inventory.vm_read_complete)
    : node("p", inventory.gpus === null ? "GPU 情報を取得できません。" : "物理 NVIDIA GPU を検出していません。");
  element("gpus").replaceChildren(content);
  renderConfiguration(gpu);
}

function render(data) {
  inventory = data;
  element("diagnostic-button").disabled = false;
  element("host-info").textContent = [data.host.os, data.host.kernel, data.host.arch].join(" · ");
  const mode = data.write_enabled ? "変更モード" :
    (transport.readOnlyHint ?? "読み取り専用");
  element("status").textContent = mode + " · 取得 " +
    new Date(data.collected_at).toLocaleString("ja-JP") +
    (data.vm_read_complete ? "" : " · VM 参照の確認が一部またはすべて未完了");
  element("warnings").hidden = data.warnings.length === 0;
  element("warning-list").replaceChildren(...data.warnings.map((warning) => node("li", warning)));
  const select = element("gpu-select");
  const previousBdf = select.value;
  const gpus = data.gpus ?? [];
  select.replaceChildren(...gpus.map((gpu) => option(gpu.name + " · " + gpu.bdf, gpu.bdf)));
  if (gpus.some((gpu) => gpu.bdf === previousBdf)) {
    select.value = previousBdf;
  }
  element("gpu-label").textContent = "物理 GPU（" + gpus.length + " 台）";
  element("gpu-picker").hidden = gpus.length === 0;
  renderSelectedGpu();

  const mdev = Object.entries(data.mdev_assignments);
  element("mdev").hidden = mdev.length === 0;
  element("mdev-list").replaceChildren(...mdev.map(([uuid, assignments]) =>
    node("li", uuid + " · " + assignments.map(assignmentLabel).join(" / "))));
}

async function refresh() {
  const button = element("refresh");
  button.disabled = true;
  element("status").textContent = "取得中";
  try {
    render(await transport.inventory());
  } catch (error) {
    element("status").textContent = "再取得できませんでした。表示中の内容は前回の取得結果です。 " + error.message;
  } finally {
    button.disabled = false;
  }
}

element("gpu-select").addEventListener("change", renderSelectedGpu);
element("vf-select").addEventListener("change", renderVfActions);
element("refresh").addEventListener("click", refresh);
if (transport.onPermissionsChanged) {
  element("diagnostic-link").hidden = true;
  element("diagnostic-button").hidden = false;
  element("diagnostic-button").addEventListener("click", () => {
    element("diagnostic-data").textContent = JSON.stringify(inventory, null, 2);
    element("diagnostic-dialog").showModal();
  });
  transport.onPermissionsChanged(() => {
    if (inventory) render({ ...inventory, write_enabled: transport.canWrite() });
    if (!writing && !element("refresh").disabled) refresh();
  });
}
refresh();
