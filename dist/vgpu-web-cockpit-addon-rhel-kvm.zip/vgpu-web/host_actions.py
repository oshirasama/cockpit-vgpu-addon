"""Perform explicitly requested NVIDIA vGPU changes on the local KVM host."""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
from uuid import UUID, uuid4
from xml.dom import minidom
from xml.parsers.expat import ExpatError
import xml.etree.ElementTree as ET


# The installed helper is started with Python's isolated mode. Import only
# the shared inventory code beside the root-owned copy of this file.
if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from inventory import READ_ERRORS, normalize_bdf, pci_source_bdf, read_profiles, read_vm_assignments
from gpu_state import (
    Hardware, LEGACY_STORE, STORE, check_legacy, gpu_identity, initialize, load_state, restore_saved,
    save_and_apply, with_enabled_pf, with_profile,
)


DEVICES = Path("/sys/bus/pci/devices")
LOCK_PATH = Path("/run/lock/nvidia-vgpu-persist.lock")
SRIOV_MANAGE = "/usr/lib/nvidia/sriov-manage"
LIBVIRT = ["/usr/bin/virsh", "--connect", "qemu:///system"]
REQUEST_FIELDS = {
    "check": set(),
    "enable-vfs": {"pf"},
    "set-profile": {"pf", "vf", "profile_id"},
    "clear-profile": {"pf", "vf", "profile_id"},
    "attach": {"pf", "vf", "vm_uuid", "profile_id"},
    "detach": {"pf", "vf", "vm_uuids"},
    "set-unmanaged": {"pf", "vf", "vm_uuid", "profile_id"},
}


class HostActionError(RuntimeError):
    pass


ACTION_ERRORS = READ_ERRORS + (KeyError, TypeError, AttributeError, ExpatError)


def trusted_runner(timeout=70):
    deadline = time.monotonic() + timeout

    def run(args):
        program = "/usr/bin/virsh" if args[0] == "virsh" else args[0]
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise HostActionError("ホスト操作の制限時間に達しました。再取得して現在の状態を確認してください。")
        result = subprocess.run(
            [program, *args[1:]], cwd="/", capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=min(remaining, 25),
            env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C", "LC_ALL": "C", "HOME": "/root"},
        )
        if result.returncode:
            raise HostActionError((result.stderr or result.stdout).strip() or f"{program}: exit {result.returncode}")
        return result.stdout

    return run


@contextmanager
def operation_lock():
    import fcntl

    fd = os.open(LOCK_PATH, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != 0 or not stat.S_ISREG(info.st_mode) or info.st_mode & 0o022:
            raise HostActionError("ロックファイルの所有者またはモードを確認してください。")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise HostActionError("別の vGPU 操作が進行中です。完了後に再取得してください。") from exc
        yield
    finally:
        os.close(fd)


def validate_request(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("action"), str):
        raise HostActionError("操作リクエストが不正です。")
    action = payload["action"]
    if action not in REQUEST_FIELDS or payload.keys() - {"action"} != REQUEST_FIELDS[action]:
        raise HostActionError("未対応の操作または入力項目です。")
    for key in ("pf", "vf"):
        if key in payload:
            payload[key] = normalize_bdf(payload[key])
    if "vm_uuid" in payload:
        payload["vm_uuid"] = str(UUID(payload["vm_uuid"]))
    if "vm_uuids" in payload:
        targets = payload["vm_uuids"]
        if not isinstance(targets, list) or not targets or not all(isinstance(value, str) for value in targets):
            raise HostActionError("解除する VM の確認情報が不正です。")
        normalized = [str(UUID(value)) for value in targets]
        if len(set(normalized)) != len(normalized):
            raise HostActionError("解除する VM の確認情報が重複しています。")
        payload["vm_uuids"] = normalized
    if "profile_id" in payload:
        value = payload["profile_id"]
        if type(value) is not int or not 0 < value <= 2**31 - 1:
            raise HostActionError("プロファイル ID が不正です。")
    return payload


def check_pf(devices, address):
    pf = devices / address
    if ((pf / "physfn").exists() or (pf / "vendor").read_text().strip().lower() != "0x10de"
            or (pf / "driver").resolve(strict=True).name != "nvidia"
            or int((pf / "sriov_totalvfs").read_text()) <= 0):
        raise HostActionError(f"{address}: NVIDIA SR-IOV GPU の PF として確認できません。")
    return pf


def vf_directory(devices, pf, address):
    vf = (devices / address).resolve(strict=True)
    if ((vf / "physfn").resolve(strict=True) != pf.resolve(strict=True)
            or not any(link.resolve(strict=True) == vf for link in pf.glob("virtfn*")
                       if re.fullmatch(r"virtfn\d+", link.name))):
        raise HostActionError(f"{address}: 選択された GPU の VF ではありません。")
    path = vf / "nvidia"
    if not (path / "current_vgpu_type").is_file() or (vf / "mdev_supported_types").is_dir():
        raise HostActionError(f"{address}: NVIDIA vendor-specific VFIO が確認できません。")
    return path


def domain_snapshot(runner):
    warnings = []
    domains = read_vm_assignments(runner, warnings)
    if not domains["complete"]:
        raise HostActionError("VM の参照を確認できません。 " + " / ".join(warnings[:3]))
    return domains


def stopped_vms(runner):
    return set(runner([*LIBVIRT, "list", "--inactive", "--persistent", "--without-managed-save", "--uuid"]).split())


def check_stopped(vm_uuid, runner):
    if vm_uuid not in stopped_vms(runner):
        raise HostActionError("永続定義のある停止中 VM を選択してください。管理保存が残る VM は復帰後に停止してください。")


def current_profile(path):
    value = (path / "current_vgpu_type").read_text().strip()
    if not re.fullmatch(r"\d+", value):
        raise HostActionError(f"現在のプロファイル ID を確認できません。 {value!r}")
    return int(value)


def write_profile(path, profile_id):
    (path / "current_vgpu_type").write_text(str(profile_id) + "\n")
    if current_profile(path) != profile_id:
        raise HostActionError("書き込み結果を確認できません。再取得して現在の状態を確認してください。")


def find_hostdev(xml, address):
    document = minidom.parseString(xml)
    devices = next(
        (node for node in document.documentElement.childNodes
         if node.nodeType == node.ELEMENT_NODE and node.tagName == "devices"), None,
    )
    candidates = [] if devices is None else [
        node for node in devices.childNodes
        if node.nodeType == node.ELEMENT_NODE and node.tagName == "hostdev"
        and node.getAttribute("type") == "pci"
        and pci_source_bdf(ET.fromstring(node.toxml())) == address
    ]
    if len(candidates) > 1:
        raise HostActionError(f"{address} の定義が同じ VM に複数あります。")
    return document, candidates[0] if candidates else None


def new_hostdev(address):
    domain, bus, slot, function = re.split(r"[:.]", address)
    hostdev = ET.Element("hostdev", mode="subsystem", type="pci", managed="no")
    ET.SubElement(ET.SubElement(hostdev, "source"), "address",
                  domain=f"0x{domain}", bus=f"0x{bus}", slot=f"0x{slot}", function=f"0x{function}")
    return ET.tostring(hostdev, encoding="unicode")


def change_vm(action, vf, vm_uuid, refs, runner):
    def dump():
        return runner([*LIBVIRT, "dumpxml", "--inactive", vm_uuid])

    check_stopped(vm_uuid, runner)
    before = dump()
    document, node = find_hostdev(before, vf)
    if action == "attach":
        if refs or node is not None:
            raise HostActionError(f"{vf} は VM から参照されています。")
        xml, command = new_hostdev(vf), "attach-device"
    else:
        if node is None:
            if action == "detach":
                return
            raise HostActionError(f"選択した VM に {vf} の PCI hostdev がありません。")
        if any(ref["scope"] == "live" for ref in refs):
            raise HostActionError(f"{vf} を参照する稼働中の VM を停止してください。")
        if action == "detach":
            xml, command = node.toxml(), "detach-device"
        else:
            if any(ref["uuid"] != vm_uuid for ref in refs):
                raise HostActionError(f"{vf} は別の VM の定義にも登録されています。")
            node.setAttribute("managed", "no")
            xml, command = document.toxml(), "define"
    check_stopped(vm_uuid, runner)
    if dump() != before:
        raise HostActionError("VM の定義が操作中に変更されました。再取得してください。")
    with TemporaryDirectory(prefix="vgpu-web-") as directory:
        config = Path(directory) / "device.xml"
        config.write_text(xml, encoding="utf-8")
        args = ["define", str(config), "--validate"] if command == "define" else [
            command, vm_uuid, str(config), "--config",
        ]
        runner([*LIBVIRT, *args])
    _, saved = find_hostdev(dump(), vf)
    if (saved is not None if action == "detach"
            else saved is None or saved.getAttribute("managed") != "no"):
        raise HostActionError("永続 VM XML の結果を確認できません。再取得してください。")


def detach_vf(vf, refs, confirmed_vms, runner):
    if not refs:
        return f"{vf}: VM からの割り当ては解除済みです。"
    if any(ref["scope"] == "live" for ref in refs):
        raise HostActionError(f"{vf} を参照する稼働中の VM を停止してください。")
    vm_uuids = {ref["uuid"] for ref in refs}
    if not vm_uuids.issubset(confirmed_vms):
        raise HostActionError(f"{vf} の VM 参照が更新されました。再取得してから確認してください。")
    if len(vm_uuids) != len(refs) or any(ref["element"] != "hostdev" for ref in refs):
        raise HostActionError(f"{vf} の各 VM 定義に PCI hostdev が一つずつあることを確認してください。")
    stopped = stopped_vms(runner)
    blocked = [ref["vm"] for ref in refs if ref["uuid"] not in stopped]
    if blocked:
        raise HostActionError("停止状態または管理保存を確認してください。 対象 VM: " + "、".join(blocked))

    detached = []
    for ref in refs:
        try:
            change_vm("detach", vf, ref["uuid"], refs, runner)
        except READ_ERRORS + (ExpatError,) as exc:
            progress = "解除を確認した VM: " + "、".join(detached) + "。" if detached else ""
            raise HostActionError(f"{vf}: {ref['vm']} の解除を確認できません。{progress} {exc}") from exc
        detached.append(ref["vm"])
    remaining = domain_snapshot(runner)["pci"].get(vf, [])
    if remaining:
        names = list(dict.fromkeys(ref["vm"] for ref in remaining))
        raise HostActionError(f"{vf}: 解除後も参照が残っています。再取得してください。 対象 VM: " + "、".join(names))
    return f"{vf}: " + "、".join(detached) + " から割り当てを解除しました。"


def save_profile(state_path, hw, pf, vf, path, name, current, selected, legacy):
    check_legacy((pf,), legacy)
    gpu_uuid = gpu_identity(hw, pf)
    indexes = [index for index, address in hw.vfs(pf) if address == vf]
    if len(indexes) != 1:
        raise HostActionError(f"{vf}: 保存する VF のインデックスを一意に確認できません。")
    previous = load_state(state_path)
    desired = with_profile(previous, pf, gpu_uuid, indexes[0], vf, name)
    save_and_apply(state_path, previous, desired, lambda: write_profile(path, selected),
                   lambda: current_profile(path), current, selected)


def perform(payload, devices=DEVICES, runner=None, restore_config=LEGACY_STORE, state_path=STORE):
    request = validate_request(payload)
    action = request["action"]
    if action == "check":
        return "ホスト操作ヘルパーを確認しました。"
    runner = runner or trusted_runner()
    pf_address = request["pf"]
    pf = check_pf(devices, pf_address)
    if action == "enable-vfs":
        def enabled():
            return int((pf / "sriov_numvfs").read_text()) > 0

        current = enabled()
        if not current and domain_snapshot(runner)["pci"].get(pf_address):
            raise HostActionError(f"{pf_address} は VM から参照されています。")
        check_legacy((pf_address,), restore_config)
        gpu_uuid = gpu_identity(Hardware(devices, runner), pf_address)
        previous = load_state(state_path)
        desired = with_enabled_pf(previous, pf_address, gpu_uuid)
        save_and_apply(state_path, previous, desired, lambda: runner([SRIOV_MANAGE, "-e", pf_address]),
                       enabled, current, True)
        return f"{pf_address}: VF の有効化を復元設定に保存しました。"

    vf = request["vf"]
    path = vf_directory(devices, pf, vf)
    refs = domain_snapshot(runner)["pci"].get(vf, [])
    if action == "detach":
        return detach_vf(vf, refs, request["vm_uuids"], runner)
    current = current_profile(path)
    selected = request.get("profile_id")
    if action == "set-profile":
        hardware = Hardware(devices, runner)
        if current == selected:
            name = hardware.supported(pf_address).get(selected)
        else:
            if current or refs:
                raise HostActionError(f"{vf}: 未設定で VM 参照のない VF を選択してください。")
            names = {profile["id"]: profile["name"] for profile in read_profiles(path / "creatable_vgpu_types")}
            name = names.get(selected)
        if not name:
            raise HostActionError("選択したプロファイルの名前または作成可否を確認できません。")
        save_profile(state_path, hardware, pf_address, vf, path, name, current, selected, restore_config)
        return f"{vf}: {name}（ID {selected}）を設定し、復元設定を更新しました。"
    if action == "clear-profile":
        if refs:
            raise HostActionError(f"{vf}: VM からの参照を解除してからクリアしてください。")
        if current and current != selected:
            raise HostActionError("VF のプロファイルが変更されました。再取得してください。")
        save_profile(state_path, Hardware(devices, runner), pf_address, vf, path, None, current, 0, restore_config)
        return f"{vf}: vGPU タイプを未設定（ID 0）に戻し、タイプを復元設定から削除しました。"
    if current != selected:
        raise HostActionError("VF のプロファイルが変更されました。再取得してください。")
    change_vm(action, vf, request["vm_uuid"], refs, runner)
    result = {"attach": "managed=no で割り当てました。", "set-unmanaged": "managed=no に修正しました。"}
    return f"{vf}: {result[action]}"


def cockpit_operator(loginuid_path=Path("/proc/self/loginuid")):
    import pwd

    try:
        uid = int(loginuid_path.read_text(encoding="ascii"))
    except (OSError, ValueError):
        return {"operator": None, "operator_uid": None}
    if not 0 <= uid < 4294967295:
        return {"operator": None, "operator_uid": None}
    try:
        name = pwd.getpwuid(uid).pw_name
    except KeyError:
        name = None
    return {"operator": name, "operator_uid": uid}


def run_cockpit_operation(request):
    import syslog

    request = validate_request(request)
    record = {"event": "vgpu_operation", "interface": "cockpit", "request_id": str(uuid4()),
              **cockpit_operator(), **request}
    syslog.openlog("vgpu-web-cockpit")

    def audit(result, **detail):
        timestamps = {"timestamp": datetime.now(timezone.utc).isoformat()}
        syslog.syslog(syslog.LOG_INFO, json.dumps({**record, **timestamps, "result": result, **detail},
                                                 separators=(",", ":")))

    audit("started")
    try:
        with operation_lock():
            message = perform(request)
    except ACTION_ERRORS as exc:
        audit("failed", error=str(exc))
        raise
    audit("succeeded", message=message)
    return message


def main():
    args = sys.argv[1:]
    from_cockpit = args == ["--cockpit-operation"]
    try:
        if sys.platform != "linux" or os.geteuid() != 0:
            raise HostActionError("Linux ホストの管理者権限で実行してください。")
        if args == ["--restore"]:
            with operation_lock():
                restore_saved(STORE, Hardware(DEVICES, trusted_runner(180)))
            return 0
        if args in (["--initialize-state"], ["--initialize-state", "--adopt-current"],
                    ["--initialize-state", "--adopt-current", "--require-vfs"]):
            with operation_lock():
                state = initialize(STORE, Hardware(DEVICES, trusted_runner()),
                                   adopt="--adopt-current" in args, require_vfs="--require-vfs" in args)
            print(f"復元設定: 物理 GPU {len(state['enabled_pfs'])} 台、vGPU タイプ {len(state['entries'])} 件。")
            return 0
        if args and not from_cockpit:
            raise HostActionError("ホスト操作へ渡す起動オプションを確認してください。")
        raw = sys.stdin.buffer.read(4097)
        if len(raw) > 4096:
            raise HostActionError("入力が上限を超えています。")
        request = json.loads(raw)
        if from_cockpit:
            message = run_cockpit_operation(request)
        else:
            with operation_lock():
                message = perform(request)
        print(json.dumps({"message": message}))
    except ACTION_ERRORS as exc:
        if args and not from_cockpit:
            print(str(exc), file=sys.stderr)
        else:
            print(json.dumps({"error": str(exc)}))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
