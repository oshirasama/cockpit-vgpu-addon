#!/usr/bin/env bash
set -euo pipefail

app_directory=$(cd -- "$(dirname -- "$0")/.." && pwd -P)
package_directory=/usr/local/share/cockpit/nvidia-vgpu
helper=/usr/local/libexec/vgpu-web/vgpu-web/host_actions.py
restore_unit=vgpu-web-restore.service
state_options=(--initialize-state)
replace_legacy=false

if [[ $EUID -eq 0 ]]; then
    echo 'sudo を使用できる一般ユーザーとして、このインストーラーを bash で実行してください。' >&2
    exit 1
fi

for option in "$@"; do
    case "$option" in
        --adopt-current) state_options=(--initialize-state --adopt-current) ;;
        --replace-legacy-restore) replace_legacy=true ;;
        *) echo "未対応のオプションです: $option" >&2; exit 1 ;;
    esac
done

if ! command -v cockpit-bridge >/dev/null || ! systemctl cat cockpit.socket >/dev/null 2>&1; then
    echo '先に Cockpit をインストールしてください。' >&2
    exit 1
fi

legacy_enabled=false
if systemctl is-enabled --quiet vgpu-restore.service; then
    legacy_enabled=true
    if ! "$replace_legacy" || [[ ${#state_options[@]} -ne 2 ]]; then
        echo '以前の vgpu-restore.service が有効です。現在の構成を確認し、--adopt-current --replace-legacy-restore を指定してください。' >&2
        exit 1
    fi
    state_options+=(--require-vfs)
fi

index_file=$(mktemp)
trap 'rm -f -- "$index_file"' EXIT
sed '/<script src="ui.js"/i\  <script src="../base1/cockpit.js" defer></script>\n  <script src="cockpit-transport.js" defer></script>' \
    "$app_directory/index.html" > "$index_file"

bash "$app_directory/deploy/install-write-helper.sh" --no-sudoers
sudo install -d -o root -g root -m 0700 /var/lib/vgpu-web
sudo /usr/bin/python3 -I "$helper" "${state_options[@]}"
sudo install -o root -g root -m 0644 "$app_directory/deploy/$restore_unit" /etc/systemd/system/

for daemon in virtqemud.service libvirtd.service libvirt-guests.service; do
    if systemctl cat "$daemon" >/dev/null 2>&1; then
        drop_in="/etc/systemd/system/$daemon.d"
        sudo install -d -o root -g root -m 0755 "$drop_in"
        sudo install -o root -g root -m 0644 "$app_directory/deploy/90-vgpu-web-restore.conf" "$drop_in/"
        sudo restorecon "$drop_in/90-vgpu-web-restore.conf"
    fi
done

sudo restorecon "/etc/systemd/system/$restore_unit" /var/lib/vgpu-web /var/lib/vgpu-web/gpu-state.json
sudo systemctl daemon-reload
sudo systemctl enable "$restore_unit"
if "$legacy_enabled"; then
    sudo systemctl disable vgpu-restore.service
fi

sudo install -d -o root -g root -m 0755 "$package_directory"
sudo install -o root -g root -m 0644 "$index_file" "$package_directory/index.html"
sudo install -o root -g root -m 0644 "$app_directory/ui.js" "$app_directory/style.css" \
    "$app_directory/cockpit/manifest.json" "$app_directory/cockpit/cockpit-transport.js" "$package_directory/"
sudo restorecon -R "$package_directory"
cockpit-bridge --packages
echo 'Cockpit にログインし直し、左メニューの「vGPU 管理」を開いてください。'
