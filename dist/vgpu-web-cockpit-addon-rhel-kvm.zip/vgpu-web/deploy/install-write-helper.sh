#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -eq 0 ]]; then
    echo 'Web UI を起動する一般ユーザーとして実行してください。' >&2
    exit 1
fi

app_directory=$(cd -- "$(dirname -- "$0")/.." && pwd -P)
helper_root=/usr/local/libexec/vgpu-web
use_sudoers=true
case "${1:-}" in
    --no-sudoers) use_sudoers=false ;;
    "") ;;
    *) echo "未対応のオプションです: $1" >&2; exit 1 ;;
esac

if "$use_sudoers"; then
    operator=$(id -un)
    if [[ ! $operator =~ ^[a-zA-Z_][a-zA-Z0-9_.-]*$ ]]; then
        echo 'このインストーラーはローカルの Linux ユーザー名を使用します。' >&2
        exit 1
    fi

    rule=$(mktemp)
    trap 'rm -f -- "$rule"' EXIT
    printf '%s ALL=(root) NOPASSWD: /usr/bin/python3 -I %s/vgpu-web/host_actions.py\n' "$operator" "$helper_root" > "$rule"
    sudo visudo -c -f "$rule"
fi
sudo install -d -o root -g root -m 0755 "$helper_root" "$helper_root/vgpu-web" "$helper_root/vgpu-persist"
sudo install -o root -g root -m 0644 "$app_directory/../vgpu-vf-status.py" "$helper_root/"
sudo install -o root -g root -m 0644 "$app_directory/../vgpu-persist/vgpu-persist.py" "$helper_root/vgpu-persist/"
sudo install -o root -g root -m 0644 \
    "$app_directory/inventory.py" "$app_directory/gpu_state.py" "$app_directory/host_actions.py" "$helper_root/vgpu-web/"
if "$use_sudoers"; then
    sudo install -o root -g root -m 0440 "$rule" /etc/sudoers.d/vgpu-web-operator
    sudo visudo -c
fi
