#!/usr/bin/env python3
"""Read-only NVIDIA SR-IOV VF/profile summary. Python standard library only."""
import argparse
import csv
import io
import os
from pathlib import Path
import re
import subprocess
import sys


def run(args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=20,
                            env=dict(os.environ, LC_ALL='C', LANG='C'))
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout).strip())
    return result.stdout


def normalize_bdf(value):
    match = re.fullmatch(r'([0-9a-fA-F]{4,8}):([0-9a-fA-F]{2}):([0-9a-fA-F]{2})\.([0-7])', value)
    if not match:
        raise ValueError(f'Invalid PCI address: {value}')
    domain, bus, slot, function = (int(v, 16) for v in match.groups())
    if domain > 0xffff or slot > 0x1f:
        raise ValueError(f'Invalid PCI address: {value}')
    return f'{domain:04x}:{bus:02x}:{slot:02x}.{function:x}'


def supported_names(text):
    names = {}
    pending = None
    for line in text.splitlines():
        match = re.fullmatch(r'\s*vGPU Type ID\s*:\s*(0[xX][0-9a-fA-F]+|\d+)\s*', line)
        if match:
            if pending is not None:
                raise ValueError('Missing profile name in nvidia-smi output')
            value = match.group(1)
            pending = int(value, 16 if value.lower().startswith('0x') else 10)
            continue
        match = re.fullmatch(r'\s*Name\s*:\s*(\S(?:.*\S)?)\s*', line)
        if match and pending is not None:
            if pending <= 0 or pending in names:
                raise ValueError('Invalid/duplicate vGPU type ID')
            names[pending] = match.group(1)
            pending = None
    if pending is not None or not names:
        raise ValueError('Unsupported nvidia-smi profile-list format')
    return names


def collect(devices=Path('/sys/bus/pci/devices'), runner=run, show_all=False):
    text = runner(['nvidia-smi', '--query-gpu=index,pci.bus_id,name', '--format=csv,noheader'])
    groups, warnings = [], []
    for values in csv.reader(io.StringIO(text), skipinitialspace=True):
        if len(values) != 3:
            raise ValueError(f'Unexpected GPU row: {values!r}')
        index, address, name = (v.strip() for v in values)
        pf = normalize_bdf(address)
        path = devices / pf
        if (path / 'physfn').exists():
            continue
        group = dict(index=index, pf=pf, name=name, rows=[], note='')
        links = sorted((p for p in path.glob('virtfn*') if re.fullmatch(r'virtfn\d+', p.name)),
                       key=lambda p: int(p.name[6:]))
        profiles = None
        if not path.exists():
            group['note'] = 'PF not found in sysfs'
            warnings.append(f'{pf}: PF not found in sysfs')
        elif not links:
            group['note'] = 'No enabled VFs (or SR-IOV unavailable)'
        for link in links:
            vf = '?'
            try:
                vf = normalize_bdf(link.resolve(strict=True).name)
                value = (link / 'nvidia/current_vgpu_type').read_text().strip()
                if not re.fullmatch(r'\d+', value):
                    raise ValueError(f'Unexpected current_vgpu_type: {value!r}')
                number = int(value)
                if not number and not show_all:
                    continue
                if not number:
                    profile = 'UNCONFIGURED'
                else:
                    if profiles is None:
                        try:
                            profiles = supported_names(runner(['nvidia-smi', 'vgpu', '-s', '-i', pf, '-v']))
                        except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
                            profiles = {}
                            warnings.append(f'{pf}: profile names unavailable: {exc}')
                    profile = profiles.get(number, 'UNKNOWN (ID retained; not guessed)')
                    if number not in profiles:
                        warnings.append(f'{vf}: cannot resolve type ID {number}')
                group['rows'].append((link.name, vf, str(number), profile))
            except (OSError, RuntimeError, ValueError) as exc:
                group['rows'].append((link.name, vf, '?', 'READ ERROR'))
                warnings.append(f'{pf}/{link.name}: {exc}')
        if links and not group['rows']:
            group['note'] = 'All enabled VFs are unconfigured (type ID = 0)'
        groups.append(group)
    if not groups:
        raise RuntimeError('No physical GPUs reported by nvidia-smi')
    return groups, warnings


def display(groups):
    for group in groups:
        print(f'GPU {group["index"]} | {group["name"]} | PF {group["pf"]}')
        if group['rows']:
            print(f'  {"VF":<10} {"VF PCI ADDRESS":<15} {"TYPE_ID":>8}  PROFILE')
            for vf_index, vf, number, profile in group['rows']:
                print(f'  {vf_index:<10} {vf:<15} {number:>8}  {profile}')
        if group['note']:
            print('  ' + group['note'])
        print()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--all', action='store_true', help='also show VFs whose type ID is zero')
    args = parser.parse_args()
    try:
        groups, warnings = collect(show_all=args.all)
        display(groups)
        for warning in warnings:
            print('WARNING: ' + warning, file=sys.stderr)
        return 1 if warnings else 0
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
