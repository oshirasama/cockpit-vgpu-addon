"use strict";

(() => {
  const cockpit = window.cockpit;
  const permission = cockpit?.permission({ admin: true });
  const helper = "/usr/local/libexec/vgpu-web/vgpu-web/";
  const python = "/usr/bin/python3";
  const canWrite = () => permission?.allowed === true;

  window.vgpuTransport = {
    canWrite,
    readOnlyHint: "Read-only · Switch to Administrative access in Cockpit to make changes",
    onPermissionsChanged(callback) {
      permission?.addEventListener("changed", callback);
    },
    async inventory() {
      if (!cockpit) throw new Error("Check the connection to Cockpit.");
      const options = canWrite() ? { superuser: "try" } : {};
      const output = await cockpit.spawn([python, "-I", helper + "inventory.py"], options);
      return { ...JSON.parse(output), write_enabled: canWrite() };
    },
    operate(payload) {
      if (!canWrite()) return Promise.resolve({ error: "Administrative access in Cockpit is required." });
      const process = cockpit.spawn(
        [python, "-I", helper + "host_actions.py", "--cockpit-operation"],
        { superuser: "require" },
      );
      process.input(JSON.stringify(payload));
      return process.then(JSON.parse, (failure, output) => {
        if (failure.problem === "access-denied") {
          return { error: "Administrative access in Cockpit is required." };
        }
        if (output) return JSON.parse(output);
        throw new Error(failure.message);
      });
    },
  };
})();
