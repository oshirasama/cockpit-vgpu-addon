"use strict";

const element = (id) => document.getElementById(id);
const interfaces = {
  "vendor-vfio": "NVIDIA vendor-specific VFIO",
  mdev: "mdev",
  both: "vendor-specific VFIO / mdev",
  unobserved: "Interface undetected",
};
const scopes = { live: "Live", config: "Persistent" };
let inventory = null;
let writing = false;

const transport = window.vgpuTransport ?? {
  async inventory() {
    const response = await fetch("/api/inventory");
    if (!response.ok) throw new Error("HTTP " + response.status);
    return response.json();
  },
  async operate(payload) {
    const response = await fetch("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VGPU-Request": "1" },
      body: JSON.stringify(payload),
    });
    if (!response.headers.get("Content-Type")?.includes("application/json")) {
      throw new Error("HTTP " + response.status);
    }
    return response.json();
  },
};

function node(tag, text) {
  const item = document.createElement(tag);
  if (text !== undefined) item.textContent = text;
  return item;
}

function list(entries) {
  const item = node("ul");
  for (const entry of entries) item.append(node("li", entry));
  return item;
}

function assignmentLabel(assignment) {
  return assignment.vm + " · " + scopes[assignment.scope] +
    " · " + (assignment.managed === null ? "managed attribute absent" : "managed=" + assignment.managed);
}

function profilesCell(vf) {
  if (vf.creatable === null) return node("span", "Unavailable");
  if (vf.creatable.length === 0) return node("span", "None available");
  const details = node("details");
  details.append(
    node("summary", vf.creatable.length + " available"),
    list(vf.creatable.map((profile) => profile.name + " (" + profile.id + ")"))
  );
  return details;
}

function renderGpu(gpu, vmReadComplete) {
  const card = node("article");
  card.className = "card";
  const total = gpu.sriov_total_vfs === null ? "" : " / max " + gpu.sriov_total_vfs;
  const mdev = gpu.pf_mdev ? " · mdev interface on PF" : "";
  card.append(
    node("h2", gpu.name),
    node("p", gpu.bdf + " · Driver " + gpu.driver + " · VF " + gpu.vfs.length + total + mdev)
  );
  if (gpu.vfs.length === 0) {
    const description = gpu.sysfs_visible ? "No enabled VFs detected." : "PCI sysfs is unavailable.";
    card.append(node("p", description));
    return card;
  }

  const table = node("table");
  const headRow = table.createTHead().insertRow();
  for (const label of ["VF / PCI BDF", "Interface", "Current profile", "Available profiles", "VM references"]) {
    const header = node("th", label);
    header.scope = "col";
    headRow.append(header);
  }
  const body = table.createTBody();
  for (const vf of gpu.vfs) {
    const row = body.insertRow();
    row.insertCell().textContent = "virtfn" + vf.index + " · " + (vf.bdf ?? "Unavailable");
    row.insertCell().textContent = interfaces[vf.interface];
    const activeProfile = vf.profile_name
      ? vf.profile_name + " (" + vf.profile_id + ")"
      : "ID " + vf.profile_id;
    row.insertCell().textContent = vf.profile_id === null ? "Unavailable" :
      vf.profile_id === 0 ? "Unset" : activeProfile;
    row.insertCell().append(profilesCell(vf));
    const assigned = row.insertCell();
    if (vf.assignments.length) assigned.append(list(vf.assignments.map(assignmentLabel)));
    else assigned.textContent = vmReadComplete && vf.bdf ? "None" : "Unverified";
  }
  const container = node("div");
  container.className = "table-scroll";
  container.append(table);
  card.append(container);
  return card;
}

function selectedGpu() {
  return inventory?.gpus?.find((gpu) => gpu.bdf === element("gpu-select").value);
}

function option(label, value) {
  const entry = node("option", label);
  entry.value = value;
  return entry;
}

function operationButton(label, buildRequest) {
  const button = node("button", label);
  button.type = "button";
  button.disabled = writing;
  button.addEventListener("click", () => {
    const { payload, target } = buildRequest();
    submitOperation(label, target, payload);
  });
  return button;
}

function choice(id, label, options) {
  const select = node("select");
  select.id = id;
  select.append(...options);
  const caption = node("label", label);
  caption.htmlFor = id;
  const field = node("div");
  field.className = "operation-field";
  field.append(caption, select);
  return { field, select };
}

function renderVfActions() {
  const controls = element("operation-controls");
  controls.replaceChildren();
  const gpu = selectedGpu();
  if (!gpu || !inventory.write_enabled) return;
  if (!inventory.vm_read_complete) {
    controls.append(node("p", "Check access to VM references and refresh."));
    return;
  }
  if (gpu.vfs.length === 0) {
    if (gpu.sysfs_visible && gpu.sriov_total_vfs > 0) {
      controls.append(operationButton("Enable VFs", () => ({
        payload: { action: "enable-vfs", pf: gpu.bdf },
        target: "Physical GPU " + gpu.bdf + ". Stop CUDA workloads and monitoring processes using this GPU before proceeding.",
      })));
    } else {
      controls.append(node("p", "Unable to verify the SR-IOV prerequisites for this GPU."));
    }
    return;
  }
  const vf = gpu.vfs.find((entry) => entry.bdf === element("vf-select").value);
  if (!vf || vf.interface !== "vendor-vfio" || vf.profile_id === null) {
    controls.append(node("p", "Select a VF with NVIDIA vendor-specific VFIO and a readable profile ID."));
    return;
  }
  const address = { pf: gpu.bdf, vf: vf.bdf };
  const stopped = (inventory.vms ?? []).filter((vm) => !vm.active);
  if (vf.assignments.length) {
    if (vf.assignments.some((ref) => ref.scope === "live")) {
      controls.append(node("p", "Shut down the running VMs that reference this VF."));
      return;
    }
    const vmUuids = [...new Set(vf.assignments.map((ref) => ref.uuid))];
    if (vmUuids.length !== vf.assignments.length || vf.assignments.some((ref) => ref.element !== "hostdev")) {
      controls.append(node("p", "Check that each VM has one PCI hostdev entry for this VF."));
      return;
    }
    const blocked = vf.assignments.filter((ref) => !stopped.some((vm) => vm.uuid === ref.uuid));
    if (blocked.length) {
      controls.append(node("p", "Verify that these VMs are stopped · " + blocked.map((ref) => ref.vm).join(", ")));
      return;
    }
    const vmNames = vf.assignments.map((ref) => ref.vm).join(", ");
    controls.append(operationButton("Detach VF from all VMs", () => ({
      payload: { action: "detach", ...address, vm_uuids: vmUuids },
      target: vf.bdf + "\nDetach from · " + vmNames,
    })));
    const ref = vf.assignments[0];
    if (vf.assignments.length === 1 && ref.managed !== "no" && vf.profile_id > 0) {
      controls.append(operationButton("Set managed=no", () => ({
        payload: { action: "set-unmanaged", ...address, vm_uuid: ref.uuid, profile_id: vf.profile_id },
        target: vf.bdf + " → " + ref.vm,
      })));
    }
    return;
  }
  if (vf.profile_id === 0) {
    if (!vf.creatable?.length) {
      controls.append(node("p", "Unable to retrieve available profiles."));
      return;
    }
    const profiles = choice("profile-select", "Profile to apply",
      vf.creatable.map((profile) => option(profile.name + " (" + profile.id + ")", profile.id)));
    controls.append(profiles.field, operationButton("Set profile", () => ({
      payload: { action: "set-profile", ...address, profile_id: Number(profiles.select.value) },
      target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent,
    })));
    return;
  }
  if (stopped.length) {
    const vms = choice("vm-select", "Stopped VM",
      stopped.map((vm) => option(vm.name, vm.uuid)));
    controls.append(vms.field, operationButton("Attach with managed=no", () => ({
      payload: { action: "attach", ...address, vm_uuid: vms.select.value, profile_id: vf.profile_id },
      target: vf.bdf + " → " + vms.select.selectedOptions[0].textContent,
    })));
  } else {
    controls.append(node("p", "No stopped persistent VM is available for assignment."));
  }
  controls.append(operationButton("Clear vGPU type", () => ({
    payload: { action: "clear-profile", ...address, profile_id: vf.profile_id },
    target: vf.bdf + " · Reset vGPU type ID " + vf.profile_id + " to unset (ID 0).",
  })));
}

function renderConfiguration(gpu) {
  element("configuration").hidden = !inventory.write_enabled || !gpu;
  const select = element("vf-select");
  const previousVf = select.value;
  const vfs = gpu?.vfs.filter((vf) => vf.bdf) ?? [];
  select.replaceChildren(...vfs.map((vf) => option("virtfn" + vf.index + " · " + vf.bdf, vf.bdf)));
  if (vfs.some((vf) => vf.bdf === previousVf)) select.value = previousVf;
  element("vf-picker").hidden = vfs.length === 0;
  renderVfActions();
}

async function confirmOperation(label, target) {
  if (!transport.onPermissionsChanged) return window.confirm(label + "\n" + target);
  const dialog = element("operation-dialog");
  element("operation-title").textContent = label;
  element("operation-target").textContent = target;
  dialog.returnValue = "";
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "apply"), { once: true });
  });
}

async function submitOperation(label, target, payload) {
  if (writing || element("refresh").disabled) return;
  const status = element("operation-status");
  if (!await confirmOperation(label, target)) return;
  writing = true;
  element("refresh").disabled = true;
  status.textContent = label + " in progress";
  renderVfActions();
  try {
    const result = await transport.operate(payload);
    status.textContent = result.error ?? result.message;
  } catch (error) {
    status.textContent = "Unable to retrieve the operation result. Refresh to check the current state. " + error.message;
  } finally {
    await refresh();
    writing = false;
    renderVfActions();
  }
}

function renderSelectedGpu() {
  if (!inventory) return;
  const gpu = selectedGpu();
  const content = gpu
    ? renderGpu(gpu, inventory.vm_read_complete)
    : node("p", inventory.gpus === null ? "Unable to retrieve GPU information." : "No physical NVIDIA GPUs detected.");
  element("gpus").replaceChildren(content);
  renderConfiguration(gpu);
}

function render(data) {
  inventory = data;
  element("diagnostic-button").disabled = false;
  element("host-info").textContent = [data.host.os, data.host.kernel, data.host.arch].join(" · ");
  const mode = data.write_enabled ? "Changes enabled" :
    (transport.readOnlyHint ?? "Read-only");
  element("status").textContent = mode + " · Updated " +
    new Date(data.collected_at).toLocaleString("en") +
    (data.vm_read_complete ? "" : " · VM references are partially or fully unverified");
  element("warnings").hidden = data.warnings.length === 0;
  element("warning-list").replaceChildren(...data.warnings.map((warning) => node("li", warning)));
  const select = element("gpu-select");
  const previousBdf = select.value;
  const gpus = data.gpus ?? [];
  select.replaceChildren(...gpus.map((gpu) => option(gpu.name + " · " + gpu.bdf, gpu.bdf)));
  if (gpus.some((gpu) => gpu.bdf === previousBdf)) {
    select.value = previousBdf;
  }
  element("gpu-label").textContent = "Physical GPUs (" + gpus.length + ")";
  element("gpu-picker").hidden = gpus.length === 0;
  renderSelectedGpu();

  const mdev = Object.entries(data.mdev_assignments);
  element("mdev").hidden = mdev.length === 0;
  element("mdev-list").replaceChildren(...mdev.map(([uuid, assignments]) =>
    node("li", uuid + " · " + assignments.map(assignmentLabel).join(" / "))));
}

async function refresh() {
  const button = element("refresh");
  button.disabled = true;
  element("status").textContent = "Refreshing";
  try {
    render(await transport.inventory());
  } catch (error) {
    element("status").textContent = "Refresh failed. The page shows the last retrieved results. " + error.message;
  } finally {
    button.disabled = false;
  }
}

element("gpu-select").addEventListener("change", renderSelectedGpu);
element("vf-select").addEventListener("change", renderVfActions);
element("refresh").addEventListener("click", refresh);
if (transport.onPermissionsChanged) {
  element("diagnostic-link").hidden = true;
  element("diagnostic-button").hidden = false;
  element("diagnostic-button").addEventListener("click", () => {
    element("diagnostic-data").textContent = JSON.stringify(inventory, null, 2);
    element("diagnostic-dialog").showModal();
  });
  transport.onPermissionsChanged(() => {
    if (inventory) render({ ...inventory, write_enabled: transport.canWrite() });
    if (!writing && !element("refresh").disabled) refresh();
  });
}
refresh();
