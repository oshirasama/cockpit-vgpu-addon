"""Persist the web service's desired SR-IOV VF and time-sliced profile state."""

import json
import os
from pathlib import Path
import re
import runpy
import sys
import time

from inventory import READ_ERRORS, normalize_bdf


STORE = Path("/var/lib/vgpu-web/gpu-state.json")
LEGACY_STORE = Path("/etc/nvidia-vgpu-persist/config.json")
_restore = runpy.run_path(str(Path(__file__).resolve().parents[1] / "vgpu-persist/vgpu-persist.py"))
Hardware = _restore["Hardware"]
StateError = _restore["Error"]


def normalize_state(raw):
    if (not isinstance(raw, dict) or raw.get("version") != 1
            or not isinstance(raw.get("enabled_pfs"), dict)):
        raise StateError("Check the vGPU Web UI restore configuration format.")
    enabled = {}
    for address, gpu_uuid in raw["enabled_pfs"].items():
        pf = normalize_bdf(address)
        if (pf in enabled or not isinstance(gpu_uuid, str)
                or not re.fullmatch(r"GPU-[0-9a-fA-F-]+", gpu_uuid)):
            raise StateError(f"{pf}: The restore configuration contains an invalid or duplicate GPU UUID.")
        enabled[pf] = gpu_uuid
    entries = _restore["validate_config"](raw)
    if any(enabled.get(entry["pf"]) != entry["gpu_uuid"] for entry in entries):
        raise StateError("The VF and physical GPU entries in the restore configuration do not match.")
    ordered = sorted(entries, key=lambda entry: (entry["pf"], entry["vf_index"]))
    return {"version": 1, "enabled_pfs": dict(sorted(enabled.items())), "entries": ordered}


def load_state(path=STORE):
    return normalize_state(json.loads(path.read_text(encoding="utf-8")))


def save_state(path, state):
    canonical = normalize_state(state)
    _restore["atomic_write"](path, json.dumps(canonical, indent=2, ensure_ascii=False) + "\n", 0o600)
    if sys.platform == "linux":
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def check_legacy(pfs, path=LEGACY_STORE):
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return
    overlap = set(pfs) & {entry["pf"] for entry in _restore["validate_config"](json.loads(raw))}
    if overlap:
        raise StateError("These GPUs are already registered in a separate vgpu-persist restore configuration: " + ", ".join(sorted(overlap)))


def gpu_identity(hw, pf, inventory=None):
    inventory = hw.gpus() if inventory is None else inventory
    if pf not in inventory:
        raise StateError(f"{pf}: Unable to identify the NVIDIA GPU.")
    gpu_uuid = inventory[pf]["gpu_uuid"]
    hw.check_pf(pf, gpu_uuid, inventory)
    return gpu_uuid


def with_enabled_pf(state, pf, gpu_uuid):
    previous_uuid = state["enabled_pfs"].get(pf)
    if previous_uuid is not None and previous_uuid != gpu_uuid:
        raise StateError(f"{pf}: The saved GPU UUID differs from the installed GPU.")
    return {**state, "enabled_pfs": {**state["enabled_pfs"], pf: gpu_uuid}}


def with_profile(state, pf, gpu_uuid, index, vf, profile):
    updated = with_enabled_pf(state, pf, gpu_uuid)
    if any(entry["vf_bdf"] == vf and entry["pf"] != pf for entry in state["entries"]):
        raise StateError(f"{vf}: The VF now belongs to a different physical GPU.")
    entries = [entry for entry in state["entries"]
               if (entry["pf"], entry["vf_index"]) != (pf, index) and entry["vf_bdf"] != vf]
    if profile is not None:
        entries.append({"pf": pf, "gpu_uuid": gpu_uuid, "vf_index": index, "vf_bdf": vf, "profile": profile})
    return normalize_state({**updated, "entries": entries})


def save_and_apply(path, before, desired, apply, readback, original, expected):
    """Record desired state first and roll back only when hardware is still at baseline."""
    changed = desired != before
    if changed:
        save_state(path, desired)
    if original == expected:
        return
    try:
        apply()
        if readback() != expected:
            raise StateError("Unable to verify the GPU change.")
    except READ_ERRORS as exc:
        try:
            actual = readback()
        except READ_ERRORS:
            actual = None
        if actual == original:
            if changed:
                save_state(path, before)
            raise
        if actual == expected:
            return
        raise StateError(f"The restore configuration was saved. Refresh to check whether the GPU change took effect. {exc}") from exc


def initialize(path, hw, adopt=False, legacy=LEGACY_STORE, *, require_vfs=False):
    if path.exists():
        state = load_state(path)
        if state["enabled_pfs"]:
            check_legacy(state["enabled_pfs"], legacy)
        return state
    state = {"version": 1, "enabled_pfs": {}, "entries": []}
    if not adopt:
        save_state(path, state)
        return state

    inventory = hw.gpus()
    for pf in sorted(inventory):
        if not inventory[pf]["sriov"]:
            continue
        present = []
        for index, vf in hw.vfs(pf):
            device = hw.devices / vf
            settings = device / "nvidia"
            if (settings / "current_vgpu_type").is_file() and not (device / "mdev_supported_types").is_dir():
                present.append((index, vf, hw.current(settings)))
        if not present:
            continue
        check_legacy((pf,), legacy)
        gpu_uuid = gpu_identity(hw, pf, inventory)
        state = with_enabled_pf(state, pf, gpu_uuid)
        names = hw.supported(pf) if any(number for _, _, number in present) else {}
        for index, vf, number in present:
            if number:
                if number not in names:
                    raise StateError(f"{vf}: Unable to resolve the name of existing profile ID {number}.")
                state = with_profile(state, pf, gpu_uuid, index, vf, names[number])
    if require_vfs and not state["enabled_pfs"]:
        raise StateError("No active VFs were found. Check the active configuration before switching the restore service.")
    save_state(path, state)
    return state


def restore_saved(path, hw, legacy=LEGACY_STORE, timeout=180):
    state = load_state(path)
    pfs = state["enabled_pfs"]
    if not pfs:
        print("No saved GPU configuration", flush=True)
        return
    check_legacy(pfs, legacy)
    deadline = time.monotonic() + timeout
    # At boot the driver can be initializing even after its service is runnable.
    ready_deadline = min(deadline, time.monotonic() + 45)
    while True:
        try:
            inventory = hw.gpus()
            pending = [pf for pf in pfs if pf not in inventory or not (hw.devices / pf / "driver").is_symlink()]
            if pending:
                raise StateError("Unable to verify the saved GPUs. " + ", ".join(pending))
            break
        except READ_ERRORS:
            if time.monotonic() >= ready_deadline:
                raise
            time.sleep(1)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise StateError("Timed out waiting for GPU initialization.")
    _restore["restore"](state["entries"], hw, enabled_pfs=pfs, timeout=remaining)
    for pf in pfs:
        if not hw.vfs(pf):
            raise StateError(f"{pf}: Unable to verify VFs after restore.")
        print(f"OK {pf}: SR-IOV VF enabled", flush=True)
