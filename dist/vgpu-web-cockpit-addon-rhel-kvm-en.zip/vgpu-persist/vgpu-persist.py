#!/usr/bin/env python3
"""Persist time-sliced NVIDIA SR-IOV vGPUs using vendor-specific VFIO.

Standard library only. Hardware operations require Linux and root.
The restore path deliberately never calls virsh or starts/stops a VM.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

CONFIG = Path('/etc/nvidia-vgpu-persist/config.json')
PROGRAM = Path('/usr/local/sbin/vgpu-persist')
UNIT = 'nvidia-vgpu-persist.service'
DROPIN = '80-nvidia-vgpu-persist.conf'
URI = 'qemu:///system'
VERSION = '1.1.1'


class Error(RuntimeError):
    pass


def bdf(value: str) -> str:
    match = re.fullmatch(r'([0-9a-fA-F]{4,8}):([0-9a-fA-F]{2}):([0-9a-fA-F]{2})\.([0-7])', value)
    if not match:
        raise Error(f'Invalid PCI address: {value!r}')
    domain, bus, device, function = (int(x, 16) for x in match.groups())
    if domain > 0xffff or device > 0x1f:
        raise Error(f'Invalid PCI address: {value!r}')
    return f'{domain:04x}:{bus:02x}:{device:02x}.{function:x}'


def run(args: list[str], timeout: float = 30) -> str:
    env = dict(os.environ, LC_ALL='C', LANG='C')
    try:
        result = subprocess.run(args, capture_output=True, text=True, encoding='utf-8',
                                errors='replace', timeout=timeout, env=env)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Error(f'{args[0]}: {exc}') from exc
    if result.returncode:
        raise Error(f'{" ".join(args)}: {(result.stderr or result.stdout).strip()}')
    return result.stdout


def parse_creatable(text: str) -> dict[str, int]:
    result: dict[str, int] = {}
    ids: set[int] = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        # Actual driver output can be ID-first with a heading, whereas the
        # vGPU documentation also shows a name-first, heading-free format.
        if re.fullmatch(r'\s*ID\s*:\s*vGPU\s+Name\s*', line, re.IGNORECASE):
            continue
        match = re.fullmatch(r'\s*(0[xX][0-9a-fA-F]+|\d+)\s*:\s*(\S(?:.*\S)?)\s*', line)
        if match:
            value, name = match.groups()
            number = int(value, 16 if value.lower().startswith('0x') else 10)
        else:
            match = re.fullmatch(r'\s*(\S(?:.*\S)?)\s+(\d+)\s*', line)
            if not match:
                raise Error(f'Unrecognized creatable_vgpu_types line: {line!r}')
            name, number = match.group(1), int(match.group(2))
        if number <= 0 or name in result or number in ids:
            raise Error('Duplicate or invalid profile in creatable_vgpu_types')
        result[name] = number
        ids.add(number)
    return result


def parse_supported(text: str) -> dict[int, str]:
    """Fail closed when the documented nvidia-smi text format is not understood."""
    result: dict[int, str] = {}
    pending = None
    for line in text.splitlines():
        match = re.fullmatch(r'\s*vGPU Type ID\s*:\s*(0x[0-9a-fA-F]+|\d+)\s*', line)
        if match:
            if pending is not None:
                raise Error('Missing profile name in nvidia-smi output')
            value = match.group(1)
            pending = int(value, 16 if value.startswith('0x') else 10)
            continue
        match = re.fullmatch(r'\s*Name\s*:\s*(\S(?:.*\S)?)\s*', line)
        if match and pending is not None:
            if pending <= 0 or pending in result:
                raise Error('Duplicate/invalid type ID in nvidia-smi output')
            result[pending] = match.group(1)
            pending = None
    if pending is not None or not result or len(set(result.values())) != len(result):
        raise Error('Cannot identify supported vGPU profiles from nvidia-smi output')
    return result


def validate_config(data: dict) -> list[dict]:
    if not isinstance(data, dict) or data.get('version') != 1 or not isinstance(data.get('entries'), list):
        raise Error('Invalid configuration schema (expected version=1 and entries=[])')
    seen_vfs: set[str] = set()
    seen_indices: set[tuple] = set()
    pf_uuids: dict[str, str] = {}
    entries = []
    for raw in data['entries']:
        if not isinstance(raw, dict):
            raise Error('Each configuration entry must be an object')
        try:
            entry = dict(raw)
            entry['pf'] = bdf(raw['pf'])
            entry['vf_bdf'] = bdf(raw['vf_bdf'])
            index = raw['vf_index']
            uuid = raw['gpu_uuid']
            profile = raw['profile']
            if type(index) is not int or index < 0:
                raise ValueError('vf_index must be a nonnegative integer')
            if not isinstance(uuid, str) or not re.fullmatch(r'GPU-[0-9a-fA-F-]+', uuid):
                raise ValueError('gpu_uuid is invalid')
            if not isinstance(profile, str) or not profile.strip() or any(ord(x) < 32 for x in profile):
                raise ValueError('profile is invalid')
        except (KeyError, TypeError, ValueError) as exc:
            raise Error(f'Invalid configuration entry: {exc}') from exc
        key = (entry['pf'], index)
        if entry['vf_bdf'] in seen_vfs or key in seen_indices:
            raise Error('A VF is registered more than once')
        if entry['pf'] == entry['vf_bdf']:
            raise Error('A PF cannot also be its assigned VF')
        if entry['pf'] in pf_uuids and pf_uuids[entry['pf']] != uuid:
            raise Error('Conflicting GPU UUIDs for one PF')
        pf_uuids[entry['pf']] = uuid
        seen_vfs.add(entry['vf_bdf'])
        seen_indices.add(key)
        entries.append(entry)
    return entries


def load_config(path: Path, allow_missing: bool = False) -> list[dict]:
    if allow_missing and not path.exists():
        return []
    try:
        return validate_config(json.loads(path.read_text(encoding='utf-8')))
    except (OSError, ValueError) as exc:
        raise Error(f'Cannot read configuration {path}: {exc}') from exc


def atomic_write(path: Path, text: str, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise Error(f'Refusing to replace symlink: {path}')
    fd, temporary = tempfile.mkstemp(prefix=f'.{path.name}.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def save_config(path: Path, entries: list[dict]) -> None:
    validate_config({'version': 1, 'entries': entries})
    if path.exists():
        # Keep the immediately preceding desired configuration.
        atomic_write(path.with_suffix('.json.bak'), path.read_text(encoding='utf-8'), 0o600)
    atomic_write(path, json.dumps({'version': 1, 'entries': entries}, indent=2, ensure_ascii=False) + '\n', 0o600)


class Hardware:
    def __init__(self, devices: Path = Path('/sys/bus/pci/devices'), runner=run):
        self.devices = devices
        self.run = runner

    def gpus(self) -> dict[str, dict]:
        text = self.run(['nvidia-smi', '--query-gpu=pci.bus_id,uuid,name,mig.mode.current', '--format=csv,noheader'])
        result = {}
        for row in csv.reader(io.StringIO(text), skipinitialspace=True):
            if len(row) != 4:
                raise Error(f'Unexpected GPU inventory row: {row!r}')
            address, uuid, name, mig_mode = (x.strip() for x in row)
            address = bdf(address)
            path = self.devices / address
            if (path / 'physfn').exists():
                continue
            result[address] = {'pf': address, 'gpu_uuid': uuid, 'name': name,
                               'mig_mode': mig_mode,
                               'sriov': (path / 'sriov_totalvfs').exists()}
        if not result:
            raise Error('No physical GPUs were reported by nvidia-smi')
        return result

    def check_pf(self, pf: str, uuid: str, inventory: dict[str, dict]) -> None:
        if pf not in inventory or inventory[pf]['gpu_uuid'] != uuid:
            raise Error(f'{pf}: GPU UUID mismatch/missing GPU; rerun configure after checking VM XML')
        path = self.devices / pf
        if (path / 'physfn').exists():
            raise Error(f'{pf}: this is a VF, not a PF')
        if inventory[pf].get('mig_mode', '').lower() == 'enabled':
            raise Error(f'{pf}: MIG mode is enabled; this tool supports time-sliced vGPUs on non-MIG GPUs only')
        if not inventory[pf]['sriov'] or int((path / 'sriov_totalvfs').read_text()) <= 0:
            raise Error(f'{pf}: no SR-IOV VFs; legacy mdev GPUs are outside this tool\'s scope')
        if (path / 'driver').resolve().name != 'nvidia':
            raise Error(f'{pf}: PF must be bound to the nvidia driver')

    def vfs(self, pf: str) -> list[tuple[int, str]]:
        result = []
        for link in (self.devices / pf).glob('virtfn*'):
            if re.fullmatch(r'virtfn\d+', link.name):
                result.append((int(link.name[6:]), bdf(link.resolve(strict=True).name)))
        return sorted(result)

    def enable_vfs(self, pf: str) -> None:
        if not self.vfs(pf):
            # Never write sriov_numvfs directly; never target ALL.
            self.run(['/usr/lib/nvidia/sriov-manage', '-e', pf])

    def vf_path(self, entry: dict, deadline: float) -> Path:
        link = self.devices / entry['pf'] / f"virtfn{entry['vf_index']}"
        path = self.devices / entry['vf_bdf']
        while True:
            if link.exists():
                actual = bdf(link.resolve(strict=True).name)
                if actual != entry['vf_bdf']:
                    raise Error(f"{entry['pf']}: VF address changed: {actual} != {entry['vf_bdf']}; update VM XML explicitly")
                if (path / 'physfn').resolve().name != entry['pf']:
                    raise Error(f"{actual}: physfn does not point to the expected PF")
                if (path / 'nvidia/current_vgpu_type').exists():
                    return path / 'nvidia'
            if time.monotonic() >= deadline:
                raise Error(f"{entry['vf_bdf']}: vendor-specific VFIO interface not ready (mdev is not supported)")
            time.sleep(0.5)

    def current(self, path: Path) -> int:
        value = path.joinpath('current_vgpu_type').read_text().strip()
        if not re.fullmatch(r'\d+', value):
            raise Error(f'{path}: invalid current_vgpu_type: {value!r}')
        return int(value)

    def creatable(self, path: Path) -> dict[str, int]:
        return parse_creatable(path.joinpath('creatable_vgpu_types').read_text())

    def supported(self, pf: str) -> dict[int, str]:
        return parse_supported(self.run(['nvidia-smi', 'vgpu', '-s', '-i', pf, '-v']))

    def write_type(self, path: Path, number: int) -> None:
        if number <= 0:
            raise Error('This tool never deletes a vGPU (type 0)')
        path.joinpath('current_vgpu_type').write_text(str(number) + '\n')


def xml_vfs(text: str) -> tuple[str, bool, set[str]]:
    root = ET.fromstring(text)
    addresses = set()
    for node in root.findall('./devices/hostdev[@type="pci"]/source/address'):
        attrs = node.attrib
        address = '{:04x}:{:02x}:{:02x}.{:x}'.format(
            *(int(attrs[key], 0) for key in ('domain', 'bus', 'slot', 'function')))
        addresses.add(bdf(address))
    return root.findtext('name', '?'), root.get('id') not in (None, '-1'), addresses


def vm_reservations(runner=run) -> dict[str, list[tuple[str, bool]]]:
    """Inspect live AND persistent definitions, including stopped VMs. Read only."""
    owners: dict[str, set[tuple[str, bool]]] = {}
    ids = runner(['virsh', '-c', URI, 'list', '--all', '--uuid']).split()
    for uuid in ids:
        live = runner(['virsh', '-c', URI, 'dumpxml', uuid])
        name, active, addresses = xml_vfs(live)
        # Determine whether an inactive definition exists without ignoring errors.
        try:
            inactive = runner(['virsh', '-c', URI, 'dumpxml', '--inactive', uuid])
        except Error:
            # A running transient VM can legitimately lack a persistent definition.
            info = runner(['virsh', '-c', URI, 'dominfo', uuid])
            if not re.search(r'^Persistent:\s+no\s*$', info, re.M):
                raise
        else:
            addresses |= xml_vfs(inactive)[2]
        for address in addresses:
            owners.setdefault(address, set()).add((name, active))
    return {address: sorted(values) for address, values in owners.items()}


def restore(entries: list[dict], hw: Hardware, timeout: int = 180, dry_run: bool = False,
            *, enabled_pfs: dict[str, str] | None = None) -> None:
    pfs = dict(enabled_pfs or {})
    pfs.update({entry['pf']: entry['gpu_uuid'] for entry in entries})
    if not pfs:
        raise Error('No desired configuration; run configure first')
    deadline = time.monotonic() + timeout
    inventory = hw.gpus()
    # Check ALL GPU identities before enabling any VFs.
    for pf, uuid in pfs.items():
        hw.check_pf(pf, uuid, inventory)
    if dry_run:
        for pf in pfs:
            if not hw.vfs(pf):
                raise Error(f'{pf}: VFs are disabled; check is read-only, run restore to enable them')
    else:
        for pf in pfs:
            hw.enable_vfs(pf)
    paths = {}
    supported = {}
    # Preflight ALL entries before the first profile write.
    for entry in entries:
        path = hw.vf_path(entry, min(deadline, time.monotonic() + (0 if dry_run else 30)))
        paths[entry['vf_bdf']] = path
        current = hw.current(path)
        if current:
            if entry['pf'] not in supported:
                supported[entry['pf']] = hw.supported(entry['pf'])
            if supported[entry['pf']].get(current) != entry['profile']:
                raise Error(f"{entry['vf_bdf']}: different/unknown existing profile (ID {current}); not overwritten")
        elif entry['profile'] not in hw.creatable(path):
            raise Error(f"{entry['vf_bdf']}: {entry['profile']} is not currently creatable")
    for entry in entries:
        if time.monotonic() >= deadline:
            raise Error('Restore deadline exceeded; completed entries are retained')
        path = paths[entry['vf_bdf']]
        # Refresh because another creation may change capacity/equal-size constraints.
        current = hw.current(path)
        if current:
            actual = hw.supported(entry['pf']).get(current)
            if actual != entry['profile']:
                raise Error(f"{entry['vf_bdf']}: profile changed concurrently; not overwritten")
            print(f"OK {entry['vf_bdf']}: {actual} (already configured)", flush=True)
            continue
        number = hw.creatable(path).get(entry['profile'])
        if number is None:
            raise Error(f"{entry['vf_bdf']}: profile no longer creatable; earlier completed entries are retained")
        if dry_run:
            print(f"PENDING {entry['vf_bdf']}: would create {entry['profile']} (ID {number})", flush=True)
            continue
        # No deletion, unbind, GPU reset, or automatic rollback on failure.
        hw.write_type(path, number)
        if hw.current(path) != number:
            raise Error(f"{entry['vf_bdf']}: failed to verify the written type ID")
        print(f"CREATED {entry['vf_bdf']}: {entry['profile']} (ID {number})", flush=True)


def choose(prompt: str, labels: list[str]) -> int:
    if not labels:
        raise Error('No available choices')
    for index, label in enumerate(labels, 1):
        print(f'  {index}. {label}')
    while True:
        value = input(f'{prompt} [1-{len(labels)} / q=cancel]: ').strip()
        if value.lower() == 'q':
            raise Error('Cancelled; previously completed hardware operations are retained')
        if value.isdecimal() and 1 <= int(value) <= len(labels):
            return int(value) - 1


def confirm(prompt: str) -> bool:
    return input(prompt + ' [yes/NO]: ').strip().lower() == 'yes'


def configure(config: Path, hw: Hardware) -> None:
    entries = load_config(config, allow_missing=True)
    print('SR-IOV/vendor-specific VFIO, time-sliced vGPUs only. VM XML is not modified.')
    print(f'VM lookup connection: {URI}. VF owner labels are not a complete VM inventory.')
    print('The PF menu lists physical GPUs only; VF PCI addresses appear in the following VF menu.')
    print('Stop workloads on a PF before enabling its VFs. q cancels selection.')
    while True:
        inventory = hw.gpus()
        choices = sorted(inventory)
        selected = choose('Select PF', [f"{pf} | {inventory[pf]['name']} | {inventory[pf]['gpu_uuid']} | SR-IOV={inventory[pf]['sriov']}" for pf in choices])
        pf = choices[selected]
        gpu = inventory[pf]
        hw.check_pf(pf, gpu['gpu_uuid'], inventory)
        if not hw.vfs(pf):
            if not confirm(f'Enable SR-IOV VFs on {pf}? This changes host state'):
                raise Error('Cancelled')
            hw.enable_vfs(pf)
        vf_list = hw.vfs(pf)
        if not vf_list:
            raise Error('No VFs appeared; check NVIDIA services and SR-IOV configuration')
        owners = vm_reservations(hw.run)
        registered = {entry['vf_bdf']: entry for entry in entries}
        candidates = []
        labels = []
        print(f'VF menu for PF {pf}: REGISTERED = read-only check; AVAILABLE = configure; BLOCKED = cannot configure.')
        for index, address in vf_list:
            owner_list = owners.get(address, [])
            entry = {'pf': pf, 'gpu_uuid': gpu['gpu_uuid'], 'vf_index': index,
                     'vf_bdf': address, 'profile': 'pending'}
            owner_text = ', '.join(f'{name} ({"active" if active else "stopped"})' for name, active in owner_list) or 'unassigned'
            # Do not wait for every unselected VF. Only the selected VF may
            # need a bounded readiness wait before a hardware operation.
            try:
                path = hw.vf_path(entry, time.monotonic())
                current = hw.current(path)
            except (Error, OSError, ValueError) as exc:
                candidates.append((entry, None, None, 'blocked', str(exc)))
                labels.append(f'virtfn{index} -> {address} | VM={owner_text} | BLOCKED: interface unavailable: {exc}')
                continue
            exclusions = []
            if any(active for _, active in owner_list):
                exclusions.append('referenced by an active VM')
            if len(owner_list) > 1:
                exclusions.append('referenced by multiple VMs')
            if address in registered:
                action = 'registered'
                reason = 'REGISTERED / check only: ' + registered[address]['profile']
            elif exclusions:
                action = 'blocked'
                reason = 'BLOCKED: ' + '; '.join(exclusions)
            else:
                action = 'configure'
                reason = 'AVAILABLE / configure'
            candidates.append((entry, path, current, action, reason))
            labels.append(f'virtfn{index} -> {address} | current_vgpu_type={current} | VM={owner_text} | {reason}')
        if not candidates:
            raise Error('No VFs were found')
        while True:
            entry, path, current, action, reason = candidates[choose('Select VF number', labels)]
            if action != 'blocked':
                break
            print(f'{entry["vf_bdf"]}: {reason}. No change was made. Select a different VF or q to exit.')
        if action == 'registered':
            saved = registered[entry['vf_bdf']]
            print(f'Checking saved mapping only: {saved["vf_bdf"]} -> {saved["profile"]}')
            restore([saved], hw, dry_run=True)
            print('Read-only check finished. No configuration was saved or applied.')
            if confirm('Return to PF selection?'):
                continue
            return
        # Refresh the selected VF state; selection itself must not authorize
        # an overwrite if its profile changed while the menu was displayed.
        path = hw.vf_path(entry, time.monotonic() + 30)
        current = hw.current(path)
        if current == 0:
            profiles = hw.creatable(path)
            names = list(profiles)
            selected = choose('Select profile (creatable_vgpu_types)', [f'{name} | ID={profiles[name]}' for name in names])
            name = names[selected]
            number = profiles[name]
        else:
            name = hw.supported(pf).get(current)
            if name is None:
                raise Error('Cannot identify the existing vGPU profile; nothing will be overwritten')
            number = current
            print(f'Existing profile: {name} (ID {number}). It can be registered without changing it.')
        entry.update(profile=name, type_id_at_setup=number, gpu_name=gpu['name'])
        print(f"PF={pf} / virtfn{entry['vf_index']} / VF={entry['vf_bdf']} / {name}")
        if not confirm('Save this desired mapping and apply it now?'):
            raise Error('Cancelled; VF enabling, if performed, is retained')
        # Repeat reservation checks immediately before applying any profiles.
        final_owners = vm_reservations(hw.run).get(entry['vf_bdf'], [])
        if any(active for _, active in final_owners) or len(final_owners) > 1:
            raise Error('VF is now referenced by an active VM or multiple VM definitions')
        entries.append(entry)
        save_config(config, entries)
        print(f'Saved desired configuration: {config}', flush=True)
        restore(entries, hw)
        print('VM XML entry (add under <devices>; do not add a duplicate hostdev):')
        domain, bus, device_function = entry['vf_bdf'].split(':')
        device, function = device_function.split('.')
        print(f"<hostdev mode='subsystem' type='pci' managed='no'>\n  <source>\n    <address domain='0x{domain}' bus='0x{bus}' slot='0x{device}' function='0x{function}'/>\n  </source>\n</hostdev>")
        if not confirm('Register another VF?'):
            return


def unit_exists(name: str) -> bool:
    return run(['systemctl', 'show', name, '--property=LoadState', '--value']).strip() == 'loaded'


def service_text(units: list[str]) -> str:
    dependencies = ' '.join(units)
    return f'''# Generated by vgpu-persist install. This is a custom service, not an NVIDIA unit.
[Unit]
Description=Restore configured NVIDIA SR-IOV vGPU profiles
Requires={dependencies}
After={dependencies}

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/vgpu-persist restore
RemainAfterExit=yes
TimeoutStartSec=210

[Install]
WantedBy=multi-user.target
'''


def install() -> None:
    if not unit_exists('nvidia-vgpu-mgr.service'):
        raise Error('nvidia-vgpu-mgr.service is missing; verify the installed vGPU Manager package')
    units = ['nvidia-vgpu-mgr.service']
    if unit_exists('nvidia-vgpud.service'):
        units.append('nvidia-vgpud.service')
    source = Path(__file__).resolve()
    atomic_write(PROGRAM, source.read_text(encoding='utf-8'), 0o755)
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(Path('/etc/systemd/system') / UNIT, service_text(units))
    run(['systemctl', 'daemon-reload'])
    print(f'Installed vgpu-persist {VERSION}: {PROGRAM} and {UNIT}. No service enable/start/restart was requested.')
    print('Next: sudo vgpu-persist configure')


def order_libvirt(config: Path, remove: bool) -> None:
    if config != CONFIG:
        raise Error('order-libvirt requires the default configuration path')
    names = ['libvirtd.service', 'virtqemud.service', 'libvirt-guests.service']
    if remove:
        changed = []
        for name in names:
            path = Path('/etc/systemd/system') / f'{name}.d' / DROPIN
            if path.exists():
                path.unlink()
                changed.append(name)
        run(['systemctl', 'daemon-reload'])
        print(f'Removed only this tool\'s ordering drop-ins: {changed}')
        return
    if not load_config(config):
        raise Error('Configure at least one VF first')
    if not unit_exists(UNIT):
        raise Error('Run install first')
    if run(['systemctl', 'is-active', UNIT]).strip() != 'active':
        raise Error('Start the restore service successfully before adding libvirt dependencies')
    if not any(unit_exists(name) for name in names[:2]):
        raise Error('Neither libvirtd.service nor virtqemud.service is installed')
    selected = [name for name in names if unit_exists(name)]
    print('This makes ALL VMs managed by these daemons wait for GPU restore: ' + ', '.join(selected))
    print('GPU restore failure will block startup of these daemons. Existing running VMs are not restarted.')
    if not confirm('Install ordering dependencies?'):
        raise Error('Cancelled')
    text = f'[Unit]\nRequires={UNIT}\nAfter={UNIT}\n'
    previous = {}
    try:
        for name in selected:
            path = Path('/etc/systemd/system') / f'{name}.d' / DROPIN
            previous[path] = path.read_text() if path.exists() else None
            atomic_write(path, text)
        run(['systemctl', 'daemon-reload'])
        run(['systemd-analyze', 'verify', UNIT, *selected])
    except (Error, OSError):
        for path, original in previous.items():
            if original is None:
                path.unlink(missing_ok=True)
            else:
                atomic_write(path, original)
        run(['systemctl', 'daemon-reload'])
        raise
    print('Ordering installed and verified. No daemon was restarted.')


@contextlib.contextmanager
def lock():
    import fcntl  # Linux-only; kept lazy so parser and mock tests run elsewhere.
    with open('/run/lock/nvidia-vgpu-persist.lock', 'a') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise Error('Another vgpu-persist operation is running') from exc
        yield


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', action='version', version=f'vgpu-persist {VERSION}')
    parser.add_argument('--config', type=Path, default=CONFIG, help='desired configuration JSON')
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('inventory', help='read-only GPU/PF/VF inventory; does not enable VFs')
    commands.add_parser('configure', help='interactive PF/VF/profile selection, save and apply')
    commands.add_parser('install', help='install this program and systemd unit; does not enable it')
    restore_parser = commands.add_parser('restore', help='restore desired mappings, without calling libvirt')
    restore_parser.add_argument('--timeout', type=int, default=180, help='restoration deadline in seconds')
    commands.add_parser('check', help='read-only check of saved mappings; disabled VFs are reported')
    ordering = commands.add_parser('order-libvirt', help='order libvirt startup after restoration')
    ordering.add_argument('--remove', action='store_true', help='remove only drop-ins created by this tool')
    args = parser.parse_args()
    try:
        if sys.platform != 'linux':
            raise Error('Hardware commands must be run on the Ubuntu KVM host (Linux)')
        if args.command in ('install', 'configure', 'restore', 'order-libvirt') and os.geteuid() != 0:
            raise Error('Run this command with sudo')
        if args.command in ('install', 'configure', 'order-libvirt') and not sys.stdin.isatty() and args.command != 'install':
            raise Error('This command needs an interactive terminal')
        if args.command == 'install':
            if args.config != CONFIG:
                raise Error('install uses the default configuration path')
            install()
        elif args.command == 'order-libvirt':
            order_libvirt(args.config, args.remove)
        elif args.command == 'inventory':
            hw = Hardware()
            for pf, gpu in sorted(hw.gpus().items()):
                print(f"{pf} | {gpu['name']} | {gpu['gpu_uuid']} | SR-IOV={gpu['sriov']}")
                for index, address in hw.vfs(pf):
                    path = hw.devices / address / 'nvidia'
                    current = hw.current(path) if (path / 'current_vgpu_type').exists() else 'not vendor-specific VFIO'
                    print(f'  virtfn{index} -> {address} | current_vgpu_type={current}')
                    if current == 0:
                        for name, number in hw.creatable(path).items():
                            print(f'    {number}: {name}')
        elif args.command == 'check':
            restore(load_config(args.config), Hardware(), dry_run=True)
        else:
            with lock():
                if args.command == 'configure':
                    configure(args.config, Hardware())
                else:
                    if not 1 <= args.timeout <= 180:
                        raise Error('--timeout must be between 1 and 180 seconds')
                    restore(load_config(args.config), Hardware(), timeout=args.timeout)
        return 0
    except (Error, OSError, ValueError, ET.ParseError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr, flush=True)
        if args.command in ('configure', 'restore'):
            print('This tool requested no vGPU/VM deletion or rollback. VF enabling may already have occurred. Review saved configuration and current state.', file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print('\nCancelled. Already completed hardware operations are retained.', file=sys.stderr)
        return 130


if __name__ == '__main__':
    raise SystemExit(main())
