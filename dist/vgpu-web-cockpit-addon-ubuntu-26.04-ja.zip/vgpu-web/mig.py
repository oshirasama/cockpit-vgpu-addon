"""NVIDIA MIG topology and vendor-specific VF placement on RHEL KVM."""

import csv
import re


GPU_MODEL = re.compile(r"(?:NVIDIA )?RTX PRO (?:6000|4500) Blackwell Server Edition(?: Liquid Cooled)?", re.I)
PROFILE_NAME = r"[\w.+-]+"
STATUS_QUERY = "--query-gpu=mig.mode.current,mig.mode.pending"


def is_mig_vgpu(name):
    """Identify the MIG-backed DC profiles managed for RTX PRO Blackwell."""
    return bool(re.search(r"\bDC-\d+-\d+[ABCQ](?:GFX)?(?:\s|$)", name, re.I))


def supported(gpu_name):
    return bool(GPU_MODEL.fullmatch(gpu_name))


def mode(runner, pf):
    rows = list(csv.reader(runner(["nvidia-smi", "-i", pf, STATUS_QUERY, "--format=csv,noheader"]).splitlines()))
    if len(rows) != 1 or len(rows[0]) != 2:
        raise ValueError(f"{pf}: unexpected MIG mode response")
    return tuple(field.strip().lower() for field in rows[0])


def change_mode(runner, pf, enabled):
    runner(["nvidia-smi", "-i", pf, "-mig", "1" if enabled else "0"])
    expected = "enabled" if enabled else "disabled"
    current, pending = mode(runner, pf)
    if current != expected or pending != expected:
        raise RuntimeError(f"{pf}: MIG mode is {current} (pending: {pending}). Stop GPU clients and retry.")


def size_status(runner, pf):
    """Read capability and observed state separately; never guess a missing state."""
    output = runner(["nvidia-smi", "-q", "-i", pf])
    capability = re.findall(r"^\s*Heterogeneous Time-Slice Sizes\s*:\s*(Supported|Not Supported)\s*$", output, re.M | re.I)
    states = re.findall(r"^\s*vGPU Heterogeneous Mode\s*:\s*(Enabled|Disabled)\s*$", output, re.M | re.I)
    supported = capability[0].lower() == "supported" if len(capability) == 1 else None
    current = ("mixed" if states[0].lower() == "enabled" else "equal") if len(states) == 1 else None
    return {"supported": supported, "current": current}


def change_size_mode(runner, pf, selected):
    if selected not in ("equal", "mixed"):
        raise ValueError("Invalid size mode")
    status = size_status(runner, pf)
    if status["current"] == selected:
        return
    if status["supported"] is not True:
        raise RuntimeError(f"{pf}: Mixed-Size capability could not be confirmed")
    runner(["nvidia-smi", "vgpu", "-i", pf, "-shm", "1" if selected == "mixed" else "0"])
    if size_status(runner, pf)["current"] != selected:
        raise RuntimeError(f"{pf}: could not confirm {selected} mode")


def run_mig(runner, pf, *args):
    return runner(["nvidia-smi", "mig", "-i", pf, *args])


def table_rows(output, title, pattern):
    rows = []
    for line in output.splitlines():
        row = line.strip().strip("|").strip()
        if re.match(r"^\d+\s+.*\bMIG\b", row):
            match = pattern.fullmatch(row)
            if not match:
                raise ValueError(f"Unrecognized {title} row: {row}")
            rows.append(match.groups())
    if not rows and title not in output.lower():
        raise ValueError(f"Missing {title} table")
    return rows


def instances(runner, pf):
    output = instance_list(runner, pf, "GPU", "-lgi")
    pattern = re.compile(rf"\d+\s+MIG\s+({PROFILE_NAME})\s+\d+\s+(\d+)\s+(\d+)\s*:\s*(\d+)")
    result = [{"profile": name, "id": int(gi), "start": int(start), "size": int(size)}
              for name, gi, start, size in table_rows(output, "gpu instances", pattern)]
    if len({row["id"] for row in result}) != len(result) or len({row["start"] for row in result}) != len(result):
        raise ValueError(f"{pf}: ambiguous GPU instances")
    return result


def compute_instances(runner, pf, gi=None):
    args = ["-lci"] if gi is None else ["-lci", "-gi", str(gi)]
    output = instance_list(runner, pf, "compute", *args)
    pattern = re.compile(rf"\d+\s+(\d+)\s+MIG\s+({PROFILE_NAME})\s+\d+\s+(\d+)"
                         r"(?:\s+\d+\s*:\s*\d+)?")
    return [{"gi": int(gi_id), "profile": name, "id": int(ci)}
            for gi_id, name, ci in table_rows(output, "compute instances", pattern)]


def instance_list(runner, pf, kind, *args):
    try:
        return run_mig(runner, pf, *args)
    except RuntimeError as exc:
        message = str(exc).strip().lower().rstrip(".")
        missing = f"no {kind.lower()} instances found"
        if not re.search(rf"(?:^|: ){missing}(?:: not found)?$", message):
            raise
        return str(exc)


def profiles(runner, pf):
    output = run_mig(runner, pf, "-lgip")
    pattern = re.compile(rf"\d+\s+MIG\s+({PROFILE_NAME})\s+(\d+)\s+(\d+)\s*/\s*\d+\s+.*")
    rows = table_rows(output, "gpu instance profiles", pattern)
    placement_text = run_mig(runner, pf, "-lgipp")
    placement = re.compile(r"\s*GPU\s+\d+\s+Profile ID\s+(\d+)\s+Placements?\s*:\s*"
                           r"\{([\d,\s]*)\}\s*:\s*(\d+)\s*")
    placements = {}
    for line in placement_text.splitlines():
        if not line.strip():
            continue
        match = placement.fullmatch(line)
        if not match:
            raise ValueError(f"Unrecognized MIG placement row: {line}")
        number, starts, size = match.groups()
        placements[int(number)] = (list(map(int, starts.split(","))) if starts.strip() else [], int(size))
    return [{"profile": name, "id": int(number), "free": int(free), "starts": starts, "size": size}
            for name, number, free in rows if int(number) in placements
            for starts, size in (placements[int(number)],)]


def geometry(instance):
    return {key: instance[key] for key in ("profile", "start", "size")}


def overlaps(left, right):
    return (left["start"] < right["start"] + right["size"]
            and right["start"] < left["start"] + left["size"])


def find_instance(runner, pf, desired):
    for instance in instances(runner, pf):
        if geometry(instance) == desired:
            return instance
        if overlaps(instance, desired):
            raise RuntimeError(f"{pf}: an existing GI conflicts with placement {desired['start']}")
    return None


def can_create(profile, desired):
    return (profile["profile"] == desired["profile"] and profile["size"] == desired["size"]
            and desired["start"] in profile["starts"] and profile["free"] > 0)


def default_ci(instance, cis):
    # The default CI spans the entire GI. Graphics/media suffixes can differ.
    family = re.match(r"\d+g\.\d+gb", instance["profile"])
    return (family is not None and len(cis) == 1 and cis[0]["gi"] == instance["id"]
            and re.fullmatch(re.escape(family[0]) + r"(?:[+\-].+)?", cis[0]["profile"]) is not None)


def ensure_instance(runner, pf, desired):
    instance = find_instance(runner, pf, desired)
    if instance is None:
        candidates = [p for p in profiles(runner, pf) if can_create(p, desired)]
        if len(candidates) != 1:
            raise RuntimeError(f"{pf}: {desired['profile']} is unavailable at placement {desired['start']}")
        run_mig(runner, pf, "-cgi", f"{candidates[0]['id']}:{desired['start']}", "-C")
        instance = find_instance(runner, pf, desired)
        if instance is None:
            raise RuntimeError(f"{pf}: could not verify the new GI")
    gi = instance["id"]
    cis = compute_instances(runner, pf, gi)
    if not cis:
        # Complete a GI left behind by an interrupted GI/CI operation.
        run_mig(runner, pf, "-cci", "-gi", str(gi))
        cis = compute_instances(runner, pf, gi)
    if not default_ci(instance, cis):
        raise RuntimeError(f"{pf}: GI {gi} must have a single default compute instance")
    return gi


def vf_gi(path):
    value = (path / "gpu_instance_id").read_text().strip()
    if not re.fullmatch(r"\d+", value):
        raise ValueError(f"{path}: invalid gpu_instance_id: {value!r}")
    return int(value)


def place_vf(path, gi):
    if vf_gi(path) != gi:
        (path / "gpu_instance_id").write_text(f"{gi}\n")
    if vf_gi(path) != gi:
        raise RuntimeError(f"{path}: could not verify GI {gi}")
