"use strict";

const element = (id) => document.getElementById(id);
const interfaces = {
  "vendor-vfio": "NVIDIA vendor-specific VFIO",
  mdev: "mdev",
  both: "vendor-specific VFIO / mdev",
  unobserved: "インターフェース未検出",
};
const scopes = { live: "稼働中", config: "永続定義" };
const modeLabels = { equal: "Equal-Size", mixed: "Mixed-Size", mig: "MIG" };
const modeDrafts = new Map();
let inventory = null;
let writing = false;
let refreshForPermissions = false;

const transport = window.vgpuTransport ?? {
  async inventory() {
    const response = await fetch("/api/inventory");
    if (!response.ok) throw new Error("HTTP " + response.status);
    return response.json();
  },
  async operate(payload) {
    const response = await fetch("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-VGPU-Request": "1" },
      body: JSON.stringify(payload),
    });
    if (!response.headers.get("Content-Type")?.includes("application/json")) {
      throw new Error("HTTP " + response.status);
    }
    return response.json();
  },
};

function node(tag, text) {
  const item = document.createElement(tag);
  if (text !== undefined) item.textContent = text;
  return item;
}

function list(entries) {
  const item = node("ul");
  for (const entry of entries) item.append(node("li", entry));
  return item;
}

function assignmentLabel(assignment) {
  return assignment.vm + " · " + scopes[assignment.scope] +
    " · " + (assignment.managed === null ? "managed 属性なし" : "managed=" + assignment.managed);
}

function modeProfiles(gpu, vf) {
  const mode = currentMode(gpu);
  if (!mode) return [];
  return (vf.creatable ?? []).filter((profile) =>
    /\bDC-\d+-\d+[ABCQ](?:GFX)?(?:\s|$)/i.test(profile.name) === (mode === "mig"));
}

function profilesCell(vf, gpu) {
  if (modeChangePending(gpu)) return node("span", "構成方式の変更待ち");
  if (vf.creatable === null) return node("span", "未取得");
  const profiles = modeProfiles(gpu, vf);
  if (profiles.length === 0) return node("span", "候補なし");
  const details = node("details");
  details.append(
    node("summary", profiles.length + " 件"),
    list(profiles.map((profile) => profile.name + " (" + profile.id + ")"))
  );
  return details;
}

function renderGpu(gpu, vmReadComplete) {
  const card = node("article");
  card.className = "card";
  const total = gpu.sriov_total_vfs === null ? "" : " / 最大 " + gpu.sriov_total_vfs;
  const mdev = gpu.pf_mdev ? " · PF に mdev インターフェースあり" : "";
  card.append(
    node("h2", gpu.name),
    node("p", gpu.bdf + " · Driver " + gpu.driver + " · VF " + gpu.vfs.length + total + mdev)
  );
  card.append(node("p", "現在の構成方式：" + (modeLabels[currentMode(gpu)] ?? "未取得")));
  if (gpu.mig) {
    const { current, pending, instances } = gpu.mig;
    card.append(node("p", "MIG · " + (current ?? "未取得") + " · Pending · " + (pending ?? "未取得")));
    if (instances?.length) {
      card.append(list(instances.map((gi) => giLabel(gi) + " · CI " +
        (gi.compute.map((ci) => ci.id).join(", ") || "なし"))));
    }
    if (current === "enabled" && gpu.mig.requires_admin) {
      card.append(node("p", "GI/CI の表示にはホストの管理者権限が必要です。"));
    }
  }
  if (gpu.vfs.length === 0) {
    const description = gpu.sysfs_visible ? "有効な VF を検出していません。" : "PCI sysfs を確認できません。";
    card.append(node("p", description));
    return card;
  }

  const table = node("table");
  const headRow = table.createTHead().insertRow();
  const isMig = currentMode(gpu) === "mig";
  const columns = ["VF / PCI BDF", "管理方式", "現在のプロファイル"];
  if (isMig) columns.push("親 GI / 配置");
  columns.push("設定可能", "VM 参照", "操作");
  for (const label of columns) {
    const header = node("th", label);
    header.scope = "col";
    headRow.append(header);
  }
  const body = table.createTBody();
  for (const vf of gpu.vfs) {
    const row = body.insertRow();
    row.insertCell().textContent = "virtfn" + vf.index + " · " + (vf.bdf ?? "未取得");
    row.insertCell().textContent = interfaces[vf.interface];
    const activeProfile = vf.profile_name
      ? vf.profile_name + " (" + vf.profile_id + ")"
      : "ID " + vf.profile_id;
    row.insertCell().textContent = vf.profile_id === null ? "未取得" :
      vf.profile_id === 0 ? "未設定" : activeProfile;
    if (isMig) {
      const gi = gpu.mig?.instances?.find((item) => item.id === vf.gi_id);
      row.insertCell().textContent = gi ? "GI " + gi.id + " · " + gi.start + ":" + gi.size :
        vf.profile_id > 0 ? "未取得" : "—";
    }
    row.insertCell().append(profilesCell(vf, gpu));
    const assigned = row.insertCell();
    if (vf.assignments.length) assigned.append(list(vf.assignments.map(assignmentLabel)));
    else assigned.textContent = vmReadComplete && vf.bdf ? "参照なし" : "未確認";
    const action = row.insertCell();
    if (inventory.write_enabled && vf.bdf) action.append(operationButton("選択", () => {
      element("vf-select").value = vf.bdf;
      renderVfActions();
      element("vf-select").focus();
      element("configuration").scrollIntoView({ behavior: "smooth", block: "start" });
      return null;
    }));
  }
  const container = node("div");
  container.className = "table-scroll";
  container.append(table);
  card.append(container);
  return card;
}

function selectedGpu() {
  return inventory?.gpus?.find((gpu) => gpu.bdf === element("gpu-select").value);
}

function option(label, value) {
  const entry = node("option", label);
  entry.value = value;
  return entry;
}

function operationButton(label, buildRequest) {
  const button = node("button", label);
  button.type = "button";
  button.disabled = writing;
  button.addEventListener("click", () => {
    const request = buildRequest();
    if (!request) return;
    const { payload, target } = request;
    submitOperation(label, target, payload);
  });
  return button;
}

function choice(id, label, options) {
  const select = node("select");
  select.id = id;
  select.append(...options);
  const caption = node("label", label);
  caption.htmlFor = id;
  const field = node("div");
  field.className = "operation-field";
  field.append(caption, select);
  return { field, select };
}

function giLabel(gi) {
  return "GI " + gi.id + " · " + gi.profile + " · " + gi.start + ":" + gi.size +
    (gi.profile.toLowerCase().endsWith("+gfx") ? "" : " · グラフィックス非対応");
}

function giRequest(action, gpu, gi) {
  return { action, pf: gpu.bdf, gi_profile: gi.profile, gi_start: gi.start, gi_size: gi.size };
}

function currentMode(gpu) {
  if (gpu.mig?.current === "enabled") return "mig";
  if (gpu.mig && gpu.mig.current !== "disabled") return null;
  return gpu.size_mode?.current ?? null;
}

function modeChangePending(gpu) {
  return modeDrafts.has(gpu.bdf) && modeDrafts.get(gpu.bdf) !== currentMode(gpu);
}

function renderModeControls(gpu) {
  const container = element("mode-controls");
  container.replaceChildren();
  const current = currentMode(gpu);
  if (modeDrafts.get(gpu.bdf) === current) modeDrafts.delete(gpu.bdf);
  const draft = modeDrafts.get(gpu.bdf) ?? current;
  container.append(node("p", "現在の構成方式：" + (modeLabels[current] ?? "未取得")));
  const fieldset = node("fieldset");
  fieldset.className = "mode-options";
  fieldset.append(node("legend", "構成方式"));
  const modes = ["equal", "mixed"];
  if (gpu.mig_supported !== false && (gpu.mig_supported === true || gpu.mig)) modes.push("mig");
  const inputs = [];
  const apply = operationButton("構成方式を変更", () => {
    const mode = inputs.find((input) => input.checked)?.value;
    return { payload: { action: "set-mode", pf: gpu.bdf, mode },
      target: gpu.bdf + " · " + modeLabels[current] + " → " + modeLabels[mode] };
  });
  const notice = node("p");
  notice.className = "mode-notice";
  const update = () => {
    const selected = inputs.find((input) => input.checked)?.value;
    apply.disabled = writing || !inventory.write_enabled || !inventory.vm_read_complete || !current || selected === current;
    notice.textContent = selected && selected !== current ? "変更予定：" + modeLabels[selected] + " · 「構成方式を変更」で適用してください。適用前の新規作成はできません。" : "";
    if (selected && selected !== current) {
      const saved = inventory.restore_state;
      const blocked = new Set(gpu.vfs.filter((vf) => vf.profile_id > 0 || vf.assignments.length).map((vf) => vf.bdf));
      for (const entry of saved?.entries ?? []) if (entry.pf === gpu.bdf) blocked.add(entry.vf_bdf);
      if (blocked.size) {
        apply.disabled = true;
        notice.textContent += " · VM の参照・vGPU タイプ・復元対象を先に解除してください：" + [...blocked].join(", ");
      }
      if (current === "mig" && (gpu.mig.instances?.length || saved?.mig_pfs?.[gpu.bdf]?.instances.length)) {
        apply.disabled = true;
        notice.textContent += " · GI / CI と GI の復元対象を先に削除してください。";
      }
      if (!saved) {
        apply.disabled = true;
        notice.textContent += " · 復元設定を取得できません。再取得してください。";
      }
    }
  };
  for (const mode of modes) {
    const label = node("label");
    const input = node("input");
    input.type = "radio";
    input.name = "configuration-mode";
    input.value = mode;
    input.checked = mode === draft;
    input.disabled = writing || !inventory.write_enabled || !current ||
      (gpu.mig && gpu.mig.current !== gpu.mig.pending) ||
      (mode === "mixed" && gpu.size_mode?.supported !== true) ||
      (mode === "mig" && !["enabled", "disabled"].includes(gpu.mig?.current));
    input.addEventListener("change", () => {
      modeDrafts.set(gpu.bdf, mode);
      renderSelectedGpu();
    });
    inputs.push(input);
    label.append(input, node("span", modeLabels[mode]));
    fieldset.append(label);
  }
  container.append(fieldset, apply, notice);
  update();
}

function renderMigActions(controls, gpu, creatingAllowed = true) {
  const mig = gpu.mig;
  if (!mig) return true;
  if (!["enabled", "disabled"].includes(mig.current) || !["enabled", "disabled"].includes(mig.pending)) {
    controls.append(node("p", "MIG の現在の状態と保留状態を取得してください。"));
    return false;
  }
  const active = mig.current === "enabled";
  if (mig.current !== mig.pending) return false;
  if (!active) return true;
  if (!mig.instances) {
    controls.append(node("p", "GI と CI の取得後に操作できます。"));
    return false;
  }
  if (mig.instances.some((gi) => !gi.profile.toLowerCase().endsWith("+gfx"))) {
    controls.append(node("p", "グラフィックス非対応の GI が残っています。作成候補の配置を占有しています。不要な場合は既存の GI から選択して削除してください。"));
  }
  const choices = (mig.profiles ?? []).filter((profile) => profile.free > 0).flatMap((profile) =>
    profile.starts.map((start) => ({ profile: profile.profile, start, size: profile.size })));
  if (choices.length && creatingAllowed) {
    const create = choice("new-gi-select", "作成する GI プロファイル / 配置", choices.map((gi, index) =>
      option(gi.profile + " · " + gi.start + ":" + gi.size, index)));
    controls.append(create.field, operationButton("GI と既定 CI を作成", () => {
      const gi = choices[Number(create.select.value)];
      return { payload: giRequest("create-gi", gpu, gi), target: gpu.bdf + " · " + create.select.selectedOptions[0].textContent };
    }));
  }
  if (mig.instances.length) {
    const existing = choice("existing-gi-select", "既存の GI", mig.instances.map((gi, index) => option(giLabel(gi), index)));
    const existingAction = (action) => {
      const gi = mig.instances[Number(existing.select.value)];
      return { payload: giRequest(action, gpu, gi), target: gpu.bdf + " · " + giLabel(gi) };
    };
    controls.append(existing.field,
      operationButton("GI と CI を削除", () => existingAction("delete-gi")));
  }
  return true;
}

function renderVfActions() {
  renderRestoreSettings(selectedGpu());
  const controls = element("operation-controls");
  controls.replaceChildren();
  const gpu = selectedGpu();
  if (!gpu || !inventory.write_enabled) return;
  renderModeControls(gpu);
  const migControls = element("mig-controls");
  migControls.replaceChildren();
  element("mig-configuration").hidden = currentMode(gpu) !== "mig";
  if (currentMode(gpu) === "mig" && gpu.mig?.instances?.length === 0 && !modeChangePending(gpu)) {
    element("mig-configuration").open = true;
  }
  if (!inventory.vm_read_complete) {
    controls.append(node("p", "VM の参照を確認できる状態で再取得してください。"));
    return;
  }
  const pendingMode = modeChangePending(gpu);
  if (!renderMigActions(migControls, gpu, !pendingMode)) return;
  if (!currentMode(gpu)) {
    controls.append(node("p", "構成方式を取得できません。再取得してください。"));
    return;
  }
  if (pendingMode) controls.append(node("p", "構成方式の変更待ちです。現在の構成の解除だけを操作できます。"));
  if (gpu.vfs.length === 0) {
    if (pendingMode) return;
    if (gpu.sysfs_visible && gpu.sriov_total_vfs > 0) {
      controls.append(operationButton("VF を有効化", () => ({
        payload: { action: "enable-vfs", pf: gpu.bdf },
        target: "物理 GPU " + gpu.bdf + "。GPU を使う CUDA や監視処理を停止した状態で実行します。",
      })));
    } else {
      controls.append(node("p", "この GPU では SR-IOV の有効化条件を確認できません。"));
    }
    return;
  }
  const vf = gpu.vfs.find((entry) => entry.bdf === element("vf-select").value);
  if (!vf || vf.interface !== "vendor-vfio" || vf.profile_id === null) {
    controls.append(node("p", "構成できる VF は NVIDIA vendor-specific VFIO で、現在のプロファイル ID を取得できる VF です。"));
    return;
  }
  const address = { pf: gpu.bdf, vf: vf.bdf };
  const migEnabled = gpu.mig?.current === "enabled";
  const gis = migEnabled ? (gpu.mig.instances ?? []).filter((gi) => gi.default_ci && gi.profile.toLowerCase().endsWith("+gfx")) : [];
  const stopped = (inventory.vms ?? []).filter((vm) => !vm.active);
  if (vf.assignments.length) {
    if (vf.assignments.some((ref) => ref.scope === "live")) {
      controls.append(node("p", "この VF を参照する稼働中の VM を停止してください。"));
      return;
    }
    const vmUuids = [...new Set(vf.assignments.map((ref) => ref.uuid))];
    if (vmUuids.length !== vf.assignments.length || vf.assignments.some((ref) => ref.element !== "hostdev")) {
      controls.append(node("p", "この VF の PCI hostdev を VM ごとに一つずつ確認してください。"));
      return;
    }
    const blocked = vf.assignments.filter((ref) => !stopped.some((vm) => vm.uuid === ref.uuid));
    if (blocked.length) {
      controls.append(node("p", "停止状態を確認する VM · " + blocked.map((ref) => ref.vm).join("、")));
      return;
    }
    const vmNames = vf.assignments.map((ref) => ref.vm).join("、");
    controls.append(operationButton("VF の割り当てを一括解除", () => ({
      payload: { action: "detach", ...address, vm_uuids: vmUuids },
      target: vf.bdf + "\n解除する VM · " + vmNames,
    })));
    const ref = vf.assignments[0];
    if (vf.assignments.length === 1 && ref.managed !== "no" && vf.profile_id > 0) {
      controls.append(operationButton("managed=no に修正", () => ({
        payload: { action: "set-unmanaged", ...address, vm_uuid: ref.uuid, profile_id: vf.profile_id },
        target: vf.bdf + " → " + ref.vm,
      })));
    }
    return;
  }
  if (vf.profile_id === 0) {
    if (pendingMode) return;
    if (migEnabled && !gis.length) {
      controls.append(node("p", "先に「GI / CI の管理」で GI と既定 CI を作成してください。"));
      return;
    }
    const available = modeProfiles(gpu, vf);
    if (!available.length) {
      controls.append(node("p", "現在設定できるプロファイルを取得できません。"));
      return;
    }
    const profiles = choice("profile-select", "設定するプロファイル",
      available.map((profile) => option(profile.name + " (" + profile.id + ")", profile.id)));
    if (migEnabled) {
      const target = choice("target-gi-select", "配置する GI", gis.map((gi) => option(giLabel(gi), gi.start)));
      controls.append(profiles.field, target.field, operationButton("MIG vGPU を設定", () => ({
        payload: { action: "set-mig-profile", ...address, profile_id: Number(profiles.select.value),
          gi_start: Number(target.select.value) },
        target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent + " · " +
          target.select.selectedOptions[0].textContent,
      })));
      return;
    }
    controls.append(profiles.field, operationButton("プロファイルを設定", () => ({
      payload: { action: "set-profile", ...address, profile_id: Number(profiles.select.value) },
      target: vf.bdf + " · " + profiles.select.selectedOptions[0].textContent,
    })));
    return;
  }
  if (stopped.length && !pendingMode) {
    const vms = choice("vm-select", "停止中の VM",
      stopped.map((vm) => option(vm.name, vm.uuid)));
    controls.append(vms.field, operationButton("managed=no で割り当て", () => ({
      payload: { action: "attach", ...address, vm_uuid: vms.select.value, profile_id: vf.profile_id },
      target: vf.bdf + " → " + vms.select.selectedOptions[0].textContent,
    })));
  } else if (!pendingMode) {
    controls.append(node("p", "割り当て先として選択できる停止中の永続 VM がありません。"));
  }
  controls.append(operationButton("vGPU タイプをクリア", () => ({
    payload: { action: "clear-profile", ...address, profile_id: vf.profile_id },
    target: vf.bdf + " · vGPU タイプ ID " + vf.profile_id + " を未設定（ID 0）に戻します。",
  })));
}

function restoreCheckbox(container, gpu, label, checked, kind, key, available = true, note = "") {
  const row = node("label");
  row.className = "restore-option";
  const input = node("input");
  input.type = "checkbox";
  input.checked = checked;
  input.disabled = writing || !inventory.write_enabled || (!checked && !available);
  const text = node("span");
  text.append(node("strong", label));
  text.append(node("small", (checked ? "復元対象" : "復元対象外") + (note ? " · " + note : "")));
  input.addEventListener("change", () => {
    const enabled = input.checked;
    input.checked = checked;
    submitOperation(enabled ? "再起動後の復元を有効化" : "再起動後の復元を解除",
      gpu.bdf + " · " + label,
      { action: "set-restore", pf: gpu.bdf, kind, key, enabled });
  });
  row.append(input, text);
  container.append(row);
}

function renderRestoreSettings(gpu) {
  const section = element("restore-settings");
  section.hidden = !gpu;
  const controls = element("restore-controls");
  controls.replaceChildren();
  if (!gpu) return;
  const saved = inventory.restore_state;
  if (!saved) {
    controls.append(node("p", "復元設定を取得できません。管理者アクセスで再取得してください。"));
    return;
  }
  const config = saved.mig_pfs?.[gpu.bdf];
  const entries = saved.entries.filter((entry) => entry.pf === gpu.bdf);
  const mig = gpu.mig;
  const active = mig?.current === "enabled" && mig.pending === "enabled";
  const sizeMode = saved.size_modes?.[gpu.bdf];
  if (!active && (sizeMode || gpu.size_mode?.current)) {
    restoreCheckbox(controls, gpu, "構成方式を復元 · " + (modeLabels[sizeMode?.mode ?? gpu.size_mode?.current] ?? "未取得"),
      !!sizeMode, "size-mode", 0, !config && !!gpu.size_mode?.current);
  }
  if (mig || config) {
    restoreCheckbox(controls, gpu, "MIG モードを復元", !!config, "mig", 0, active);
    const geometryKey = (gi) => [gi.start, gi.size, gi.profile].join(":");
    const layouts = new Map((config?.instances ?? []).map((gi) => [geometryKey(gi), gi]));
    for (const gi of mig?.instances ?? []) layouts.set(geometryKey(gi), gi);
    for (const gi of [...layouts.values()].sort((a, b) => a.start - b.start)) {
      const stored = config?.instances.some((row) => row.start === gi.start && row.size === gi.size && row.profile === gi.profile);
      const existing = mig?.instances?.find((row) => row.start === gi.start && row.profile === gi.profile && row.size === gi.size);
      restoreCheckbox(controls, gpu, "GI と既定 CI を復元 · " + gi.profile + " · " + gi.start + ":" + gi.size,
        !!stored, "gi", gi.start, !!config && active && existing?.default_ci && gi.profile.toLowerCase().endsWith("+gfx"),
        existing ? "" : "現在の GI は未検出");
    }
  }
  restoreCheckbox(controls, gpu, "SR-IOV VF を復元", !!saved.enabled_pfs[gpu.bdf], "vfs", 0, gpu.vfs.length > 0);
  const vfs = new Map(gpu.vfs.map((vf) => [vf.index, vf]));
  for (const entry of entries) if (!vfs.has(entry.vf_index)) vfs.set(entry.vf_index, { index: entry.vf_index, bdf: entry.vf_bdf });
  for (const vf of [...vfs.values()].sort((a, b) => a.index - b.index)) {
    const entry = entries.find((row) => row.vf_index === vf.index);
    if (!entry && !(vf.profile_id > 0)) continue;
    const name = entry?.profile ?? vf.profile_name ?? ("ID " + vf.profile_id);
    const gi = mig?.instances?.find((row) => row.id === vf.gi_id);
    const parentSaved = !active || config?.instances.some((row) => row.start === gi?.start && row.profile === gi?.profile && row.size === gi?.size);
    const placement = entry?.gi_start ?? gi?.start;
    restoreCheckbox(controls, gpu, "vGPU を復元 · virtfn" + vf.index + " · " + name,
      !!entry, "profile", vf.index, vf.profile_id > 0 && parentSaved,
      vf.bdf + (placement === undefined ? "" : " · GI 配置 " + placement));
  }
}

function renderConfiguration(gpu) {
  element("configuration").hidden = !inventory.write_enabled || !gpu;
  const select = element("vf-select");
  const previousVf = select.value;
  const vfs = gpu?.vfs.filter((vf) => vf.bdf) ?? [];
  select.replaceChildren(...vfs.map((vf) => option("virtfn" + vf.index + " · " + vf.bdf, vf.bdf)));
  if (vfs.some((vf) => vf.bdf === previousVf)) select.value = previousVf;
  element("vf-picker").hidden = vfs.length === 0;
  renderVfActions();
}

async function confirmOperation(label, target) {
  if (!transport.onPermissionsChanged) return window.confirm(label + "\n" + target);
  const dialog = element("operation-dialog");
  element("operation-title").textContent = label;
  element("operation-target").textContent = target;
  dialog.returnValue = "";
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "apply"), { once: true });
  });
}

async function submitOperation(label, target, payload) {
  if (writing || element("refresh").disabled) return;
  const status = element("operation-status");
  const restoreStatus = element("restore-status");
  if (!await confirmOperation(label, target)) return;
  writing = true;
  element("refresh").disabled = true;
  status.textContent = label + "を実行中";
  restoreStatus.textContent = status.textContent;
  renderVfActions();
  try {
    const result = await transport.operate(payload);
    status.textContent = result.error ?? result.message;
  } catch (error) {
    status.textContent = "操作の結果を取得できません。再取得して現在の状態を確認してください。 " + error.message;
  } finally {
    restoreStatus.textContent = status.textContent;
    await refresh();
    writing = false;
    renderSelectedGpu();
  }
}

function renderSelectedGpu() {
  if (!inventory) return;
  const gpu = selectedGpu();
  const content = gpu
    ? renderGpu(gpu, inventory.vm_read_complete)
    : node("p", inventory.gpus === null ? "GPU 情報を取得できません。" : "物理 NVIDIA GPU を検出していません。");
  element("gpus").replaceChildren(content);
  renderConfiguration(gpu);
}

function render(data) {
  inventory = data;
  element("diagnostic-button").disabled = false;
  element("host-info").textContent = [data.host.os, data.host.kernel, data.host.arch].join(" · ");
  const mode = data.write_enabled ? "変更モード" :
    (transport.readOnlyHint ?? "読み取り専用");
  element("status").textContent = mode + " · 取得 " +
    new Date(data.collected_at).toLocaleString("ja-JP") +
    (data.vm_read_complete ? "" : " · VM 参照の確認が一部またはすべて未完了");
  element("warnings").hidden = data.warnings.length === 0;
  element("warning-list").replaceChildren(...data.warnings.map((warning) => node("li", warning)));
  const select = element("gpu-select");
  const previousBdf = select.value;
  const gpus = data.gpus ?? [];
  select.replaceChildren(...gpus.map((gpu) => option(gpu.name + " · " + gpu.bdf, gpu.bdf)));
  if (gpus.some((gpu) => gpu.bdf === previousBdf)) {
    select.value = previousBdf;
  }
  element("gpu-label").textContent = "物理 GPU（" + gpus.length + " 台）";
  element("gpu-picker").hidden = gpus.length === 0;
  renderSelectedGpu();

  const mdev = Object.entries(data.mdev_assignments);
  element("mdev").hidden = mdev.length === 0;
  element("mdev-list").replaceChildren(...mdev.map(([uuid, assignments]) =>
    node("li", uuid + " · " + assignments.map(assignmentLabel).join(" / "))));
}

async function refresh() {
  refreshForPermissions = false;
  const button = element("refresh");
  button.disabled = true;
  element("status").textContent = "取得中";
  try {
    render(await transport.inventory());
  } catch (error) {
    element("status").textContent = "再取得できませんでした。表示中の内容は前回の取得結果です。 " + error.message;
  } finally {
    button.disabled = false;
    if (refreshForPermissions) await refresh();
  }
}

element("gpu-select").addEventListener("change", renderSelectedGpu);
element("vf-select").addEventListener("change", renderVfActions);
element("refresh").addEventListener("click", refresh);
if (transport.onPermissionsChanged) {
  element("diagnostic-link").hidden = true;
  element("diagnostic-button").hidden = false;
  element("diagnostic-button").addEventListener("click", () => {
    element("diagnostic-data").textContent = JSON.stringify(inventory, null, 2);
    element("diagnostic-dialog").showModal();
  });
  transport.onPermissionsChanged(() => {
    if (inventory && !transport.canWrite()) render({ ...inventory, write_enabled: false });
    if (element("refresh").disabled) refreshForPermissions = true;
    else refresh();
  });
}
refresh();
