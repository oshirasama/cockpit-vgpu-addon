"use strict";

(() => {
  const cockpit = window.cockpit;
  const permission = cockpit?.permission({ admin: true });
  const helper = "/usr/local/libexec/vgpu-web/vgpu-web/";
  const python = "/usr/bin/python3";
  const canWrite = () => permission?.allowed === true;

  window.vgpuTransport = {
    canWrite,
    readOnlyHint: "読み取り専用 · GI/CI の表示と構成には Cockpit の管理者アクセスが必要です",
    onPermissionsChanged(callback) {
      permission?.addEventListener("changed", callback);
    },
    async inventory() {
      if (!cockpit) throw new Error("Cockpit の接続を確認してください。");
      const command = [python, "-I", helper + "inventory.py"];
      if (canWrite()) {
        try {
          const data = JSON.parse(await cockpit.spawn(command, { superuser: "require" }));
          return { ...data, write_enabled: data.is_root === true && canWrite() };
        } catch (error) {
          if (error.problem !== "access-denied") throw error;
        }
      }
      const output = await cockpit.spawn(command);
      return { ...JSON.parse(output), write_enabled: false };
    },
    operate(payload) {
      if (!canWrite()) return Promise.resolve({ error: "Cockpit の管理者権限が必要です。" });
      const process = cockpit.spawn(
        [python, "-I", helper + "host_actions.py", "--cockpit-operation"],
        { superuser: "require" },
      );
      process.input(JSON.stringify(payload));
      return process.then(JSON.parse, (failure, output) => {
        if (failure.problem === "access-denied") {
          return { error: "Cockpit の管理者権限が必要です。" };
        }
        if (output) return JSON.parse(output);
        throw new Error(failure.message);
      });
    },
  };
})();
