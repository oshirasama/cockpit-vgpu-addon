"""Read-only inventory for NVIDIA vGPU on Linux KVM."""

import csv
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import re
import runpy
import subprocess
import sys
import xml.etree.ElementTree as ET


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import mig


status = runpy.run_path(str(Path(__file__).resolve().parents[1] / "vgpu-vf-status.py"))
run = status["run"]
normalize_bdf = status["normalize_bdf"]
supported_names = status["supported_names"]
READ_ERRORS = (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired, ET.ParseError)
VIRSH = ["virsh", "--readonly", "--connect", "qemu:///system"]


def read_profiles(path):
    profiles = []
    for line in path.read_text().splitlines():
        if not line.strip() or re.fullmatch(r"\s*ID\s*:\s*vGPU\s+Name\s*", line, re.I):
            continue
        by_id = re.fullmatch(r"\s*(0x[0-9a-f]+|\d+)\s*:\s*(\S.*?)\s*", line, re.I)
        by_name = re.fullmatch(r"\s*(\S.*?)\s+(\d+)\s*", line)
        if by_id:
            value, name = by_id.groups()
        elif by_name:
            name, value = by_name.groups()
        else:
            raise ValueError(f"Unrecognized profile row: {line!r}")
        profiles.append({"id": int(value, 16 if value.lower().startswith("0x") else 10), "name": name})
    return profiles


def read_vfs(pf, path, runner, warnings):
    links = [entry for entry in path.glob("virtfn*") if re.fullmatch(r"virtfn\d+", entry.name)]
    vfs, names = [], None
    for link in sorted(links, key=lambda entry: int(entry.name[6:])):
        vf = {"index": int(link.name[6:]), "bdf": None, "interface": "unobserved",
              "profile_id": None, "profile_name": None, "creatable": None}
        vfs.append(vf)
        try:
            target = link.resolve(strict=True)
            vf["bdf"] = normalize_bdf(target.name)
            nvidia = target / "nvidia"
            current = nvidia / "current_vgpu_type"
            if current.exists():
                vf["interface"] = "vendor-vfio"
                try:
                    value = current.read_text().strip()
                    if not re.fullmatch(r"\d+", value):
                        raise ValueError(f"Unexpected current_vgpu_type: {value!r}")
                    vf["profile_id"] = int(value)
                except READ_ERRORS as exc:
                    warnings.append(f"{vf['bdf']} / current_vgpu_type: {exc}")
                try:
                    vf["creatable"] = read_profiles(nvidia / "creatable_vgpu_types")
                except READ_ERRORS as exc:
                    warnings.append(f"{vf['bdf']} / creatable_vgpu_types: {exc}")
            if (target / "mdev_supported_types").is_dir():
                vf["interface"] = "both" if current.exists() else "mdev"
            if vf["profile_id"]:
                if names is None:
                    try:
                        names = supported_names(runner(["nvidia-smi", "vgpu", "-s", "-i", pf, "-v"]))
                    except READ_ERRORS as exc:
                        names = {}
                        warnings.append(f"{pf} / vGPU profile names: {exc}")
                vf["profile_name"] = names.get(vf["profile_id"])
        except READ_ERRORS as exc:
            warnings.append(f"{pf} / {link.name}: {exc}")
    return vfs


def read_mig(gpu, devices, runner, warnings, *, privileged):
    pf = gpu["bdf"]
    status = gpu["mig"] = {"current": None, "pending": None, "requires_admin": not privileged}
    try:
        current, pending = mig.mode(runner, pf)
        status.update(current=current, pending=pending)
        if current != "enabled" or not privileged:
            return
        instances = mig.instances(runner, pf)
        cis = mig.compute_instances(runner, pf) if instances else []
        for instance in instances:
            instance["compute"] = [ci for ci in cis if ci["gi"] == instance["id"]]
            instance["default_ci"] = mig.default_ci(instance, instance["compute"])
        status["instances"] = instances
        visible_ids = {instance["id"] for instance in instances}
        for vf in gpu["vfs"]:
            if vf["profile_id"] and visible_ids:
                try:
                    gi = mig.vf_gi(devices / vf["bdf"] / "nvidia")
                    if gi in visible_ids:
                        vf["gi_id"] = gi
                except READ_ERRORS as exc:
                    warnings.append(f"{vf['bdf']} / gpu_instance_id: {exc}")
        profiles = []
        for profile in mig.profiles(runner, pf):
            if profile["profile"].lower().endswith("+gfx"):
                # All existing GIs occupy placements, including non-graphics GIs.
                starts = [start for start in profile["starts"] if not any(
                    mig.overlaps({**profile, "start": start}, instance) for instance in instances
                )]
                profiles.append({**profile, "starts": starts})
        status["profiles"] = profiles
    except READ_ERRORS as exc:
        warnings.append(f"{pf} / MIG: {exc}")


def read_gpus(devices, runner, warnings, *, privileged):
    command = ["nvidia-smi", "--query-gpu=name,pci.bus_id,driver_version", "--format=csv,noheader"]
    try:
        output = runner(command)
    except READ_ERRORS as exc:
        warnings.append(f"nvidia-smi: {exc}")
        return None
    gpus = []
    for row in csv.reader(output.splitlines(), skipinitialspace=True):
        try:
            name, address, driver = (field.strip() for field in row)
            pf = normalize_bdf(address)
            path = devices / pf
            if (path / "physfn").is_symlink():
                continue
            gpu = {"name": name, "bdf": pf, "driver": driver, "sriov_total_vfs": None,
                   "pf_mdev": False, "sysfs_visible": path.is_dir(), "vfs": []}
            gpus.append(gpu)
            if not gpu["sysfs_visible"]:
                warnings.append(f"{pf}: PCI device is missing from sysfs")
                continue
            gpu["pf_mdev"] = (path / "mdev_supported_types").is_dir()
            try:
                gpu["sriov_total_vfs"] = int((path / "sriov_totalvfs").read_text())
            except FileNotFoundError:
                pass
            gpu["vfs"] = read_vfs(pf, path, runner, warnings)
            gpu["mig_supported"] = mig.supported(name)
            gpu["size_mode"] = {"supported": None, "current": None}
            if gpu["sriov_total_vfs"]:
                try:
                    gpu["size_mode"] = mig.size_status(runner, pf)
                except READ_ERRORS as exc:
                    warnings.append(f"{pf} / size mode: {exc}")
            if mig.supported(name) and gpu["sriov_total_vfs"]:
                read_mig(gpu, devices, runner, warnings, privileged=privileged)
        except READ_ERRORS as exc:
            warnings.append(f"GPU inventory: {exc}")
    return gpus


def pci_source_bdf(device):
    address = device.find("./source/address")
    if address is None:
        return None
    parts = [int(address.get("domain", "0"), 0)]
    parts.extend(int(address.get(key, ""), 0) for key in ("bus", "slot", "function"))
    return normalize_bdf("{:04x}:{:02x}:{:02x}.{:x}".format(*parts))


def read_vm_assignments(runner, warnings):
    assignments = {"complete": True, "pci": {}, "mdev": {}, "vms": []}
    try:
        active = runner([*VIRSH, "list", "--uuid"]).split()
        persistent = runner([*VIRSH, "list", "--all", "--persistent", "--uuid"]).split()
    except READ_ERRORS as exc:
        warnings.append(f"libvirt / VM list: {exc}")
        assignments["complete"] = False
        return assignments

    for scope, uuids, flags in (("live", active, []), ("config", persistent, ["--inactive"])):
        for uuid in uuids:
            try:
                root = ET.fromstring(runner([*VIRSH, "dumpxml", *flags, uuid]))
                if scope == "live" and root.get("id") in (None, "-1"):
                    raise ValueError("VM stopped during collection; refresh inventory")
                name = root.findtext("name") or uuid
                if scope == "config":
                    assignments["vms"].append({"uuid": uuid, "name": name, "active": uuid in active})
                devices = root.findall("./devices/hostdev")
                devices += root.findall("./devices/interface[@type='hostdev']")
                for device in devices:
                    kind = device.get("type")
                    address = device.find("./source/address")
                    if kind in ("pci", "hostdev") and address is not None:
                        kind, key = "pci", pci_source_bdf(device)
                    elif kind == "mdev" and address is not None and address.get("uuid"):
                        key = address.get("uuid").lower()
                    else:
                        continue
                    assignment = {"vm": name, "uuid": uuid, "scope": scope,
                                  "managed": device.get("managed"), "element": device.tag}
                    assignments[kind].setdefault(key, []).append(assignment)
            except READ_ERRORS as exc:
                warnings.append(f"libvirt / {uuid} / {scope}: {exc}")
                assignments["complete"] = False
    return assignments


def collect(devices=Path("/sys/bus/pci/devices"), runner=run):
    warnings = []
    try:
        os_release = platform.freedesktop_os_release()["PRETTY_NAME"]
    except (AttributeError, OSError, KeyError):
        # platform.freedesktop_os_release was introduced in Python 3.10.
        os_release = platform.system()
        for path in (Path("/etc/os-release"), Path("/usr/lib/os-release")):
            try:
                lines = path.read_text().splitlines()
            except FileNotFoundError:
                continue
            except OSError as exc:
                warnings.append(f"{path}: {exc}")
                continue
            os_release = next((line.split("=", 1)[1].strip("\"'") for line in lines
                               if line.startswith("PRETTY_NAME=")), os_release)
            break

    is_root = getattr(os, "geteuid", lambda: -1)() == 0
    gpus = read_gpus(devices, runner, warnings, privileged=is_root)
    assignments = read_vm_assignments(runner, warnings)
    restore_state = None
    if is_root:
        try:
            from gpu_state import load_state
            restore_state = load_state()
        except READ_ERRORS as exc:
            warnings.append(f"Startup restore settings: {exc}")
    for gpu in gpus or []:
        for vf in gpu["vfs"]:
            vf["assignments"] = assignments["pci"].get(vf["bdf"], [])

    return {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "host": {"os": os_release, "kernel": platform.release(), "arch": platform.machine()},
        "gpus": gpus, "vm_read_complete": assignments["complete"], "vms": assignments["vms"],
        "restore_state": restore_state,
        "mdev_assignments": assignments["mdev"], "warnings": warnings, "is_root": is_root,
    }


if __name__ == "__main__":
    print(json.dumps(collect()))
