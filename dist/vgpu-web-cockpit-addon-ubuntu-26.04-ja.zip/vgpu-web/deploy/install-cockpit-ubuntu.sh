#!/usr/bin/env bash
set -euo pipefail

if [[ -r /etc/os-release ]]; then
    . /etc/os-release
fi
if [[ ${ID:-} != ubuntu || ${VERSION_ID:-} != 26.04 ]]; then
    echo 'このパッケージは Ubuntu 26.04 LTS の KVM ホスト向けです。' >&2
    exit 1
fi

if [[ ! -x /usr/bin/python3 || ! -x /usr/bin/virsh ]] ||
    { ! systemctl cat virtqemud.service >/dev/null 2>&1 &&
      ! systemctl cat libvirtd.service >/dev/null 2>&1; }; then
    echo '先に Python 3 と libvirt の QEMU サービスを用意してください。詳細は INSTALL.ja.md を参照してください。' >&2
    exit 1
fi

if ! command -v nvidia-smi >/dev/null || [[ ! -x /usr/lib/nvidia/sriov-manage ]] ||
    ! systemctl cat nvidia-vgpu-mgr.service >/dev/null 2>&1; then
    echo 'Ubuntu 用 NVIDIA vGPU Manager の導入を確認してください。詳細は INSTALL.ja.md を参照してください。' >&2
    exit 1
fi

exec bash "$(dirname -- "$0")/install-cockpit.sh" "$@"
